<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_Detector {

    private static $lms_plugins = array(
        'learnpress' => array(
            'name'     => 'LearnPress',
            'slug'     => 'learnpress/learnpress.php',
            'file'     => 'learnpress',
            'api_base' => '/wp-json/lp/v1',
        ),
        'learndash' => array(
            'name'     => 'LearnDash',
            'slug'     => 'sfwd-lms/sfwd_lms.php',
            'file'     => 'sfwd_lms',
            'api_base' => '/wp-json/sfwd-lms/v1',
        ),
        'lifterlms' => array(
            'name'     => 'LifterLMS',
            'slug'     => 'lifterlms/lifterlms.php',
            'file'     => 'lifterlms',
            'api_base' => '/wp-json/llms/v1',
        ),
        'sensei' => array(
            'name'     => 'Sensei LMS',
            'slug'     => 'sensei-lms/sensei-lms.php',
            'file'     => 'sensei-lms',
            'api_base' => '/wp-json/sensei/v1',
        ),
    );

    private static $membership_plugins = array(
        'wishlist_member' => array(
            'name' => 'Wishlist Member',
            'slug' => 'wishlist-member/index.php',
            'file' => 'wishlist-member',
        ),
        'memberpress' => array(
            'name' => 'MemberPress',
            'slug' => 'memberpress/memberpress.php',
            'file' => 'memberpress',
        ),
        'restrict_content_pro' => array(
            'name' => 'Restrict Content Pro',
            'slug' => 'restrict-content-pro/restrict-content-pro.php',
            'file' => 'restrict-content-pro',
        ),
        'paid_memberships_pro' => array(
            'name' => 'Paid Memberships Pro',
            'slug' => 'paid-memberships-pro/paid-memberships-pro.php',
            'file' => 'paid-memberships-pro',
        ),
    );

    public static function detect_all() {
        return array(
            'lms'         => self::detect_lms(),
            'membership'  => self::detect_membership(),
        );
    }

    public static function detect_lms() {
        $detected = array();
        foreach ( self::$lms_plugins as $key => $plugin ) {
            $status = self::check_plugin( $plugin['slug'] );
            $detected[ $key ] = array(
                'name'     => $plugin['name'],
                'slug'     => $plugin['slug'],
                'active'   => $status['active'],
                'installed' => $status['installed'],
                'api_base' => $plugin['api_base'],
                'api_available' => $status['active'] ? self::check_api_available( $plugin['api_base'] ) : false,
            );
        }
        return $detected;
    }

    public static function detect_membership() {
        $detected = array();
        foreach ( self::$membership_plugins as $key => $plugin ) {
            $status = self::check_plugin( $plugin['slug'] );
            $detected[ $key ] = array(
                'name'      => $plugin['name'],
                'slug'      => $plugin['slug'],
                'active'    => $status['active'],
                'installed' => $status['installed'],
            );
        }
        return $detected;
    }

    private static function check_plugin( $plugin_slug ) {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins = get_plugins();
        $installed   = isset( $all_plugins[ $plugin_slug ] );
        $active      = is_plugin_active( $plugin_slug );

        return array(
            'installed' => $installed,
            'active'    => $active,
        );
    }

    private static function check_api_available( $api_base ) {
        $site_url = home_url( $api_base );
        $response = wp_remote_get( $site_url, array(
            'timeout' => 5,
            'headers' => array( 'Accept' => 'application/json' ),
        ) );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        return ( $code >= 200 && $code < 300 );
    }

    public static function get_active_lms() {
        $detected = self::detect_lms();
        foreach ( $detected as $key => $lms ) {
            if ( $lms['active'] ) {
                return $key;
            }
        }
        return '';
    }

    public static function get_lms_info( $lms_key ) {
        return isset( self::$lms_plugins[ $lms_key ] ) ? self::$lms_plugins[ $lms_key ] : null;
    }
}
