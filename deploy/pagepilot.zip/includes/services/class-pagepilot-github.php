<?php
/**
 * PagePilot GitHub API Service
 *
 * Handles all communication with the GitHub REST API v3.
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_GitHub {

    /**
     * GitHub API base URL.
     *
     * @var string
     */
    const API_BASE = 'https://api.github.com/';

    /**
     * Personal access token.
     *
     * @var string
     */
    private $token;

    /**
     * Constructor.
     *
     * @param string $token GitHub personal access token.
     */
    public function __construct( $token ) {
        $this->token = $token;
    }

    /**
     * Validate the personal access token by fetching /user.
     *
     * @return array|false User data on success, false on failure.
     */
    public function validate_token() {
        $response = $this->request( 'GET', 'user' );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( $code < 200 || $code >= 300 ) {
            return false;
        }

        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    /**
     * List repositories for the authenticated user.
     *
     * @param int    $page     Page number (1-indexed).
     * @param int    $per_page Number of results per page.
     * @param string $type     Repository type filter (owner, all, public, private, member).
     * @return array|WP_Error Parsed JSON on success, WP_Error on failure.
     */
    public function list_repos( $page = 1, $per_page = 30, $type = 'owner' ) {
        $response = $this->request(
            'GET',
            'user/repos',
            array(
                'page'     => $page,
                'per_page' => $per_page,
                'type'     => $type,
                'sort'     => 'updated',
                'direction' => 'desc',
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'github_api_error',
                sprintf( __( 'GitHub API returned HTTP %d.', 'pagepilot' ), $code ),
                array( 'body' => wp_remote_retrieve_body( $response ) )
            );
        }

        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    /**
     * Create a new repository.
     *
     * @param string $name        Repository name.
     * @param string $description Repository description.
     * @param bool   $private     Whether the repo should be private.
     * @param bool   $auto_init   Whether to auto-initialize with a README.
     * @return array|WP_Error Parsed JSON on success, WP_Error on failure.
     */
    public function create_repo( $name, $description = '', $private = true, $auto_init = true ) {
        $body = array(
            'name'        => sanitize_title( $name ),
            'description' => sanitize_text_field( $description ),
            'private'     => (bool) $private,
            'auto_init'   => (bool) $auto_init,
            'has_issues'  => true,
            'has_wiki'    => false,
        );

        $response = $this->request( 'POST', 'user/repos', array(), wp_json_encode( $body ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( $code < 200 || $code >= 300 ) {
            $error_body = json_decode( wp_remote_retrieve_body( $response ), true );
            $message    = isset( $error_body['message'] ) ? $error_body['message'] : __( 'Failed to create repository.', 'pagepilot' );

            return new WP_Error(
                'github_repo_create_failed',
                $message,
                array( 'status' => $code )
            );
        }

        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    /**
     * Get details of a specific repository.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @return array|WP_Error Parsed JSON on success, WP_Error on failure.
     */
    public function get_repo( $owner, $repo ) {
        $response = $this->request(
            'GET',
            'repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'github_repo_not_found',
                __( 'Repository not found or inaccessible.', 'pagepilot' ),
                array( 'status' => $code )
            );
        }

        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    /**
     * Push multiple files to a repository in a single commit.
     *
     * Steps:
     *   1. Get the HEAD reference SHA.
     *   2. Create blobs for each file.
     *   3. Create a tree from the blobs.
     *   4. Create a commit.
     *   5. Update the ref to point to the new commit.
     *
     * @param string $owner         Repository owner.
     * @param string $repo          Repository name.
     * @param string $branch        Branch name to push to.
     * @param array  $files         Associative array of file_path => file_content.
     * @param string $commit_message Commit message.
     * @return string|WP_Error Commit SHA on success, WP_Error on failure.
     */
    public function push_files( $owner, $repo, $branch, $files, $commit_message ) {
        $repo_path = rawurlencode( $owner ) . '/' . rawurlencode( $repo );

        // Step 1: Get HEAD ref SHA.
        $ref_response = $this->request( 'GET', 'repos/' . $repo_path . '/git/ref/heads/' . rawurlencode( $branch ) );

        if ( is_wp_error( $ref_response ) ) {
            return $ref_response;
        }

        $ref_code = wp_remote_retrieve_response_code( $ref_response );
        if ( $ref_code < 200 || $ref_code >= 300 ) {
            return new WP_Error(
                'github_ref_not_found',
                sprintf( __( 'Branch %s not found.', 'pagepilot' ), $branch ),
                array( 'status' => $ref_code )
            );
        }

        $ref_data = json_decode( wp_remote_retrieve_body( $ref_response ), true );
        $base_sha = $ref_data['object']['sha'];

        // Step 2: Create blobs for each file.
        $tree_entries = array();

        foreach ( $files as $file_path => $content ) {
            $blob_body = array(
                'encoding' => 'base64',
                'content'  => base64_encode( $content ),
            );

            $blob_response = $this->request(
                'POST',
                'repos/' . $repo_path . '/git/blobs',
                array(),
                wp_json_encode( $blob_body )
            );

            if ( is_wp_error( $blob_response ) ) {
                return $blob_response;
            }

            $blob_code = wp_remote_retrieve_response_code( $blob_response );
            if ( $blob_code < 200 || $blob_code >= 300 ) {
                return new WP_Error(
                    'github_blob_failed',
                    sprintf( __( 'Failed to create blob for %s.', 'pagepilot' ), $file_path ),
                    array( 'status' => $blob_code )
                );
            }

            $blob_data = json_decode( wp_remote_retrieve_body( $blob_response ), true );

            $tree_entries[] = array(
                'path'     => $file_path,
                'mode'     => '100644',
                'type'     => 'blob',
                'sha'      => $blob_data['sha'],
            );
        }

        // Step 3: Create a tree.
        $tree_body = array(
            'base_tree' => $base_sha,
            'tree'      => $tree_entries,
        );

        $tree_response = $this->request(
            'POST',
            'repos/' . $repo_path . '/git/trees',
            array(),
            wp_json_encode( $tree_body )
        );

        if ( is_wp_error( $tree_response ) ) {
            return $tree_response;
        }

        $tree_code = wp_remote_retrieve_response_code( $tree_response );
        if ( $tree_code < 200 || $tree_code >= 300 ) {
            return new WP_Error(
                'github_tree_failed',
                __( 'Failed to create Git tree.', 'pagepilot' ),
                array( 'status' => $tree_code )
            );
        }

        $tree_data = json_decode( wp_remote_retrieve_body( $tree_response ), true );
        $tree_sha  = $tree_data['sha'];

        // Step 4: Create a commit.
        $commit_body = array(
            'message'  => $commit_message,
            'tree'     => $tree_sha,
            'parents'  => array( $base_sha ),
        );

        $commit_response = $this->request(
            'POST',
            'repos/' . $repo_path . '/git/commits',
            array(),
            wp_json_encode( $commit_body )
        );

        if ( is_wp_error( $commit_response ) ) {
            return $commit_response;
        }

        $commit_code = wp_remote_retrieve_response_code( $commit_response );
        if ( $commit_code < 200 || $commit_code >= 300 ) {
            return new WP_Error(
                'github_commit_failed',
                __( 'Failed to create Git commit.', 'pagepilot' ),
                array( 'status' => $commit_code )
            );
        }

        $commit_data  = json_decode( wp_remote_retrieve_body( $commit_response ), true );
        $commit_sha   = $commit_data['sha'];

        // Step 5: Update the ref.
        $update_body = array(
            'sha' => $commit_sha,
        );

        $update_response = $this->request(
            'PATCH',
            'repos/' . $repo_path . '/git/refs/heads/' . rawurlencode( $branch ),
            array(),
            wp_json_encode( $update_body )
        );

        if ( is_wp_error( $update_response ) ) {
            return $update_response;
        }

        $update_code = wp_remote_retrieve_response_code( $update_response );
        if ( $update_code < 200 || $update_code >= 300 ) {
            return new WP_Error(
                'github_ref_update_failed',
                __( 'Failed to update branch reference.', 'pagepilot' ),
                array( 'status' => $update_code )
            );
        }

        return $commit_sha;
    }

    /**
     * Make an HTTP request to the GitHub API with retry logic.
     *
     * @param string $method   HTTP method (GET, POST, PATCH, PUT, DELETE).
     * @param string $endpoint API endpoint path (relative to API_BASE).
     * @param array  $query    Optional query parameters.
     * @param string $body     Optional raw JSON body.
     * @return WP_Error|WP_Response HTTP response on success, WP_Error on failure.
     */
    private function request( $method, $endpoint, $query = array(), $body = '' ) {
        $url = self::API_BASE . $endpoint;

        if ( ! empty( $query ) ) {
            $url = add_query_arg( $query, $url );
        }

        $args = array(
            'method'  => $method,
            'headers' => array(
                'Authorization' => 'token ' . $this->token,
                'Accept'        => 'application/vnd.github.v3+json',
                'User-Agent'    => 'PagePilot WordPress Plugin/' . PAGEPILOT_VERSION,
                'Content-Type'  => 'application/json',
            ),
            'timeout' => 30,
        );

        if ( ! empty( $body ) ) {
            $args['body'] = $body;
        }

        $max_retries = 3;
        $retry_delay = 1;

        for ( $attempt = 1; $attempt <= $max_retries; $attempt++ ) {
            $response = wp_remote_request( $url, $args );

            if ( is_wp_error( $response ) ) {
                if ( $attempt < $max_retries ) {
                    sleep( $retry_delay );
                    $retry_delay *= 2;
                    continue;
                }
                return $response;
            }

            $code = wp_remote_retrieve_response_code( $response );

            // Handle rate limiting (429).
            if ( 429 === $code ) {
                $retry_after = wp_remote_retrieve_header( $response, 'retry-after' );
                $wait        = $retry_after ? (int) $retry_after : $retry_delay;

                if ( $attempt < $max_retries ) {
                    sleep( $wait );
                    $retry_delay = $wait * 2;
                    continue;
                }
            }

            // Retry on server errors (5xx).
            if ( $code >= 500 && $attempt < $max_retries ) {
                sleep( $retry_delay );
                $retry_delay *= 2;
                continue;
            }

            return $response;
        }

        return new WP_Error(
            'github_api_max_retries',
            __( 'GitHub API request failed after maximum retries.', 'pagepilot' ),
            array( 'endpoint' => $endpoint )
        );
    }
}
