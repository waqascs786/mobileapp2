<?php
/**
 * PagePilot Admin - Dashboard Page
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class PagePilot_Admin_Dashboard
 *
 * Renders the main dashboard page with status cards, quick actions, and system info.
 */
class PagePilot_Admin_Dashboard {

    /**
     * Plugin version.
     *
     * @var string
     */
    private $version;

    /**
     * Plugin file path.
     *
     * @var string
     */
    private $plugin_file;

    /**
     * Detected plugins.
     *
     * @var array
     */
    private $detected_plugins;

    /**
     * Settings.
     *
     * @var array
     */
    private $settings;

    /**
     * GitHub settings.
     *
     * @var array
     */
    private $github_settings;

    /**
     * Constructor.
     *
     * @param string $version     Plugin version.
     * @param string $plugin_file Plugin main file path.
     */
    public function __construct( $version, $plugin_file ) {
        $this->version         = $version;
        $this->plugin_file     = $plugin_file;
        $this->detected_plugins = $this->get_detected_plugins();
        $this->settings        = get_option( 'pagepilot_settings', array() );
        $this->github_settings = get_option( 'pagepilot_github_settings', array() );
    }

    /**
     * Render the dashboard page.
     */
    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'pagepilot' ) );
        }

        $recent_builds = $this->get_recent_builds();
        ?>
        <div class="wrap pagepilot-wrap pagepilot-dashboard">
            <?php $this->render_welcome_banner(); ?>
            <?php $this->render_status_cards(); ?>
            <?php $this->render_quick_actions(); ?>

            <div class="pagepilot-row">
                <div class="pagepilot-col-2">
                    <?php $this->render_recent_builds( $recent_builds ); ?>
                </div>
                <div class="pagepilot-col-2">
                    <?php $this->render_system_info(); ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render welcome banner.
     */
    private function render_welcome_banner() {
        ?>
        <div class="pagepilot-welcome-banner">
            <div class="pagepilot-welcome-content">
                <h1>
                    <span class="dashicons dashicons-smartphone"></span>
                    <?php esc_html_e( 'PagePilot', 'pagepilot' ); ?>
                    <span class="pagepilot-version">v<?php echo esc_html( $this->version ); ?></span>
                </h1>
                <p><?php esc_html_e( 'Turn your WordPress LMS into a native mobile app. Configure, build, and deploy from here.', 'pagepilot' ); ?></p>
            </div>
        </div>
        <?php
    }

    /**
     * Render status cards.
     */
    private function render_status_cards() {
        $lms_status    = $this->get_lms_status();
        $membership    = $this->get_membership_status();
        $github_status = $this->get_github_connection_status();
        $build_status  = $this->get_last_build_status();
        ?>
        <div class="pagepilot-status-cards">
            <div class="pagepilot-status-card">
                <div class="pagepilot-card-icon">
                    <span class="dashicons dashicons-welcome-learn-more"></span>
                </div>
                <div class="pagepilot-card-content">
                    <h3><?php esc_html_e( 'LMS Plugin', 'pagepilot' ); ?></h3>
                    <p class="pagepilot-card-value">
                        <?php echo esc_html( $lms_status['name'] ? $lms_status['name'] : __( 'Not Detected', 'pagepilot' ) ); ?>
                    </p>
                    <?php if ( $lms_status['name'] ) : ?>
                        <span class="pagepilot-badge <?php echo $lms_status['active'] ? 'pagepilot-badge-success' : 'pagepilot-badge-warning'; ?>">
                            <?php echo $lms_status['active'] ? esc_html__( 'Active', 'pagepilot' ) : esc_html__( 'Inactive', 'pagepilot' ); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="pagepilot-card-action">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-lms' ) ); ?>" class="button button-small">
                        <?php esc_html_e( 'Configure', 'pagepilot' ); ?>
                    </a>
                </div>
            </div>

            <div class="pagepilot-status-card">
                <div class="pagepilot-card-icon">
                    <span class="dashicons dashicons-groups"></span>
                </div>
                <div class="pagepilot-card-content">
                    <h3><?php esc_html_e( 'Membership Plugins', 'pagepilot' ); ?></h3>
                    <p class="pagepilot-card-value">
                        <?php
                        if ( ! empty( $membership ) ) {
                            echo esc_html( count( $membership ) . ' ' . __( 'detected', 'pagepilot' ) );
                        } else {
                            esc_html_e( 'None Detected', 'pagepilot' );
                        }
                        ?>
                    </p>
                    <?php if ( ! empty( $membership ) ) : ?>
                        <span class="pagepilot-badge pagepilot-badge-info">
                            <?php echo esc_html( $membership[0]['name'] ); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="pagepilot-card-action">
                    <a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>" class="button button-small">
                        <?php esc_html_e( 'View Plugins', 'pagepilot' ); ?>
                    </a>
                </div>
            </div>

            <div class="pagepilot-status-card">
                <div class="pagepilot-card-icon">
                    <span class="dashicons dashicons-github"></span>
                </div>
                <div class="pagepilot-card-content">
                    <h3><?php esc_html_e( 'GitHub Connection', 'pagepilot' ); ?></h3>
                    <p class="pagepilot-card-value">
                        <?php echo $github_status ? esc_html__( 'Connected', 'pagepilot' ) : esc_html__( 'Not Connected', 'pagepilot' ); ?>
                    </p>
                    <span class="pagepilot-badge <?php echo $github_status ? 'pagepilot-badge-success' : 'pagepilot-badge-danger'; ?>">
                        <?php echo $github_status ? esc_html__( 'Online', 'pagepilot' ) : esc_html__( 'Offline', 'pagepilot' ); ?>
                    </span>
                </div>
                <div class="pagepilot-card-action">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-github' ) ); ?>" class="button button-small">
                        <?php esc_html_e( 'Setup', 'pagepilot' ); ?>
                    </a>
                </div>
            </div>

            <div class="pagepilot-status-card">
                <div class="pagepilot-card-icon">
                    <span class="dashicons dashicons-performance"></span>
                </div>
                <div class="pagepilot-card-content">
                    <h3><?php esc_html_e( 'Last Build', 'pagepilot' ); ?></h3>
                    <p class="pagepilot-card-value">
                        <?php echo esc_html( $build_status['label'] ); ?>
                    </p>
                    <?php if ( $build_status['status'] ) : ?>
                        <span class="pagepilot-badge pagepilot-badge-<?php echo esc_attr( $build_status['class'] ); ?>">
                            <?php echo esc_html( $build_status['label'] ); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="pagepilot-card-action">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-builds' ) ); ?>" class="button button-small">
                        <?php esc_html_e( 'View Builds', 'pagepilot' ); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render quick action buttons.
     */
    private function render_quick_actions() {
        ?>
        <div class="pagepilot-quick-actions">
            <h2><?php esc_html_e( 'Quick Actions', 'pagepilot' ); ?></h2>
            <div class="pagepilot-action-buttons">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-lms' ) ); ?>" class="button button-primary">
                    <span class="dashicons dashicons-welcome-learn-more"></span>
                    <?php esc_html_e( 'Configure LMS', 'pagepilot' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-github' ) ); ?>" class="button button-secondary">
                    <span class="dashicons dashicons-github"></span>
                    <?php esc_html_e( 'Set Up GitHub', 'pagepilot' ); ?>
                </a>
                <a href="#" class="button button-secondary pagepilot-build-btn" id="pagepilot-quick-build">
                    <span class="dashicons dashicons-feedback"></span>
                    <?php esc_html_e( 'Build App', 'pagepilot' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-settings' ) ); ?>" class="button button-secondary">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <?php esc_html_e( 'App Settings', 'pagepilot' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-docs' ) ); ?>" class="button button-secondary">
                    <span class="dashicons dashicons-sos"></span>
                    <?php esc_html_e( 'Documentation', 'pagepilot' ); ?>
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Render recent builds table.
     *
     * @param array $builds Recent builds array.
     */
    private function render_recent_builds( $builds ) {
        ?>
        <div class="pagepilot-panel">
            <div class="pagepilot-panel-header">
                <h2><?php esc_html_e( 'Recent Builds', 'pagepilot' ); ?></h2>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-builds' ) ); ?>" class="pagepilot-view-all">
                    <?php esc_html_e( 'View All', 'pagepilot' ); ?> &rarr;
                </a>
            </div>
            <div class="pagepilot-panel-body">
                <?php if ( empty( $builds ) ) : ?>
                    <div class="pagepilot-empty-state">
                        <span class="dashicons dashicons-build"></span>
                        <p><?php esc_html_e( 'No builds yet. Create your first build to get started.', 'pagepilot' ); ?></p>
                    </div>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped pagepilot-builds-mini">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'ID', 'pagepilot' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'pagepilot' ); ?></th>
                                <th><?php esc_html_e( 'Branch', 'pagepilot' ); ?></th>
                                <th><?php esc_html_e( 'Date', 'pagepilot' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $builds as $build ) : ?>
                                <tr>
                                    <td>
                                        <strong>#<?php echo esc_html( $build['id'] ); ?></strong>
                                    </td>
                                    <td>
                                        <?php
                                        $status_class = $this->get_build_status_class( $build['status'] );
                                        ?>
                                        <span class="pagepilot-badge pagepilot-badge-<?php echo esc_attr( $status_class ); ?>">
                                            <?php echo esc_html( ucfirst( $build['status'] ) ); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html( $build['branch'] ); ?></td>
                                    <td><?php echo esc_html( human_time_diff( strtotime( $build['created_at'] ), current_time( 'timestamp' ) ) . ' ago' ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render system info panel.
     */
    private function render_system_info() {
        $curl_status = function_exists( 'curl_init' ) ? __( 'Active', 'pagepilot' ) : __( 'Inactive', 'pagepilot' );
        $curl_class  = function_exists( 'curl_init' ) ? 'pagepilot-badge-success' : 'pagepilot-badge-danger';
        ?>
        <div class="pagepilot-panel">
            <div class="pagepilot-panel-header">
                <h2><?php esc_html_e( 'System Info', 'pagepilot' ); ?></h2>
            </div>
            <div class="pagepilot-panel-body">
                <table class="pagepilot-info-table">
                    <tr>
                        <td class="pagepilot-info-label"><?php esc_html_e( 'WordPress Version', 'pagepilot' ); ?></td>
                        <td class="pagepilot-info-value"><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td>
                    </tr>
                    <tr>
                        <td class="pagepilot-info-label"><?php esc_html_e( 'PHP Version', 'pagepilot' ); ?></td>
                        <td class="pagepilot-info-value"><?php echo esc_html( phpversion() ); ?></td>
                    </tr>
                    <tr>
                        <td class="pagepilot-info-label"><?php esc_html_e( 'cURL Status', 'pagepilot' ); ?></td>
                        <td class="pagepilot-info-value">
                            <span class="pagepilot-badge <?php echo esc_attr( $curl_class ); ?>">
                                <?php echo esc_html( $curl_status ); ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td class="pagepilot-info-label"><?php esc_html_e( 'Plugin Version', 'pagepilot' ); ?></td>
                        <td class="pagepilot-info-value"><?php echo esc_html( $this->version ); ?></td>
                    </tr>
                    <tr>
                        <td class="pagepilot-info-label"><?php esc_html_e( 'WP Debug Mode', 'pagepilot' ); ?></td>
                        <td class="pagepilot-info-value">
                            <?php echo WP_DEBUG ? esc_html__( 'Enabled', 'pagepilot' ) : esc_html__( 'Disabled', 'pagepilot' ); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="pagepilot-info-label"><?php esc_html_e( 'Memory Limit', 'pagepilot' ); ?></td>
                        <td class="pagepilot-info-value"><?php echo esc_html( ini_get( 'memory_limit' ) ); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * Get detected plugins (independently for dashboard use).
     *
     * @return array
     */
    private function get_detected_plugins() {
        $detected = array(
            'lms'        => array(),
            'membership' => array(),
        );

        $lms_plugins = array(
            'learnpress/learnpress.php'            => 'LearnPress',
            'lifterlms/lifterlms.php'              => 'LifterLMS',
            'sensei-lms/sensei-lms.php'            => 'Sensei LMS',
            'learn-dash/learndash.php'             => 'LearnDash',
            'masterstudy-lms/masterstudy-lms.php'  => 'MasterStudy LMS',
            'tutor/tutor.php'                      => 'Tutor LMS',
        );

        $membership_plugins = array(
            'woocommerce-memberships/woocommerce-memberships.php' => 'WooCommerce Memberships',
            'memberpress/memberpress.php'                         => 'MemberPress',
            'paid-memberships-pro/paid-memberships-pro.php'       => 'Paid Memberships Pro',
        );

        foreach ( $lms_plugins as $path => $name ) {
            if ( file_exists( WP_PLUGIN_DIR . '/' . $path ) ) {
                $detected['lms'][] = array(
                    'name'   => $name,
                    'slug'   => dirname( $path ),
                    'path'   => $path,
                    'active' => is_plugin_active( $path ),
                );
            }
        }

        foreach ( $membership_plugins as $path => $name ) {
            if ( file_exists( WP_PLUGIN_DIR . '/' . $path ) ) {
                $detected['membership'][] = array(
                    'name'   => $name,
                    'slug'   => dirname( $path ),
                    'path'   => $path,
                    'active' => is_plugin_active( $path ),
                );
            }
        }

        return $detected;
    }

    /**
     * Get LMS status for display.
     *
     * @return array
     */
    private function get_lms_status() {
        $selected = isset( $this->settings['lms_plugin'] ) ? $this->settings['lms_plugin'] : '';

        if ( ! empty( $selected ) && ! empty( $this->detected_plugins['lms'] ) ) {
            foreach ( $this->detected_plugins['lms'] as $lms ) {
                if ( $lms['slug'] === $selected || $lms['path'] === $selected ) {
                    return $lms;
                }
            }
        }

        if ( ! empty( $this->detected_plugins['lms'] ) ) {
            return $this->detected_plugins['lms'][0];
        }

        return array(
            'name'   => '',
            'active' => false,
        );
    }

    /**
     * Get membership plugins status.
     *
     * @return array
     */
    private function get_membership_status() {
        return isset( $this->detected_plugins['membership'] ) ? $this->detected_plugins['membership'] : array();
    }

    /**
     * Check GitHub connection status.
     *
     * @return bool
     */
    private function get_github_connection_status() {
        $token       = isset( $this->github_settings['token'] ) ? $this->github_settings['token'] : '';
        $repository  = isset( $this->github_settings['repository'] ) ? $this->github_settings['repository'] : '';

        return ! empty( $token ) && ! empty( $repository );
    }

    /**
     * Get last build status.
     *
     * @return array
     */
    private function get_last_build_status() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'pagepilot_builds';

        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
            return array(
                'status' => false,
                'label'  => __( 'No Builds', 'pagepilot' ),
                'class'  => 'muted',
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            "SELECT status FROM {$table_name} ORDER BY created_at DESC LIMIT 1",
            ARRAY_A
        );

        if ( ! $build ) {
            return array(
                'status' => false,
                'label'  => __( 'No Builds', 'pagepilot' ),
                'class'  => 'muted',
            );
        }

        return array(
            'status' => true,
            'label'  => ucfirst( $build['status'] ),
            'class'  => $this->get_build_status_class( $build['status'] ),
        );
    }

    /**
     * Map build status to CSS class.
     *
     * @param string $status Build status.
     * @return string CSS class.
     */
    private function get_build_status_class( $status ) {
        $classes = array(
            'pending'  => 'warning',
            'building' => 'info',
            'success'  => 'success',
            'failed'   => 'danger',
            'error'    => 'danger',
        );

        return isset( $classes[ $status ] ) ? $classes[ $status ] : 'muted';
    }

    /**
     * Get recent builds.
     *
     * @param int $limit Number of builds.
     * @return array
     */
    private function get_recent_builds( $limit = 5 ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'pagepilot_builds';

        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
            return array();
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $builds = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );

        return $builds ? $builds : array();
    }
}
