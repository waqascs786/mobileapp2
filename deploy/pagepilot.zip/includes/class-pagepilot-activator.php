<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_Activator {

    public static function activate() {
        self::create_tables();
        self::set_defaults();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $settings_table = $wpdb->prefix . 'pagepilot_settings';
        $builds_table   = $wpdb->prefix . 'pagepilot_builds';
        $cache_table    = $wpdb->prefix . 'pagepilot_course_cache';

        $sql_settings = "CREATE TABLE $settings_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            option_name varchar(100) NOT NULL,
            option_value longtext NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY option_name (option_name)
        ) $charset_collate;";

        $sql_builds = "CREATE TABLE $builds_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            repo_owner varchar(100) NOT NULL,
            repo_name varchar(100) NOT NULL,
            branch varchar(100) NOT NULL DEFAULT 'main',
            commit_sha varchar(40) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            workflow_run_id bigint(20) DEFAULT NULL,
            artifact_url text DEFAULT NULL,
            error_message text DEFAULT NULL,
            build_config longtext DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY status (status)
        ) $charset_collate;";

        $sql_cache = "CREATE TABLE $cache_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            lms_plugin varchar(50) NOT NULL,
            item_type varchar(20) NOT NULL DEFAULT 'course',
            item_id bigint(20) NOT NULL,
            item_data longtext NOT NULL,
            last_synced datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY lms_item (lms_plugin, item_type, item_id),
            KEY last_synced (last_synced)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql_settings );
        dbDelta( $sql_builds );
        dbDelta( $sql_cache );
    }

    private static function set_defaults() {
        $defaults = array(
            'app_name'          => get_bloginfo( 'name' ),
            'package_name'      => 'com.' . preg_replace( '/[^a-z0-9]/', '', strtolower( get_bloginfo( 'name' ) ) ) . '.app',
            'primary_color'     => '#6C63FF',
            'secondary_color'   => '#FF6584',
            'accent_color'      => '#00C9A7',
            'bg_color'          => '#FFFFFF',
            'text_color'        => '#333333',
            'github_token'      => '',
            'github_repo'       => '',
            'github_owner'      => '',
            'github_branch'     => 'main',
            'github_repo_private' => '1',
            'lms_plugin'        => '',
            'site_url'          => home_url(),
            'enable_courses'    => '1',
            'enable_wishlist'   => '1',
            'enable_profile'    => '1',
            'enable_quiz'       => '1',
            'enable_search'     => '1',
            'enable_dark_mode'  => '1',
            'enable_push_notifications' => '0',
            'enable_social_login' => '0',
            'enable_offline_mode' => '0',
            'splash_bg_color'   => '#6C63FF',
            'app_version'       => '1.0.0',
            'build_number'      => '1',
        );

        foreach ( $defaults as $key => $value ) {
            update_option( 'pagepilot_' . $key, $value );
        }
    }

    public static function get_setting( $key, $default = '' ) {
        return get_option( 'pagepilot_' . $key, $default );
    }

    public static function update_setting( $key, $value ) {
        return update_option( 'pagepilot_' . $key, $value );
    }

    public static function get_all_settings() {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_settings';
        $rows = $wpdb->get_results( "SELECT option_name, option_value FROM $table", OBJECT_K );

        $settings = array();
        foreach ( $rows as $row ) {
            $settings[ $row->option_name ] = $row->option_value;
        }

        if ( empty( $settings ) ) {
            $option_keys = array(
                'app_name', 'package_name', 'primary_color', 'secondary_color',
                'accent_color', 'bg_color', 'text_color', 'github_token',
                'github_repo', 'github_owner', 'github_branch', 'github_repo_private',
                'lms_plugin', 'site_url', 'enable_courses', 'enable_wishlist',
                'enable_profile', 'enable_quiz', 'enable_search', 'enable_dark_mode',
                'enable_push_notifications', 'enable_social_login', 'enable_offline_mode',
                'splash_bg_color', 'app_version', 'build_number',
            );
            foreach ( $option_keys as $key ) {
                $settings[ $key ] = self::get_setting( $key );
            }
        }

        return $settings;
    }
}
