<?php
/**
 * Plugin Name:       PagePilot
 * Plugin URI:        https://pagepilot.app
 * Description:       Generate native Android & iOS mobile apps from your WordPress LMS. Integrates with LearnPress, LearnDash, and membership plugins. Build via GitHub Actions.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            PagePilot
 * Author URI:        https://pagepilot.app
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pagepilot
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PAGEPILOT_VERSION', '1.0.0' );
define( 'PAGEPILOT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PAGEPILOT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PAGEPILOT_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once PAGEPILOT_PLUGIN_DIR . 'includes/class-pagepilot-activator.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/class-pagepilot-detector.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/admin/class-pagepilot-admin.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/admin/class-pagepilot-admin-dashboard.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/admin/class-pagepilot-admin-settings.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/admin/class-pagepilot-admin-builds.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/admin/class-pagepilot-admin-docs.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/api/class-pagepilot-rest-api.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/api/class-pagepilot-app-api.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/lms/class-pagepilot-lms-factory.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/lms/class-pagepilot-learnpress.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/lms/class-pagepilot-lifterlms.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/services/class-pagepilot-github.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/services/class-pagepilot-builder.php';
require_once PAGEPILOT_PLUGIN_DIR . 'includes/services/class-pagepilot-webhook.php';

register_activation_hook( __FILE__, array( 'PagePilot_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'PagePilot_Activator', 'deactivate' ) );

class PagePilot {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action( 'init', array( $this, 'load_textdomain' ) );
        add_action( 'rest_api_init', array( $this, 'register_rest_api' ) );

        if ( is_admin() ) {
            new PagePilot_Admin( PAGEPILOT_VERSION, __FILE__ );
        }

        new PagePilot_Webhook();
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'pagepilot', false, dirname( PAGEPILOT_PLUGIN_BASENAME ) . '/languages' );
    }

    public function register_rest_api() {
        $api = new PagePilot_REST_API();
        $api->register_routes();

        $app_api = new PagePilot_App_API();
        $app_api->register_routes();
    }

    public function get_detected_lms() {
        return PagePilot_LMS_Factory::get_detected_lms();
    }

    public function get_detected_plugins() {
        return PagePilot_Detector::detect_all();
    }
}

function pagepilot() {
    return PagePilot::instance();
}

pagepilot();
