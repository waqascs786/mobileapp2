<?php
/**
 * PagePilot REST API Controller
 *
 * Registers all REST API routes under the 'pagepilot/v1' namespace.
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_REST_API {

    /**
     * API namespace.
     *
     * @var string
     */
    const NAMESPACE = 'pagepilot/v1';

    /**
     * Register all REST routes.
     */
    public function register_routes() {
        // Settings endpoints.
        register_rest_route(
            self::NAMESPACE,
            '/settings',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_settings' ),
                    'permission_callback' => array( $this, 'check_admin_permission' ),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'save_settings' ),
                    'permission_callback' => array( $this, 'check_admin_permission' ),
                ),
            )
        );

        // Detected plugins.
        register_rest_route(
            self::NAMESPACE,
            '/detected-plugins',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_detected_plugins' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        // GitHub endpoints.
        register_rest_route(
            self::NAMESPACE,
            '/github/connect',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'github_connect' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/github/repos',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'github_list_repos' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/github/save-settings',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'save_github_settings' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/advanced/save-settings',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'save_advanced_settings' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/github/create-repo',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'github_create_repo' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        // Build endpoints.
        register_rest_route(
            self::NAMESPACE,
            '/build/trigger',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'trigger_build' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/builds',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'list_builds' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/build/(?P<id>\d+)',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_build' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/build/(?P<id>\d+)/cancel',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'cancel_build' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        // Course endpoints.
        register_rest_route(
            self::NAMESPACE,
            '/courses/preview',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'preview_courses' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        register_rest_route(
            self::NAMESPACE,
            '/courses/sync',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'sync_courses' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        // System info.
        register_rest_route(
            self::NAMESPACE,
            '/system-info',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_system_info' ),
                'permission_callback' => array( $this, 'check_admin_permission' ),
            )
        );

        // Webhook endpoint (no admin permission — called by GitHub).
        register_rest_route(
            self::NAMESPACE,
            '/webhook',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'handle_webhook' ),
                'permission_callback' => '__return_true',
            )
        );

        // Debug endpoint — dump cache table state (public for debugging).
        register_rest_route(
            self::NAMESPACE,
            '/debug/cache',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'debug_cache' ),
                'permission_callback' => '__return_true',
            )
        );

        // Self-update endpoint — upload a new plugin zip and overwrite.
        register_rest_route(
            self::NAMESPACE,
            '/self-update',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'self_update' ),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * Permission callback: requires manage_options capability and a valid nonce or app password.
     *
     * @return bool|WP_Error True if authorized, WP_Error otherwise.
     */
    public function check_admin_permission() {
        // Check standard WP capability (works when cookies are intact).
        if ( current_user_can( 'manage_options' ) ) {
            $nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) ) : '';
            if ( ! empty( $nonce ) && wp_verify_nonce( $nonce, 'wp_rest' ) ) {
                return true;
            }
            if ( $this->is_application_password_request() ) {
                return true;
            }
        }

        // CDN-safe fallback: PagePilot token auth via custom headers.
        $pp_user  = isset( $_SERVER['HTTP_X_PAGEPILOT_USER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_PAGEPILOT_USER'] ) ) : '';
        $pp_token = isset( $_SERVER['HTTP_X_PAGEPILOT_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_PAGEPILOT_TOKEN'] ) ) : '';
        if ( ! empty( $pp_user ) && ! empty( $pp_token ) ) {
            $u = get_user_by( 'login', $pp_user );
            if ( $u && user_can( $u, 'manage_options' ) && hash_equals( md5( $u->ID . wp_salt() ), $pp_token ) ) {
                wp_set_current_user( $u->ID );
                return true;
            }
        }

        return new WP_Error(
            'pagepilot_rest_forbidden',
            __( 'You do not have permission to perform this action.', 'pagepilot' ),
            array( 'status' => 403 )
        );
    }

    /**
     * Check if the request is authenticated via an application password.
     *
     * @return bool
     */
    private function is_application_password_request() {
        $auth_header = isset( $_SERVER['HTTP_AUTHORIZATION'] )
            ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) )
            : '';

        return ! empty( $auth_header ) && str_starts_with( strtolower( $auth_header ), 'basic ' );
    }

    // -------------------------------------------------------------------------
    // Settings endpoints.
    // -------------------------------------------------------------------------

    /**
     * Return all plugin settings.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function get_settings( $request ) {
        $settings = PagePilot_Activator::get_all_settings();
        return new WP_REST_Response( $settings, 200 );
    }

    /**
     * Save plugin settings from the JSON request body.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function save_settings( $request ) {
        $params = $request->get_json_params();

        if ( ! is_array( $params ) || empty( $params ) ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => __( 'Request body must be valid JSON.', 'pagepilot' ) ),
                400
            );
        }

        // Separate GitHub settings (pagepilot_github_settings[key]) from regular settings (pagepilot_settings[key]).
        $github_settings = array();
        $flat            = array();
        foreach ( $params as $key => $value ) {
            if ( preg_match( '/^pagepilot_github_settings\[([^\]]+)\]$/', $key, $m ) ) {
                $github_settings[ sanitize_key( $m[1] ) ] = sanitize_text_field( wp_unslash( $value ) );
            } elseif ( preg_match( '/^pagepilot_settings\[([^\]]+)\]$/', $key, $m ) ) {
                $flat[ $m[1] ] = $value;
            } elseif ( preg_match( '/^[^\[]+\[([^\]]+)\]$/', $key, $m ) ) {
                $flat[ $m[1] ] = $value;
            } else {
                $flat[ $key ] = $value;
            }
        }

        $saved = 0;

        // Save GitHub settings to their own option.
        if ( ! empty( $github_settings ) ) {
            update_option( 'pagepilot_github_settings', $github_settings );
            $saved += count( $github_settings );
        }

        // Save regular plugin settings to the pagepilot_settings array option.
        $existing = get_option( 'pagepilot_settings', array() );
        foreach ( $flat as $key => $value ) {
            if ( in_array( $key, array( 'primary_color', 'secondary_color', 'accent_color', 'bg_color', 'text_color', 'splash_bg_color' ), true ) ) {
                $value = sanitize_hex_color( $value );
            } else {
                $value = sanitize_text_field( $value );
            }
            $existing[ $key ] = $value;
            ++$saved;
        }
        if ( ! empty( $flat ) ) {
            update_option( 'pagepilot_settings', $existing );
        }

        return new WP_REST_Response(
            array(
                'success' => true,
                'saved'   => $saved,
                'message' => __( 'Settings saved successfully.', 'pagepilot' ),
            ),
            200
        );
    }

    // -------------------------------------------------------------------------
    // GitHub settings endpoint.
    // -------------------------------------------------------------------------

    /**
     * Save GitHub-specific settings.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function save_github_settings( $request ) {
        $params = $request->get_json_params();

        if ( ! is_array( $params ) || empty( $params ) ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => __( 'Request body must be valid JSON.', 'pagepilot' ) ),
                400
            );
        }

        $existing = get_option( 'pagepilot_github_settings', array() );
        $allowed  = array( 'token', 'repository', 'branch', 'repo_private', 'appetize_token', 'appetize_android_key', 'appetize_ios_key' );

        foreach ( $params as $key => $value ) {
            $key = sanitize_key( $key );
            if ( ! in_array( $key, $allowed, true ) ) {
                continue;
            }
            $existing[ $key ] = sanitize_text_field( wp_unslash( $value ) );
        }

        update_option( 'pagepilot_github_settings', $existing );

        return new WP_REST_Response(
            array(
                'success' => true,
                'message' => __( 'GitHub settings saved.', 'pagepilot' ),
            ),
            200
        );
    }

    /**
     * Save advanced settings.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function save_advanced_settings( $request ) {
        $params = $request->get_json_params();

        if ( ! is_array( $params ) || empty( $params ) ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => __( 'Request body must be valid JSON.', 'pagepilot' ) ),
                400
            );
        }

        $existing = get_option( 'pagepilot_advanced_settings', array() );
        $allowed  = array( 'api_endpoint', 'auth_method', 'custom_headers' );

        foreach ( $params as $key => $value ) {
            $key = sanitize_key( $key );
            if ( ! in_array( $key, $allowed, true ) ) {
                continue;
            }
            if ( 'custom_headers' === $key ) {
                $existing[ $key ] = sanitize_textarea_field( wp_unslash( $value ) );
            } elseif ( 'api_endpoint' === $key ) {
                $existing[ $key ] = esc_url_raw( wp_unslash( $value ) );
            } else {
                $existing[ $key ] = sanitize_text_field( wp_unslash( $value ) );
            }
        }

        update_option( 'pagepilot_advanced_settings', $existing );

        return new WP_REST_Response(
            array(
                'success' => true,
                'message' => __( 'Advanced settings saved.', 'pagepilot' ),
            ),
            200
        );
    }

    // -------------------------------------------------------------------------
    // Detected plugins endpoint.
    // -------------------------------------------------------------------------

    /**
     * Return detected LMS and membership plugins.
     *
     * @return WP_REST_Response
     */
    public function get_detected_plugins() {
        $detected = PagePilot_Detector::detect_all();
        return new WP_REST_Response( $detected, 200 );
    }

    // -------------------------------------------------------------------------
    // GitHub endpoints.
    // -------------------------------------------------------------------------

    /**
     * Validate a GitHub personal access token and store it on success.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function github_connect( $request ) {
        $params  = $request->get_json_params();
        $token   = isset( $params['token'] ) ? sanitize_text_field( $params['token'] ) : '';

        if ( empty( $token ) ) {
            return new WP_Error(
                'pagepilot_missing_token',
                __( 'GitHub token is required.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $github = new PagePilot_GitHub( $token );
        $user   = $github->validate_token();

        if ( ! $user ) {
            return new WP_Error(
                'pagepilot_invalid_token',
                __( 'The GitHub token is invalid or has been revoked.', 'pagepilot' ),
                array( 'status' => 401 )
            );
        }

        PagePilot_Activator::update_setting( 'github_token', $token );

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => array(
                    'login' => isset( $user['login'] ) ? $user['login'] : '',
                    'name'  => isset( $user['name'] ) ? $user['name'] : '',
                    'email' => isset( $user['email'] ) ? $user['email'] : '',
                ),
                'message' => __( 'GitHub account connected successfully.', 'pagepilot' ),
            ),
            200
        );
    }

    /**
     * List the authenticated user's GitHub repositories.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function github_list_repos( $request ) {
        $token = PagePilot_Activator::get_setting( 'github_token' );

        if ( empty( $token ) ) {
            return new WP_Error(
                'pagepilot_no_token',
                __( 'GitHub is not connected. Please connect your GitHub account first.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $page     = absint( $request->get_param( 'page' ) ?: 1 );
        $per_page = absint( $request->get_param( 'per_page' ) ?: 30 );
        $type     = sanitize_text_field( $request->get_param( 'type' ) ?: 'owner' );

        $github = new PagePilot_GitHub( $token );
        $repos  = $github->list_repos( $page, $per_page, $type );

        if ( is_wp_error( $repos ) ) {
            return $repos;
        }

        return new WP_REST_Response( $repos, 200 );
    }

    /**
     * Create a new GitHub repository.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function github_create_repo( $request ) {
        $token = PagePilot_Activator::get_setting( 'github_token' );

        if ( empty( $token ) ) {
            return new WP_Error(
                'pagepilot_no_token',
                __( 'GitHub is not connected. Please connect your GitHub account first.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $params    = $request->get_json_params();
        $name      = isset( $params['name'] ) ? sanitize_title( $params['name'] ) : '';
        $private   = isset( $params['private'] ) ? (bool) $params['private'] : true;

        if ( empty( $name ) ) {
            return new WP_Error(
                'pagepilot_missing_name',
                __( 'Repository name is required.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $github = new PagePilot_GitHub( $token );
        $repo   = $github->create_repo(
            $name,
            sprintf( __( 'Mobile app generated by PagePilot from %s', 'pagepilot' ), get_bloginfo( 'name' ) ),
            $private,
            true
        );

        if ( is_wp_error( $repo ) ) {
            return $repo;
        }

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => array(
                    'full_name' => isset( $repo['full_name'] ) ? $repo['full_name'] : ( isset( $repo['owner']['login'] ) ? $repo['owner']['login'] . '/' . $name : $name ),
                    'html_url'  => isset( $repo['html_url'] ) ? $repo['html_url'] : '',
                    'private'   => isset( $repo['private'] ) ? $repo['private'] : $private,
                    'name'      => isset( $repo['name'] ) ? $repo['name'] : $name,
                ),
                'message' => __( 'Repository created successfully.', 'pagepilot' ),
            ),
            201
        );
    }

    // -------------------------------------------------------------------------
    // Build endpoints.
    // -------------------------------------------------------------------------

    /**
     * Trigger a new build.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function trigger_build( $request ) {
        $params = $request->get_json_params();

        $repo_owner = isset( $params['repo_owner'] ) ? sanitize_text_field( $params['repo_owner'] ) : '';
        $repo_name  = isset( $params['repo_name'] ) ? sanitize_text_field( $params['repo_name'] ) : '';
        $branch     = isset( $params['branch'] ) ? sanitize_text_field( $params['branch'] ) : 'main';
        $platform   = isset( $params['platform'] ) ? sanitize_text_field( $params['platform'] ) : 'android';
        if ( ! in_array( $platform, array( 'android', 'ios' ), true ) ) {
            $platform = 'android';
        }

        // Also accept combined "repository" field (e.g. "owner/repo").
        if ( empty( $repo_owner ) || empty( $repo_name ) ) {
            $repository = isset( $params['repository'] ) ? sanitize_text_field( $params['repository'] ) : '';
            if ( ! empty( $repository ) && strpos( $repository, '/' ) !== false ) {
                $parts = explode( '/', $repository, 2 );
                $repo_owner = $parts[0];
                $repo_name  = $parts[1];
            }
        }

        if ( empty( $repo_owner ) || empty( $repo_name ) ) {
            return new WP_Error(
                'pagepilot_missing_params',
                __( 'repo_owner and repo_name are required.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $token = PagePilot_Activator::get_setting( 'github_token' );
        if ( empty( $token ) ) {
            $gh_settings = get_option( 'pagepilot_github_settings', array() );
            $token = isset( $gh_settings['token'] ) ? $gh_settings['token'] : '';
        }
        if ( empty( $token ) ) {
            return new WP_Error(
                'pagepilot_no_token',
                __( 'GitHub is not connected.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $settings = PagePilot_Activator::get_all_settings();
        $settings['github_owner'] = $repo_owner;
        $settings['github_repo']  = $repo_name;
        $settings['github_branch'] = $branch;
        $settings['platform'] = $platform;
        if ( empty( $settings['github_token'] ) ) {
            $gh_settings = get_option( 'pagepilot_github_settings', array() );
            $settings['github_token'] = isset( $gh_settings['token'] ) ? $gh_settings['token'] : '';
        }

        $builder = new PagePilot_Builder();
        $result  = $builder->trigger_build( $settings );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return new WP_REST_Response(
            array(
                'success'  => true,
                'build_id' => $result['build_id'],
                'message'  => __( 'Build triggered successfully.', 'pagepilot' ),
            ),
            202
        );
    }

    /**
     * List build history with pagination.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public function list_builds( $request ) {
        $args = array(
            'page'     => absint( $request->get_param( 'page' ) ?: 1 ),
            'per_page' => absint( $request->get_param( 'per_page' ) ?: 20 ),
            'status'   => sanitize_text_field( $request->get_param( 'status' ) ?: '' ),
        );

        $builder = new PagePilot_Builder();
        $builds  = $builder->get_builds( $args );

        return new WP_REST_Response( $builds, 200 );
    }

    /**
     * Get a single build by ID.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function get_build( $request ) {
        $build_id = absint( $request->get_param( 'id' ) );

        if ( ! $build_id ) {
            return new WP_Error(
                'pagepilot_invalid_id',
                __( 'Invalid build ID.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            return new WP_Error(
                'pagepilot_build_not_found',
                __( 'Build not found.', 'pagepilot' ),
                array( 'status' => 404 )
            );
        }

        if ( ! empty( $build['build_config'] ) ) {
            $build['build_config'] = json_decode( $build['build_config'], true );
        }

        return new WP_REST_Response( $build, 200 );
    }

    /**
     * Cancel a running build by stopping the GitHub Actions workflow run.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function cancel_build( $request ) {
        $build_id = absint( $request->get_param( 'id' ) );

        if ( ! $build_id ) {
            return new WP_Error(
                'pagepilot_invalid_id',
                __( 'Invalid build ID.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            return new WP_Error(
                'pagepilot_build_not_found',
                __( 'Build not found.', 'pagepilot' ),
                array( 'status' => 404 )
            );
        }

        if ( in_array( $build['status'], array( 'completed', 'failed', 'cancelled' ), true ) ) {
            return new WP_Error(
                'pagepilot_build_not_cancellable',
                __( 'This build cannot be cancelled because it is no longer running.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        if ( empty( $build['workflow_run_id'] ) ) {
            return new WP_Error(
                'pagepilot_no_workflow',
                __( 'No workflow run ID associated with this build.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $token  = PagePilot_Activator::get_setting( 'github_token' );
        $github = new PagePilot_GitHub( $token );

        $response = wp_remote_post(
            'https://api.github.com/repos/' . rawurlencode( $build['repo_owner'] ) . '/' . rawurlencode( $build['repo_name'] ) . '/actions/runs/' . absint( $build['workflow_run_id'] ) . '/cancel',
            array(
                'headers' => array(
                    'Authorization' => 'token ' . $token,
                    'Accept'        => 'application/vnd.github.v3+json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'pagepilot_cancel_failed',
                __( 'Failed to cancel the GitHub Actions workflow run.', 'pagepilot' ),
                array( 'status' => 502 )
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table,
            array( 'status' => 'cancelled' ),
            array( 'id' => $build_id ),
            array( '%s' ),
            array( '%d' )
        );

        return new WP_REST_Response(
            array(
                'success' => true,
                'message' => __( 'Build cancelled successfully.', 'pagepilot' ),
            ),
            200
        );
    }

    // -------------------------------------------------------------------------
    // Course endpoints.
    // -------------------------------------------------------------------------

    /**
     * Preview courses from the currently configured LMS plugin.
     *
     * @return WP_REST_Response|WP_Error
     */
    public function preview_courses() {
        $lms_plugin = PagePilot_Activator::get_setting( 'lms_plugin' );

        if ( empty( $lms_plugin ) ) {
            return new WP_Error(
                'pagepilot_no_lms',
                __( 'No LMS plugin is configured. Please set an LMS plugin first.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        $lms_key = '';
        if ( strpos( $lms_plugin, 'learnpress' ) !== false ) {
            $lms_key = 'learnpress';
        } elseif ( strpos( $lms_plugin, 'lifterlms' ) !== false ) {
            $lms_key = 'lifterlms';
        } elseif ( strpos( $lms_plugin, 'learndash' ) !== false || strpos( $lms_plugin, 'sfwd' ) !== false ) {
            $lms_key = 'learndash';
        } elseif ( strpos( $lms_plugin, 'sensei' ) !== false ) {
            $lms_key = 'sensei';
        }

        // Try to get courses from cache table first (works on CDN environments).
        $courses = $this->get_courses_from_cache( $lms_key );

        if ( empty( $courses ) && ! empty( $lms_key ) ) {
            $handler = PagePilot_LMS_Factory::get_handler( $lms_key );
            if ( $handler ) {
                $result = $handler->get_courses( array( 'per_page' => 20, 'page' => 1 ) );
                if ( ! is_wp_error( $result ) ) {
                    $courses = isset( $result['courses'] ) ? $result['courses'] : array();
                }
            }
        }

        return new WP_REST_Response(
            array(
                'lms'     => $lms_key,
                'courses' => $courses,
            ),
            200
        );
    }

    /**
     * Read courses from the cache table for preview.
     */
    private function get_courses_from_cache( $lms_key ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
            return array();
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT item_id, item_data FROM {$table} WHERE lms_plugin = %s AND item_type = 'course' ORDER BY last_synced DESC LIMIT 20",
                $lms_key
            )
        );

        $courses = array();
        foreach ( $rows as $row ) {
            $data = json_decode( $row->item_data, true );
            if ( is_array( $data ) ) {
                $data['id'] = (int) $row->item_id;
                $courses[] = $data;
            }
        }

        return $courses;
    }

    /**
     * Sync courses from the configured LMS into the local cache table.
     *
     * @return WP_REST_Response|WP_Error
     */
    public function sync_courses( $request ) {
        $params = $request->get_json_params();
        $lms_plugin = isset( $params['lms_plugin'] ) ? sanitize_text_field( $params['lms_plugin'] ) : '';

        if ( empty( $lms_plugin ) ) {
            $lms_plugin = PagePilot_Activator::get_setting( 'lms_plugin' );
        }

        if ( empty( $lms_plugin ) ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => __( 'No LMS plugin is configured.', 'pagepilot' ) ),
                400
            );
        }

        // Detect which LMS key to use from the plugin path.
        $lms_key = '';
        if ( strpos( $lms_plugin, 'learnpress' ) !== false ) {
            $lms_key = 'learnpress';
        } elseif ( strpos( $lms_plugin, 'lifterlms' ) !== false ) {
            $lms_key = 'lifterlms';
        } elseif ( strpos( $lms_plugin, 'learndash' ) !== false || strpos( $lms_plugin, 'sfwd' ) !== false ) {
            $lms_key = 'learndash';
        } elseif ( strpos( $lms_plugin, 'sensei' ) !== false ) {
            $lms_key = 'sensei';
        }

        if ( empty( $lms_key ) ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => __( 'Could not identify the LMS plugin.', 'pagepilot' ) ),
                400
            );
        }

        $handler = PagePilot_LMS_Factory::get_handler( $lms_key );

        if ( ! $handler ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => sprintf( __( 'LMS handler for %s is not available.', 'pagepilot' ), $lms_key ) ),
                400
            );
        }

        $result = $handler->sync_courses();

        if ( is_wp_error( $result ) ) {
            return new WP_REST_Response(
                array( 'success' => false, 'message' => $result->get_error_message() ),
                500
            );
        }

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => $result,
                'message' => sprintf(
                    __( '%d courses synced successfully.', 'pagepilot' ),
                    isset( $result['synced'] ) ? $result['synced'] : 0
                ),
            ),
            200
        );
    }

    // -------------------------------------------------------------------------
    // System info endpoint.
    // -------------------------------------------------------------------------

    /**
     * Return system information for diagnostics.
     *
     * @return WP_REST_Response
     */
    public function get_system_info() {
        global $wpdb;

        $active_plugins = array();
        foreach ( get_option( 'active_plugins', array() ) as $plugin ) {
            $plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin, false, false );
            $active_plugins[] = array(
                'name'    => $plugin_data['Name'],
                'version' => $plugin_data['Version'],
                'slug'    => $plugin,
            );
        }

        $info = array(
            'wordpress_version' => get_bloginfo( 'version' ),
            'php_version'       => PHP_VERSION,
            'mysql_version'     => $wpdb->get_var( 'SELECT VERSION()' ),
            'server_software'   => isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '',
            'memory_limit'      => function_exists( 'wp_convert_hr_to_bytes' ) ? size_format( wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) ) ) : ini_get( 'memory_limit' ),
            'active_plugins'    => $active_plugins,
            'plugin_version'    => PAGEPILOT_VERSION,
            'site_url'          => home_url(),
            'multisite'         => is_multisite(),
            'theme'             => wp_get_theme()->get( 'Name' ),
        );

        return new WP_REST_Response( $info, 200 );
    }

    // -------------------------------------------------------------------------
    // Debug endpoint.
    // -------------------------------------------------------------------------

    /**
     * Dump the cache table state for debugging.
     *
     * @return WP_REST_Response
     */
    public function debug_cache() {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';
        $result = array( 'table_exists' => false );

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
            return new WP_REST_Response( $result, 200 );
        }

        $result['table_exists'] = true;

        // Count by item_type.
        $counts = $wpdb->get_results(
            "SELECT item_type, COUNT(*) as cnt FROM {$table} GROUP BY item_type",
            OBJECT_K
        );
        $result['counts'] = array();
        foreach ( $counts as $type => $row ) {
            $result['counts'][ $type ] = (int) $row->cnt;
        }

        // Sample lessons — show stored course_id values.
        $lessons = $wpdb->get_results(
            "SELECT item_id, JSON_EXTRACT(item_data, '$.course_id') as stored_course_id
             FROM {$table} WHERE item_type = 'lesson' LIMIT 10"
        );
        $result['lesson_course_ids'] = array();
        foreach ( $lessons as $l ) {
            $result['lesson_course_ids'][] = array(
                'lesson_id'       => (int) $l->item_id,
                'stored_course_id' => (int) $l->stored_course_id,
            );
        }

        // Section→course mapping.
        $sections = $wpdb->get_results(
            "SELECT ID, post_parent FROM {$wpdb->posts} WHERE post_type = 'llms_section' AND post_status = 'publish' LIMIT 10"
        );
        $result['section_to_course'] = array();
        foreach ( $sections as $s ) {
            $result['section_to_course'][] = array(
                'section_id'  => (int) $s->ID,
                'course_id'   => (int) $s->post_parent,
            );
        }

        // Course IDs in cache.
        $courses = $wpdb->get_results(
            "SELECT item_id FROM {$table} WHERE item_type = 'course'"
        );
        $result['cached_course_ids'] = array_map( 'intval', wp_list_pluck( $courses, 'item_id' ) );

        // Settings.
        $settings = get_option( 'pagepilot_settings', array() );
        $result['lms_plugin_setting'] = isset( $settings['lms_plugin'] ) ? $settings['lms_plugin'] : '(empty)';

        // Check what LMS-related post types exist.
        $post_types = $wpdb->get_col(
            "SELECT DISTINCT post_type FROM {$wpdb->posts} WHERE post_type LIKE '%lesson%' OR post_type LIKE '%section%' OR post_type LIKE '%course%' OR post_type LIKE '%quiz%' OR post_type LIKE '%llms%' ORDER BY post_type"
        );
        $result['lms_post_types'] = $post_types;

        // Check total lesson posts (regardless of cache).
        $total_lessons = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'lesson' AND post_status = 'publish'"
        );
        $result['total_published_lessons'] = (int) $total_lessons;

        // Check total section posts.
        $total_sections = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'llms_section' AND post_status = 'publish'"
        );
        $result['total_published_sections'] = (int) $total_sections;

        // Check total course posts.
        $total_courses = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'course' AND post_status = 'publish'"
        );
        $result['total_published_courses'] = (int) $total_courses;

        // Check total quiz posts.
        $total_quizzes = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'llms_quiz' AND post_status = 'publish'"
        );
        $result['total_published_quizzes'] = (int) $total_quizzes;

        // Sample lesson posts — what are their post_parent values?
        $sample_lessons = $wpdb->get_results(
            "SELECT ID, post_parent, post_title FROM {$wpdb->posts} WHERE post_type = 'lesson' AND post_status = 'publish' LIMIT 5"
        );
        $result['sample_lessons'] = array();
        foreach ( $sample_lessons as $sl ) {
            $result['sample_lessons'][] = array(
                'id'           => (int) $sl->ID,
                'post_parent'  => (int) $sl->post_parent,
                'title'        => $sl->post_title,
            );
        }

        // Is LifterLMS active?
        $result['lifterlms_active'] = class_exists( 'LifterLMS' );

        // Count section posts by type.
        $section_counts = $wpdb->get_results(
            "SELECT post_type, COUNT(*) as cnt FROM {$wpdb->posts} WHERE post_type IN ('llms_section', 'section') GROUP BY post_type"
        );
        $result['section_counts_by_type'] = array();
        foreach ( $section_counts as $sc ) {
            $result['section_counts_by_type'][ $sc->post_type ] = (int) $sc->cnt;
        }

        // Sample section posts (both types).
        $sample_sections = $wpdb->get_results(
            "SELECT ID, post_type, post_parent, post_status, post_title FROM {$wpdb->posts} WHERE post_type IN ('llms_section', 'section') LIMIT 10"
        );
        $result['sample_sections'] = array();
        foreach ( $sample_sections as $ss ) {
            $result['sample_sections'][] = array(
                'id'           => (int) $ss->ID,
                'post_type'    => $ss->post_type,
                'post_parent'  => (int) $ss->post_parent,
                'post_status'  => $ss->post_status,
                'title'        => $ss->post_title,
            );
        }

        // Check _llms_section_lessons meta — which posts have it and what values.
        $section_meta = $wpdb->get_results(
            "SELECT pm.post_id, pm.meta_value, p.post_parent, p.post_status
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_llms_section_lessons'
             LIMIT 10"
        );
        $result['section_lessons_meta'] = array();
        foreach ( $section_meta as $sm ) {
            $decoded = maybe_unserialize( $sm->meta_value );
            $result['section_lessons_meta'][] = array(
                'section_id'   => (int) $sm->post_id,
                'course_id'    => (int) $sm->post_parent,
                'post_status'  => $sm->post_status,
                'lesson_ids'   => is_array( $decoded ) ? array_map( 'intval', $decoded ) : array(),
            );
        }

        // Also check if lessons have any course-related meta.
        $sample = $wpdb->get_var( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'lesson' LIMIT 1" );
        if ( $sample ) {
            $lesson_meta_keys = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT meta_key FROM {$wpdb->postmeta} WHERE post_id = %d AND (meta_key LIKE '%%course%%' OR meta_key LIKE '%%llms%%' OR meta_key LIKE '%%section%%')",
                    $sample
                )
            );
            $result['lesson_meta_keys'] = $lesson_meta_keys;
        }

        return new WP_REST_Response( $result, 200 );
    }

    // -------------------------------------------------------------------------
    // Webhook endpoint.
    // -------------------------------------------------------------------------

    /**
     * Forward incoming GitHub webhooks to the webhook handler.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function handle_webhook( $request ) {
        $handler = new PagePilot_Webhook();
        return $handler->process_webhook_request( $request );
    }

    // -------------------------------------------------------------------------
    // Self-update endpoint.
    // -------------------------------------------------------------------------

    /**
     * POST /self-update — accept a zip file and overwrite the plugin in-place.
     *
     * @param WP_REST_Request $request Request with a `pluginzip` file field.
     * @return WP_REST_Response|WP_Error
     */
    public function self_update( $request ) {
        // Auth: require Basic auth as admin OR a valid app token.
        $user_id = 0;
        if ( isset( $_SERVER['PHP_AUTH_USER'] ) && isset( $_SERVER['PHP_AUTH_PW'] ) ) {
            $user = wp_authenticate( sanitize_text_field( wp_unslash( $_SERVER['PHP_AUTH_USER'] ) ), wp_unslash( $_SERVER['PHP_AUTH_PW'] ) );
            if ( ! is_wp_error( $user ) && user_can( $user, 'manage_options' ) ) {
                $user_id = $user->ID;
            }
        }
        if ( ! $user_id ) {
            // Check app token.
            $pp_user  = isset( $_SERVER['HTTP_X_PAGEPILOT_USER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_PAGEPILOT_USER'] ) ) : '';
            $pp_token = isset( $_SERVER['HTTP_X_PAGEPILOT_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_PAGEPILOT_TOKEN'] ) ) : '';
            if ( ! empty( $pp_user ) && ! empty( $pp_token ) ) {
                $u = get_user_by( 'login', $pp_user );
                if ( $u && user_can( $u, 'manage_options' ) && hash_equals( md5( $u->ID . wp_salt() ), $pp_token ) ) {
                    $user_id = $u->ID;
                }
            }
        }
        if ( ! $user_id ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Unauthorized.' ), 403 );
        }

        // Accept base64-encoded zip in JSON body (CDN blocks multipart form).
        $params = $request->get_json_params();
        $tmp    = null;

        if ( ! empty( $params['pluginzip_base64'] ) ) {
            $raw = base64_decode( $params['pluginzip_base64'], true );
            if ( false === $raw ) {
                return new WP_REST_Response( array( 'success' => false, 'message' => 'Invalid base64 data.' ), 400 );
            }
            $tmp = wp_tempnam( 'pp_update_' );
            file_put_contents( $tmp, $raw );
        } else {
            // Fallback: standard multipart file upload.
            $files = $request->get_file_params();
            if ( ! empty( $files['pluginzip'] ) && ! empty( $files['pluginzip']['tmp_name'] ) ) {
                $tmp = $files['pluginzip']['tmp_name'];
            }
        }

        if ( ! $tmp || ! file_exists( $tmp ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'No zip file provided. Send {pluginzip_base64: "..."} in JSON body.' ), 400 );
        }

        $plugin_dir = plugin_dir_path( PAGEPILOT_FILE );

        // Extract zip into plugin dir, overwriting existing files.
        $zip = new ZipArchive();
        if ( true !== $zip->open( $tmp ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Failed to open zip.' ), 500 );
        }
        $zip->extractTo( $plugin_dir );
        $zip->close();
        unlink( $tmp );

        return new WP_REST_Response( array(
            'success' => true,
            'message' => 'Plugin updated successfully.',
            'version' => defined( 'PAGEPILOT_VERSION' ) ? PAGEPILOT_VERSION : 'unknown',
        ), 200 );
    }
}
