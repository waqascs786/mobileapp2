<?php
/**
 * PagePilot Webhook Handler
 *
 * Processes incoming GitHub webhooks, verifies signatures, and updates
 * build status records. Also provides an AJAX polling endpoint for the admin UI.
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_Webhook {

    /**
     * Constructor. Registers hooks.
     */
    public function __construct() {
        add_action( 'wp_ajax_pagepilot_poll_build', array( $this, 'ajax_poll_build' ) );
    }

    /**
     * Process a webhook request forwarded from the REST API controller.
     *
     * @param WP_REST_Request $request Incoming request.
     * @return WP_REST_Response|WP_Error
     */
    public function process_webhook_request( $request ) {
        $body = $request->get_body();

        $signature = isset( $_SERVER['HTTP_X_HUB_SIGNATURE_256'] )
            ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_HUB_SIGNATURE_256'] ) )
            : '';

        $event = isset( $_SERVER['HTTP_X_GITHUB_EVENT'] )
            ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_GITHUB_EVENT'] ) )
            : '';

        if ( empty( $event ) ) {
            return new WP_Error(
                'pagepilot_missing_event',
                __( 'Missing X-GitHub-Event header.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        // Verify signature when a secret is configured.
        $secret = get_option( 'pagepilot_webhook_secret', '' );
        if ( ! empty( $secret ) ) {
            if ( empty( $signature ) || ! $this->verify_signature( $body, $signature, $secret ) ) {
                return new WP_Error(
                    'pagepilot_invalid_signature',
                    __( 'Invalid webhook signature.', 'pagepilot' ),
                    array( 'status' => 401 )
                );
            }
        }

        $data = json_decode( $body, true );

        if ( ! is_array( $data ) ) {
            return new WP_Error(
                'pagepilot_invalid_payload',
                __( 'Invalid JSON payload.', 'pagepilot' ),
                array( 'status' => 400 )
            );
        }

        // Handle ping events.
        if ( 'ping' === $event ) {
            return new WP_REST_Response( array( 'message' => 'pong' ), 200 );
        }

        $action = isset( $data['action'] ) ? $data['action'] : '';

        switch ( $event ) {
            case 'workflow_run':
                $this->process_workflow_run( $data );
                break;

            case 'workflow_job':
                $this->process_workflow_job( $data );
                break;

            default:
                // Unhandled event type — acknowledge gracefully.
                break;
        }

        return new WP_REST_Response( array( 'received' => true ), 200 );
    }

    /**
     * Verify the HMAC-SHA256 signature of the webhook payload.
     *
     * @param string $payload   Raw request body.
     * @param string $signature Value of the X-Hub-Signature-256 header.
     * @param string $secret    Webhook secret.
     * @return bool True if the signature is valid.
     */
    public function verify_signature( $payload, $signature, $secret ) {
        $expected = 'sha256=' . hash_hmac( 'sha256', $payload, $secret );

        if ( function_exists( 'hash_equals' ) ) {
            return hash_equals( $expected, $signature );
        }

        return $expected === $signature;
    }

    /**
     * Process a workflow_run event from GitHub.
     *
     * @param array $data Webhook payload.
     */
    public function process_workflow_run( $data ) {
        $workflow_run = isset( $data['workflow_run'] ) ? $data['workflow_run'] : array();

        if ( empty( $workflow_run['id'] ) ) {
            return;
        }

        $run_id       = (int) $workflow_run['id'];
        $status       = isset( $workflow_run['status'] ) ? $workflow_run['status'] : '';
        $conclusion   = isset( $workflow_run['conclusion'] ) ? $workflow_run['conclusion'] : '';
        $repo_full    = isset( $workflow_run['repository']['full_name'] ) ? $workflow_run['repository']['full_name'] : '';
        $html_url     = isset( $workflow_run['html_url'] ) ? $workflow_run['html_url'] : '';

        $mapped_status = $this->map_conclusion( $status, $conclusion );

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE workflow_run_id = %d", $run_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            // Try to match by repo name and recent builds.
            if ( ! empty( $repo_full ) ) {
                $parts   = explode( '/', $repo_full );
                $owner   = isset( $parts[0] ) ? $parts[0] : '';
                $repo    = isset( $parts[1] ) ? $parts[1] : '';

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $build = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT * FROM {$table} WHERE repo_owner = %s AND repo_name = %s AND status IN ('pending', 'running') ORDER BY created_at DESC LIMIT 1",
                        $owner,
                        $repo
                    ),
                    ARRAY_A
                );
            }

            if ( ! $build ) {
                return;
            }
        }

        $update = array(
            'status' => $mapped_status,
        );

        if ( ! empty( $run_id ) && empty( $build['workflow_run_id'] ) ) {
            $update['workflow_run_id'] = $run_id;
        }

        if ( 'completed' === $mapped_status || 'failed' === $mapped_status ) {
            if ( ! empty( $html_url ) ) {
                $update['artifact_url'] = $html_url;
            }

            if ( 'failed' === $mapped_status && ! empty( $conclusion ) ) {
                $update['error_message'] = sprintf(
                    /* translators: 1: workflow conclusion, 2: run URL */
                    __( 'Workflow concluded with status: %1$s (%2$s)', 'pagepilot' ),
                    $conclusion,
                    $html_url
                );
            }
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table,
            $update,
            array( 'id' => (int) $build['id'] ),
            array( '%s', '%s', '%s', '%s' ),
            array( '%d' )
        );

        $this->maybe_notify_admin( (int) $build['id'], $mapped_status );
    }

    /**
     * Process a workflow_job event from GitHub.
     *
     * @param array $data Webhook payload.
     */
    public function process_workflow_job( $data ) {
        $job = isset( $data['workflow_job'] ) ? $data['workflow_job'] : array();

        if ( empty( $job['id'] ) ) {
            return;
        }

        $status    = isset( $job['status'] ) ? $job['status'] : '';
        $conclusion = isset( $job['conclusion'] ) ? $job['conclusion'] : '';
        $run_id    = isset( $job['run_id'] ) ? (int) $job['run_id'] : 0;

        if ( 0 === $run_id ) {
            return;
        }

        $mapped_status = $this->map_conclusion( $status, $conclusion );

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE workflow_run_id = %d", $run_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            return;
        }

        // Only update if the new status is more severe (e.g., failure overrides running).
        $priority = array(
            'pending'   => 0,
            'running'   => 1,
            'completed' => 2,
            'failed'    => 3,
            'cancelled' => 4,
        );

        $current_priority = isset( $priority[ $build['status'] ] ) ? $priority[ $build['status'] ] : 0;
        $new_priority     = isset( $priority[ $mapped_status ] ) ? $priority[ $mapped_status ] : 0;

        if ( $new_priority > $current_priority ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $table,
                array( 'status' => $mapped_status ),
                array( 'id' => (int) $build['id'] ),
                array( '%s' ),
                array( '%d' )
            );

            $this->maybe_notify_admin( (int) $build['id'], $mapped_status );
        }
    }

    /**
     * Send an admin email notification when a build completes or fails.
     *
     * @param int    $build_id Build record ID.
     * @param string $status   New build status.
     */
    public function maybe_notify_admin( $build_id, $status ) {
        if ( ! in_array( $status, array( 'completed', 'failed' ), true ) ) {
            return;
        }

        $notify = get_option( 'pagepilot_notify_admin', '1' );
        if ( '1' !== $notify ) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            return;
        }

        $admin_email = get_option( 'admin_email' );
        $site_name   = get_bloginfo( 'name' );

        if ( 'completed' === $status ) {
            $subject = sprintf(
                /* translators: 1: site name, 2: build repo */
                __( '[%1$s] Build #%2$d completed successfully', 'pagepilot' ),
                $site_name,
                $build_id
            );

            $message = sprintf(
                /* translators: 1: build ID, 2: repo owner/name, 3: branch, 4: commit SHA */
                __( "Build #%1\$d completed successfully.\n\nRepository: %2\$s\nBranch: %3\$s\nCommit: %4\$s\n\nView builds: %5\$s", 'pagepilot' ),
                $build_id,
                $build['repo_owner'] . '/' . $build['repo_name'],
                $build['branch'],
                $build['commit_sha'] ? substr( $build['commit_sha'], 0, 7 ) : 'N/A',
                admin_url( 'admin.php?page=pagepilot-builds' )
            );
        } else {
            $subject = sprintf(
                /* translators: 1: site name, 2: build repo */
                __( '[%1$s] Build from %2$s failed', 'pagepilot' ),
                $site_name,
                $build['repo_owner'] . '/' . $build['repo_name']
            );

            $error_msg = ! empty( $build['error_message'] ) ? $build['error_message'] : __( 'No error message available.', 'pagepilot' );

            $message = sprintf(
                /* translators: 1: build ID, 2: repo, 3: error message */
                __( "Build #%1\$d has failed.\n\nRepository: %2\$s\nError: %3\$s\n\nView builds: %4\$s", 'pagepilot' ),
                $build_id,
                $build['repo_owner'] . '/' . $build['repo_name'],
                $error_msg,
                admin_url( 'admin.php?page=pagepilot-builds' )
            );
        }

        wp_mail( $admin_email, $subject, $message );
    }

    /**
     * AJAX handler for admin UI build polling.
     */
    public function ajax_poll_build() {
        check_ajax_referer( 'pagepilot_ajax_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'pagepilot' ) ), 403 );
        }

        $build_id = isset( $_POST['build_id'] ) ? absint( $_POST['build_id'] ) : 0;

        if ( ! $build_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid build ID.', 'pagepilot' ) ), 400 );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            wp_send_json_error( array( 'message' => __( 'Build not found.', 'pagepilot' ) ), 404 );
        }

        // If the build is still running, query GitHub for the latest status.
        if ( in_array( $build['status'], array( 'pending', 'running' ), true ) && ! empty( $build['workflow_run_id'] ) ) {
            $builder = new PagePilot_Builder();
            $status  = $builder->get_build_status( $build_id );

            if ( ! is_wp_error( $status ) ) {
                $build['status'] = $status['status'];

                if ( ! empty( $status['html_url'] ) ) {
                    $build['artifact_url'] = $status['html_url'];
                }
            }
        }

        wp_send_json_success( $build );
    }

    /**
     * Map a GitHub workflow status and conclusion to a PagePilot build status.
     *
     * @param string $status     GitHub workflow status.
     * @param string $conclusion GitHub workflow conclusion.
     * @return string PagePilot status.
     */
    private function map_conclusion( $status, $conclusion ) {
        if ( 'completed' === $status ) {
            switch ( $conclusion ) {
                case 'success':
                    return 'completed';
                case 'failure':
                case 'timed_out':
                    return 'failed';
                case 'cancelled':
                case 'skipped':
                    return 'cancelled';
                default:
                    return 'completed';
            }
        }

        if ( 'in_progress' === $status ) {
            return 'running';
        }

        return 'pending';
    }
}
