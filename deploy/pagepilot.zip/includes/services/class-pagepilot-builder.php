<?php
/**
 * PagePilot Builder Orchestrator
 *
 * Generates configuration files from plugin settings, pushes them to GitHub,
 * and triggers GitHub Actions builds.
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_Builder {

    /**
     * Plugin settings.
     *
     * @var array
     */
    private $settings;

    /**
     * GitHub service instance.
     *
     * @var PagePilot_GitHub|null
     */
    private $github;

    /**
     * Flutter template directory path.
     *
     * @var string
     */
    private $template_dir;

    /**
     * Constructor. Loads settings and initializes GitHub service.
     */
    public function __construct() {
        $this->settings     = PagePilot_Activator::get_all_settings();
        $this->template_dir = PAGEPILOT_PLUGIN_DIR . 'templates/flutter-app/';

        $token = $this->get_setting( 'github_token' );
        if ( ! empty( $token ) ) {
            $this->github = new PagePilot_GitHub( $token );
        }
    }

    /**
     * Retrieve a single setting value.
     *
     * @param string $key     Setting key.
     * @param mixed  $default Default value.
     * @return mixed
     */
    private function get_setting( $key, $default = '' ) {
        return isset( $this->settings[ $key ] ) ? $this->settings[ $key ] : $default;
    }

    private function get_github_setting( $key, $default = '' ) {
        $github_settings = get_option( 'pagepilot_github_settings', array() );
        return isset( $github_settings[ $key ] ) ? $github_settings[ $key ] : $default;
    }

    /**
     * Generate the main app_config.dart file content from settings.
     *
     * @param array $settings Plugin settings.
     * @return string File content.
     */
    public function generate_app_config( $settings ) {
        $app_name        = $this->get_string( $settings, 'app_name', 'PagePilot App' );
        $primary_color   = $this->get_string( $settings, 'primary_color', '#6C63FF' );
        $secondary_color = $this->get_string( $settings, 'secondary_color', '#FF6584' );
        $accent_color    = $this->get_string( $settings, 'accent_color', '#00C9A7' );
        $bg_color        = $this->get_string( $settings, 'bg_color', '#FFFFFF' );
        $text_color      = $this->get_string( $settings, 'text_color', '#333333' );
        $splash_bg       = $this->get_string( $settings, 'splash_bg_color', '#6C63FF' );
        $package_name    = $this->get_string( $settings, 'package_name', 'com.pagepilot.app' );
        $app_version     = $this->get_string( $settings, 'app_version', '1.0.0' );
        $build_number    = $this->get_string( $settings, 'build_number', '1' );
        $site_url        = $this->get_string( $settings, 'site_url', home_url() );
        $lms_plugin      = $this->get_string( $settings, 'lms_plugin', '' );

        $enable_courses   = $this->get_bool_setting( $settings, 'enable_courses', true );
        $enable_wishlist  = $this->get_bool_setting( $settings, 'enable_wishlist', true );
        $enable_profile   = $this->get_bool_setting( $settings, 'enable_profile', true );
        $enable_quiz      = $this->get_bool_setting( $settings, 'enable_quiz', true );
        $enable_search    = $this->get_bool_setting( $settings, 'enable_search', true );
        $enable_dark_mode = $this->bool_to_dart( $this->get_bool_setting( $settings, 'enable_dark_mode', true ) );

        $primary_int   = $this->hex_to_int( $primary_color );
        $secondary_int = $this->hex_to_int( $secondary_color );
        $accent_int    = $this->hex_to_int( $accent_color );
        $bg_int        = $this->hex_to_int( $bg_color );
        $text_int      = $this->hex_to_int( $text_color );
        $splash_int    = $this->hex_to_int( $splash_bg );

        $api_url  = $this->escape_dart_string( rtrim( $site_url, '/' ) . '/wp-json' );

        $content = <<<DART
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Category {
  final String name;
  final String icon;
  final int? id;

  const Category({required this.name, this.icon = '', this.id});

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      name: json['name'] as String? ?? '',
      icon: json['icon'] as String? ?? '',
      id: json['id'] as int?,
    );
  }
}

class AppConfig {
  AppConfig._({
    required this.appName,
    required this.packageName,
    required this.primaryColor,
    required this.secondaryColor,
    required this.accentColor,
    required this.bgColor,
    required this.textColor,
    required this.primaryColorDark,
    this.logoAsset = '',
    this.appTagline = '',
    required this.siteUrl,
    required this.apiBaseUrl,
    this.wpBaseUrl = '',
    this.categories = const [],
    this.screens = const {},
    this.features = const {},
    this.enableGoogleLogin = true,
    this.enableFacebookLogin = true,
    this.showProfileTab = true,
    this.showSettingsTab = true,
  });

  static AppConfig? _instance;

  static AppConfig get instance {
    if (_instance == null) {
      throw StateError('AppConfig not initialized. Call AppConfig.load() first.');
    }
    return _instance!;
  }

  static AppConfig of(BuildContext context) {
    try {
      return Provider.of<AppConfig>(context, listen: false);
    } catch (_) {
      return instance;
    }
  }

  static Future<void> load() async {
    _instance = AppConfig._(
      appName: '{$this->escape_dart_string( $app_name )}',
      packageName: '{$this->escape_dart_string( $package_name )}',
      primaryColor: Color(0x{$primary_int}),
      secondaryColor: Color(0x{$secondary_int}),
      accentColor: Color(0x{$accent_int}),
      bgColor: Color(0x{$bg_int}),
      textColor: Color(0x{$text_int}),
      primaryColorDark: Color(0x{$primary_int}).withOpacity(0.8),
      siteUrl: '{$this->escape_dart_string( rtrim( $site_url, '/' ) )}',
      apiBaseUrl: '{$api_url}',
      wpBaseUrl: '{$this->escape_dart_string( rtrim( $site_url, '/' ) )}',
      logoAsset: '',
      appTagline: 'Learn anytime, anywhere',
      categories: [],
      screens: {
        'home': true,
        'courses': {$this->bool_to_dart( $enable_courses )},
        'wishlist': {$this->bool_to_dart( $enable_wishlist )},
        'profile': {$this->bool_to_dart( $enable_profile )},
        'quiz': {$this->bool_to_dart( $enable_quiz )},
        'search': {$this->bool_to_dart( $enable_search )},
        'settings': true,
      },
      features: {
        'darkMode': {$enable_dark_mode},
        'googleLogin': false,
        'facebookLogin': false,
      },
    );
  }

  factory AppConfig.fromJson(Map<String, dynamic> json) {
    return AppConfig._(
      appName: json['appName'] as String? ?? 'PagePilot',
      packageName: json['packageName'] as String? ?? 'com.pagepilot.app',
      primaryColor: _parseColor(json['primaryColor'] as String? ?? '#6C63FF'),
      secondaryColor: _parseColor(json['secondaryColor'] as String? ?? '#FF6584'),
      accentColor: _parseColor(json['accentColor'] as String? ?? '#00C9A7'),
      bgColor: _parseColor(json['bgColor'] as String? ?? '#FFFFFF'),
      textColor: _parseColor(json['textColor'] as String? ?? '#1E1E2D'),
      primaryColorDark: _parseColor(json['primaryColor'] as String? ?? '#6C63FF').withOpacity(0.8),
      siteUrl: json['siteUrl'] as String? ?? '',
      apiBaseUrl: json['apiBaseUrl'] as String? ?? '',
      wpBaseUrl: json['wpBaseUrl'] as String? ?? '',
      logoAsset: json['logoAsset'] as String? ?? '',
      appTagline: json['appTagline'] as String? ?? 'Learn anytime, anywhere',
      categories: (json['categories'] as List<dynamic>?)?.map((e) => Category.fromJson(e as Map<String, dynamic>)).toList() ?? [],
      screens: json['screens'] != null ? Map<String, bool>.from(json['screens'] as Map) : {},
      features: json['features'] != null ? Map<String, bool>.from(json['features'] as Map) : {},
      enableGoogleLogin: json['enableGoogleLogin'] as bool? ?? true,
      enableFacebookLogin: json['enableFacebookLogin'] as bool? ?? true,
      showProfileTab: json['showProfileTab'] as bool? ?? true,
      showSettingsTab: json['showSettingsTab'] as bool? ?? true,
    );
  }

  final String appName;
  final String packageName;
  final Color primaryColor;
  final Color secondaryColor;
  final Color accentColor;
  final Color bgColor;
  final Color textColor;
  final Color primaryColorDark;
  final String logoAsset;
  final String appTagline;
  final String siteUrl;
  final String apiBaseUrl;
  final String wpBaseUrl;
  final List<Category> categories;
  final Map<String, bool> screens;
  final Map<String, bool> features;
  final bool enableGoogleLogin;
  final bool enableFacebookLogin;
  final bool showProfileTab;
  final bool showSettingsTab;

  bool isScreenEnabled(String screenName) => screens[screenName] ?? false;
  bool isFeatureEnabled(String featureName) => features[featureName] ?? false;

  static Color _parseColor(String hex) {
    hex = hex.replaceFirst('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    return Color(int.parse(hex, radix: 16));
  }
}
DART;

        return $content;
    }

    /**
     * Generate pubspec.yaml content.
     *
     * @param array $settings Plugin settings.
     * @return string File content.
     */
    public function generate_pubspec( $settings ) {
        $app_name     = $this->get_string( $settings, 'app_name', 'pagepilot_app' );
        $app_version  = $this->get_string( $settings, 'app_version', '1.0.0' );
        $package_name = $this->get_string( $settings, 'package_name', 'com.pagepilot.app' );

        $slug = strtolower( preg_replace( '/[^a-zA-Z0-9]/', '_', $app_name ) );
        $slug = preg_replace( '/_+/', '_', $slug );

        $content = <<<YAML
name: {$slug}
description: A mobile app generated by PagePilot from WordPress LMS.
publish_to: 'none'
version: {$app_version}+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  http: ^1.1.0
  shared_preferences: ^2.2.0
  cached_network_image: ^3.3.0
  flutter_html: ^3.0.0-beta.2
  provider: ^6.1.0
  shimmer: ^3.0.0
  video_player: ^2.8.0
  permission_handler: ^11.0.0
  path_provider: ^2.1.0
  url_launcher: ^6.2.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
  assets:
    - assets/images/
    - assets/icons/
YAML;

        return $content;
    }

    /**
     * Generate Android build.gradle (app-level) content.
     *
     * @param array $settings Plugin settings.
     * @return string File content.
     */
    public function generate_android_config( $settings ) {
        $package_name = $this->get_string( $settings, 'package_name', 'com.pagepilot.app' );
        $app_version  = $this->get_string( $settings, 'app_version', '1.0.0' );
        $build_number = $this->get_string( $settings, 'build_number', '1' );

        $content = <<<GRADLE
plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
}

android {
    namespace "{$package_name}"
    compileSdk flutter.compileSdkVersion
    ndkVersion flutter.ndkVersion

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = '1.8'
    }

    sourceSets {
        main.java.srcDirs += 'src/main/kotlin'
    }

    defaultConfig {
        applicationId "{$package_name}"
        minSdk 21
        targetSdk flutter.targetSdkVersion
        versionCode {$build_number}
        versionName "{$app_version}"
    }

    buildTypes {
        release {
            signingConfig signingConfigs.debug
        }
    }
}

flutter {
    source '../..'
}
GRADLE;

        return $content;
    }

    /**
     * Generate iOS Info.plist content.
     *
     * @param array $settings Plugin settings.
     * @return string File content.
     */
    public function generate_ios_config( $settings ) {
        $app_name    = $this->get_string( $settings, 'app_name', 'PagePilot' );
        $app_version = $this->get_string( $settings, 'app_version', '1.0.0' );

        $escaped_name = $this->escape_xml( $app_name );

        $content = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key>
	<string>$(DEVELOPMENT_LANGUAGE)</string>
	<key>CFBundleDisplayName</key>
	<string>{$escaped_name}</string>
	<key>CFBundleExecutable</key>
	<string>$(EXECUTABLE_NAME)</string>
	<key>CFBundleIdentifier</key>
	<string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
	<key>CFBundleInfoDictionaryVersion</key>
	<string>6.0</string>
	<key>CFBundleName</key>
	<string>{$escaped_name}</string>
	<key>CFBundlePackageType</key>
	<string>APPL</string>
	<key>CFBundleShortVersionString</key>
	<string>{$app_version}</string>
	<key>CFBundleSignature</key>
	<string>????</string>
	<key>CFBundleVersion</key>
	<string>1</string>
	<key>LSRequiresIPhoneOS</key>
	<true/>
	<key>UILaunchStoryboardName</key>
	<string>LaunchScreen</string>
	<key>UIMainStoryboardFile</key>
	<string>Main</string>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
	<key>NSAppTransportSecurity</key>
	<dict>
		<key>NSAllowsArbitraryLoads</key>
		<true/>
	</dict>
	<key>NSPhotoLibraryUsageDescription</key>
	<string>This app needs access to your photo library to upload profile pictures.</string>
	<key>NSCameraUsageDescription</key>
	<string>This app needs access to your camera to take profile pictures.</string>
</dict>
</plist>
XML;

        return $content;
    }

    /**
     * Prepare all template files by reading the Flutter template, replacing
     * config files with generated versions, and copying assets.
     *
     * @param array $settings Plugin settings.
     * @return array|WP_Error Associative array of file_path => content, or WP_Error on failure.
     */
    public function prepare_template_files( $settings ) {
        $files = array();

        $template_dir = $this->template_dir;

        if ( ! is_dir( $template_dir ) ) {
            return new WP_Error(
                'pagepilot_template_missing',
                __( 'Flutter template directory not found.', 'pagepilot' )
            );
        }

        // Recursively read all files in the template directory.
        $template_files = $this->get_directory_files( $template_dir );

        if ( empty( $template_files ) ) {
            return new WP_Error(
                'pagepilot_template_empty',
                __( 'Flutter template directory is empty.', 'pagepilot' )
            );
        }

        foreach ( $template_files as $file_path ) {
            $relative_path = str_replace( $template_dir, '', $file_path );
            $relative_path = ltrim( $relative_path, '/' );

            // Skip directories and .git files (but not .github).
            $parts = explode( '/', $relative_path );
            if ( is_dir( $file_path ) || ( '.' === $parts[0] && 'github' !== ( $parts[1] ?? '' ) ) ) {
                continue;
            }

        // Replace generated config files.
        if ( 'lib/config/app_config.dart' === $relative_path ) {
            $files[ $relative_path ] = $this->generate_app_config( $settings );
            continue;
        }

        if ( 'pubspec.yaml' === $relative_path ) {
            $files[ $relative_path ] = $this->generate_pubspec( $settings );
            continue;
        }

        if ( 'android/app/build.gradle' === $relative_path ) {
            $files[ $relative_path ] = $this->generate_android_config( $settings );
            continue;
        }

        if ( 'ios/Runner/Info.plist' === $relative_path ) {
            $files[ $relative_path ] = $this->generate_ios_config( $settings );
            continue;
        }

        // Copy other files as-is.
        $content = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        if ( false !== $content ) {
            $files[ $relative_path ] = $content;
        }
    }

    // Inject build config file — triggers the workflow on push.
    // Timestamp ensures unique content so GitHub detects the change.
    $files['.pagepilot-build.json'] = wp_json_encode( array(
        'trigger_id'            => wp_generate_uuid4(),
        'platform'              => $this->get_string( $settings, 'platform', 'android' ),
        'app_name'              => $this->get_string( $settings, 'app_name', 'PagePilot' ),
        'package_name'          => $this->get_string( $settings, 'package_name', 'com.pagepilot.app' ),
        'primary_color'         => $this->get_string( $settings, 'primary_color', '#4F46E5' ),
        'api_url'               => $this->get_string( $settings, 'site_url', home_url( '/wp-json' ) ),
        'build_number'          => $this->get_string( $settings, 'build_number', '1' ),
        'appetize_token'        => $this->get_github_setting( 'appetize_token' ),
        'appetize_android_key'  => $this->get_github_setting( 'appetize_android_key' ),
        'appetize_ios_key'      => $this->get_github_setting( 'appetize_ios_key' ),
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . "\n";

    return $files;
    }

    /**
     * Push prepared files to the user's GitHub repository.
     *
     * @param array $settings Plugin settings (must include github_owner, github_repo, github_branch).
     * @return string|WP_Error Commit SHA on success, WP_Error on failure.
     */
    public function push_to_github( $settings ) {
        if ( ! $this->github ) {
            return new WP_Error(
                'pagepilot_no_github',
                __( 'GitHub is not connected. Please connect your account first.', 'pagepilot' )
            );
        }

        $repo_owner = $this->get_string( $settings, 'github_owner', '' );
        $repo_name  = $this->get_string( $settings, 'github_repo', '' );
        $branch     = $this->get_string( $settings, 'github_branch', 'main' );

        if ( empty( $repo_owner ) || empty( $repo_name ) ) {
            return new WP_Error(
                'pagepilot_missing_repo',
                __( 'GitHub repository owner and name are required.', 'pagepilot' )
            );
        }

        $files = $this->prepare_template_files( $settings );

        if ( is_wp_error( $files ) ) {
            return $files;
        }

        $app_name = $this->get_string( $settings, 'app_name', 'PagePilot' );
        $commit_message = sprintf(
            /* translators: %s: app name */
            __( 'Update PagePilot generated files for %s', 'pagepilot' ),
            $app_name
        );

        $result = $this->github->push_files( $repo_owner, $repo_name, $branch, $files, $commit_message );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $result;
    }

    /**
     * Orchestrate a full build: prepare files, push to GitHub, trigger Actions workflow.
     *
     * @param array $settings Plugin settings.
     * @return array|WP_Error Array with build_id and status on success, WP_Error on failure.
     */
    public function trigger_build( $settings ) {
        $repo_owner = $this->get_string( $settings, 'github_owner', '' );
        $repo_name  = $this->get_string( $settings, 'github_repo', '' );
        $branch     = $this->get_string( $settings, 'github_branch', 'main' );
        $platform   = $this->get_string( $settings, 'platform', 'android' );

        if ( empty( $repo_owner ) || empty( $repo_name ) ) {
            return new WP_Error(
                'pagepilot_missing_repo',
                __( 'GitHub repository is not configured.', 'pagepilot' )
            );
        }

        if ( ! $this->github ) {
            return new WP_Error(
                'pagepilot_no_github',
                __( 'GitHub is not connected.', 'pagepilot' )
            );
        }

        // Push files to the repository (includes .pagepilot-build.json which triggers the workflow).
        $commit_sha = $this->push_to_github( $settings );

        if ( is_wp_error( $commit_sha ) ) {
            $this->save_build(
                array(
                    'repo_owner'    => $repo_owner,
                    'repo_name'     => $repo_name,
                    'branch'        => $branch,
                    'status'        => 'failed',
                    'error_message' => $commit_sha->get_error_message(),
                    'build_config'  => wp_json_encode( $settings ),
                )
            );
            return $commit_sha;
        }

        // The push of .pagepilot-build.json triggers the workflow. No separate dispatch needed.
        $workflow_run_id = $this->get_latest_workflow_run_id( $repo_owner, $repo_name );

        $build_data = array(
            'repo_owner'      => $repo_owner,
            'repo_name'       => $repo_name,
            'branch'          => $branch,
            'commit_sha'      => $commit_sha,
            'status'          => $workflow_run_id ? 'running' : 'pushed',
            'workflow_run_id' => $workflow_run_id,
            'build_config'    => wp_json_encode( $settings ),
        );

        $build_id = $this->save_build( $build_data );

        return array(
            'build_id'        => $build_id,
            'commit_sha'      => $commit_sha,
            'workflow_run_id' => $workflow_run_id,
            'status'          => 'running',
        );
    }

    /**
     * Get the status of a build from the GitHub Actions API.
     *
     * @param int $build_id Build record ID.
     * @return array|WP_Error Status data on success, WP_Error on failure.
     */
    public function get_build_status( $build_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            return new WP_Error(
                'pagepilot_build_not_found',
                __( 'Build not found.', 'pagepilot' )
            );
        }

        if ( empty( $build['workflow_run_id'] ) ) {
            return array(
                'id'     => $build_id,
                'status' => $build['status'],
            );
        }

        if ( ! $this->github ) {
            $token = $this->get_setting( 'github_token' );
            if ( ! empty( $token ) ) {
                $this->github = new PagePilot_GitHub( $token );
            }
        }

        $response = wp_remote_get(
            'https://api.github.com/repos/' . rawurlencode( $build['repo_owner'] ) . '/' . rawurlencode( $build['repo_name'] ) . '/actions/runs/' . absint( $build['workflow_run_id'] ),
            array(
                'headers' => array(
                    'Authorization' => 'token ' . $this->get_setting( 'github_token' ),
                    'Accept'        => 'application/vnd.github.v3+json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'github_api_error',
                sprintf( __( 'GitHub API returned HTTP %d.', 'pagepilot' ), $code )
            );
        }

        $data   = json_decode( wp_remote_retrieve_body( $response ), true );
        $status = $this->map_workflow_status( $data['status'] );

        // Update the database if status changed.
        if ( $status !== $build['status'] ) {
            $update_data = array( 'status' => $status );

            if ( 'completed' === $status || 'failed' === $status ) {
                $update_data['artifact_url'] = $this->extract_artifact_url( $data );
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update( $table, $update_data, array( 'id' => $build_id ) );
        }

        return array(
            'id'            => $build_id,
            'status'        => $status,
            'conclusion'    => isset( $data['conclusion'] ) ? $data['conclusion'] : '',
            'html_url'      => isset( $data['html_url'] ) ? $data['html_url'] : '',
            'run_started_at' => isset( $data['run_started_at'] ) ? $data['run_started_at'] : '',
        );
    }

    /**
     * Get download URLs for build artifacts.
     *
     * @param int $build_id Build record ID.
     * @return array|WP_Error Array of artifact URLs on success, WP_Error on failure.
     */
    public function get_artifacts( $build_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $build = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ),
            ARRAY_A
        );

        if ( ! $build ) {
            return new WP_Error(
                'pagepilot_build_not_found',
                __( 'Build not found.', 'pagepilot' )
            );
        }

        if ( empty( $build['workflow_run_id'] ) ) {
            return array();
        }

        $response = wp_remote_get(
            'https://api.github.com/repos/' . rawurlencode( $build['repo_owner'] ) . '/' . rawurlencode( $build['repo_name'] ) . '/actions/runs/' . absint( $build['workflow_run_id'] ) . '/artifacts',
            array(
                'headers' => array(
                    'Authorization' => 'token ' . $this->get_setting( 'github_token' ),
                    'Accept'        => 'application/vnd.github.v3+json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'github_api_error',
                sprintf( __( 'GitHub API returned HTTP %d.', 'pagepilot' ), $code )
            );
        }

        $data      = json_decode( wp_remote_retrieve_body( $response ), true );
        $artifacts = array();

        if ( ! empty( $data['artifacts'] ) ) {
            foreach ( $data['artifacts'] as $artifact ) {
                $artifacts[] = array(
                    'name'                => $artifact['name'],
                    'size_in_bytes'       => $artifact['size_in_bytes'],
                    'archive_download_url' => $artifact['archive_download_url'],
                    'expired'             => $artifact['expired'],
                );
            }
        }

        return $artifacts;
    }

    /**
     * Save a build record to the pagepilot_builds table.
     *
     * @param array $data Build data.
     * @return int|false Insert ID on success, false on failure.
     */
    public function save_build( $data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        $insert = array(
            'repo_owner'      => isset( $data['repo_owner'] ) ? sanitize_text_field( $data['repo_owner'] ) : '',
            'repo_name'       => isset( $data['repo_name'] ) ? sanitize_text_field( $data['repo_name'] ) : '',
            'branch'          => isset( $data['branch'] ) ? sanitize_text_field( $data['branch'] ) : 'main',
            'commit_sha'      => isset( $data['commit_sha'] ) ? sanitize_text_field( $data['commit_sha'] ) : '',
            'status'          => isset( $data['status'] ) ? sanitize_text_field( $data['status'] ) : 'pending',
            'workflow_run_id' => isset( $data['workflow_run_id'] ) ? absint( $data['workflow_run_id'] ) : null,
            'artifact_url'    => isset( $data['artifact_url'] ) ? esc_url_raw( $data['artifact_url'] ) : null,
            'error_message'   => isset( $data['error_message'] ) ? sanitize_text_field( $data['error_message'] ) : null,
            'build_config'    => isset( $data['build_config'] ) ? wp_json_encode( json_decode( $data['build_config'], true ) ) : null,
        );

        $format = array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->insert( $table, $insert, $format );

        if ( false === $result ) {
            return false;
        }

        return $wpdb->insert_id;
    }

    /**
     * Get build history with optional filtering and pagination.
     *
     * @param array $args Query arguments (page, per_page, status).
     * @return array Array of builds with pagination metadata.
     */
    public function get_builds( $args = array() ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';

        $defaults = array(
            'page'     => 1,
            'per_page' => 20,
            'status'   => '',
        );

        $args  = wp_parse_args( $args, $defaults );
        $page  = max( 1, (int) $args['page'] );
        $limit = max( 1, min( 100, (int) $args['per_page'] ) );
        $offset = ( $page - 1 ) * $limit;

        $where = '1=1';
        $query_args = array();

        if ( ! empty( $args['status'] ) ) {
            $valid_statuses = array( 'pending', 'running', 'completed', 'failed', 'cancelled' );
            $status = sanitize_text_field( $args['status'] );

            if ( in_array( $status, $valid_statuses, true ) ) {
                $where  .= ' AND status = %s';
                $query_args[] = $status;
            }
        }

        // Count total records.
        $count_query = "SELECT COUNT(*) FROM {$table} WHERE {$where}";

        if ( ! empty( $query_args ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $total = (int) $wpdb->get_var( $wpdb->prepare( $count_query, ...$query_args ) );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $total = (int) $wpdb->get_var( $count_query );
        }

        // Fetch results.
        $select_query = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $query_args[] = $limit;
        $query_args[] = $offset;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $builds = $wpdb->get_results(
            $wpdb->prepare( $select_query, ...$query_args ),
            ARRAY_A
        );

        return array(
            'builds'    => $builds ? $builds : array(),
            'total'     => $total,
            'page'      => $page,
            'per_page'  => $limit,
            'total_pages' => (int) ceil( $total / $limit ),
        );
    }

    /**
     * Get the most recent builds.
     *
     * @param int $count Number of builds to retrieve.
     * @return array Array of build records.
     */
    public function get_recent_builds( $count = 5 ) {
        global $wpdb;
        $table  = $wpdb->prefix . 'pagepilot_builds';
        $count  = absint( $count );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $builds = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d", $count ),
            ARRAY_A
        );

        return $builds ? $builds : array();
    }

    // -------------------------------------------------------------------------
    // Private helpers.
    // -------------------------------------------------------------------------

    /**
     * Recursively list all files in a directory.
     *
     * @param string $dir Directory path.
     * @return array List of file paths.
     */
    private function get_directory_files( $dir ) {
        $files = array();

        if ( ! is_dir( $dir ) ) {
            return $files;
        }

        $items = scandir( $dir );

        foreach ( $items as $item ) {
            if ( '.' === $item || '..' === $item ) {
                continue;
            }

            $path = $dir . '/' . $item;

            if ( is_dir( $path ) ) {
                $files = array_merge( $files, $this->get_directory_files( $path ) );
            } else {
                $files[] = $path;
            }
        }

        return $files;
    }

    /**
     * Safely retrieve a string value from an array.
     *
     * @param array  $data    Source array.
     * @param string $key     Key to retrieve.
     * @param string $default Default value.
     * @return string
     */
    private function get_string( $data, $key, $default = '' ) {
        return isset( $data[ $key ] ) ? (string) $data[ $key ] : $default;
    }

    /**
     * Safely retrieve a boolean value from an array.
     *
     * @param array  $data    Source array.
     * @param string $key     Key to retrieve.
     * @param bool   $default Default value.
     * @return bool
     */
    private function get_bool_setting( $data, $key, $default = false ) {
        if ( ! isset( $data[ $key ] ) ) {
            return $default;
        }
        return in_array( $data[ $key ], array( true, 1, '1', 'true', 'yes' ), true );
    }

    /**
     * Convert a hex color to a 32-bit integer for Dart.
     *
     * @param string $hex Hex color code.
     * @return string Integer string.
     */
    private function hex_to_int( $hex ) {
        $hex = str_replace( '#', '', $hex );
        if ( strlen( $hex ) < 6 ) {
            $hex = str_pad( $hex, 6, '0' );
        }
        $hex = 'FF' . $hex;
        return strtoupper( $hex );
    }

    /**
     * Convert a PHP boolean to a Dart boolean string.
     *
     * @param bool $value Boolean value.
     * @return string 'true' or 'false'.
     */
    private function bool_to_dart( $value ) {
        return $value ? 'true' : 'false';
    }

    /**
     * Escape a string for use in Dart source code.
     *
     * @param string $str Input string.
     * @return string Escaped string.
     */
    private function escape_dart_string( $str ) {
        return addcslashes( $str, "'\"\\" );
    }

    /**
     * Escape a string for use in XML.
     *
     * @param string $str Input string.
     * @return string Escaped string.
     */
    private function escape_xml( $str ) {
        return htmlspecialchars( $str, ENT_XML1, 'UTF-8' );
    }

    /**
     * Map a GitHub workflow status to a PagePilot build status.
     *
     * @param string $workflow_status GitHub workflow status.
     * @return string PagePilot status.
     */
    private function map_workflow_status( $workflow_status ) {
        $map = array(
            'queued'    => 'pending',
            'in_progress' => 'running',
            'completed' => 'completed',
            'waiting'   => 'pending',
            'requested' => 'pending',
        );

        return isset( $map[ $workflow_status ] ) ? $map[ $workflow_status ] : 'pending';
    }

    /**
     * Extract the artifact download URL from a workflow run response.
     *
     * @param array $data GitHub workflow run data.
     * @return string|null Artifact URL or null.
     */
    private function extract_artifact_url( $data ) {
        if ( ! empty( $data['artifacts_url'] ) ) {
            return $data['artifacts_url'];
        }

        return null;
    }

    /**
     * Retrieve the latest workflow run ID for a repository.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @return int|null Workflow run ID or null.
     */
    private function get_latest_workflow_run_id( $owner, $repo ) {
        $response = wp_remote_get(
            'https://api.github.com/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/actions/runs?per_page=1&created=>=' . gmdate( 'Y-m-d\TH:i:s', time() - 60 ),
            array(
                'headers' => array(
                    'Authorization' => 'token ' . $this->get_setting( 'github_token' ),
                    'Accept'        => 'application/vnd.github.v3+json',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return null;
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! empty( $data['workflow_runs'][0]['id'] ) ) {
            return (int) $data['workflow_runs'][0]['id'];
        }

        return null;
    }

    /**
     * Send a POST request via wp_remote_request (works because push_files already uses POST for blobs).
     *
     * @param string $url  Request URL.
     * @param string $auth Authorization header value.
     * @param string $body JSON body.
     * @return true|WP_Error True on success.
     */
    private function dispatch_via_curl( $url, $auth, $body ) {
        $response = wp_remote_request( $url, array(
            'method'  => 'POST',
            'headers' => array(
                'Authorization' => 'token ' . $auth,
                'Accept'        => 'application/vnd.github.v3+json',
                'Content-Type'  => 'application/json',
                'User-Agent'    => 'PagePilot-WordPress/' . PAGEPILOT_VERSION,
            ),
            'body'    => $body,
            'timeout' => 30,
        ) );

        if ( is_wp_error( $response ) ) {
            error_log( '[PagePilot] dispatch error: ' . $response->get_error_message() );
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );

        error_log( '[PagePilot] dispatch_via_curl http_code=' . $code );

        if ( $code >= 200 && $code < 300 ) {
            return true;
        }

        return new WP_Error( 'http_error', sprintf( 'HTTP %d: %s', $code, wp_remote_retrieve_body( $response ) ) );
    }
}
