<?php
/**
 * PagePilot Admin - Main Admin Class
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class PagePilot_Admin
 *
 * Main admin class that registers menus, enqueues assets, and renders submenu pages.
 */
class PagePilot_Admin {

    /**
     * Plugin version.
     *
     * @var string
     */
    private $version;

    /**
     * Plugin file path.
     *
     * @var string
     */
    private $plugin_file;

    /**
     * Admin slug prefix.
     *
     * @var string
     */
    const SLUG = 'pagepilot';

    /**
     * Capabilities needed.
     *
     * @var string
     */
    const CAPABILITY = 'manage_options';

    /**
     * Constructor.
     *
     * @param string $version     Plugin version.
     * @param string $plugin_file Plugin main file path.
     */
    public function __construct( $version, $plugin_file ) {
        $this->version     = $version;
        $this->plugin_file = $plugin_file;

        add_action( 'admin_menu', array( $this, 'register_menus' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Register admin menu and submenu pages.
     */
    public function register_menus() {
        add_menu_page(
            __( 'PagePilot', 'pagepilot' ),
            __( 'PagePilot', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG,
            array( $this, 'render_dashboard' ),
            'dashicons-smartphone',
            80
        );

        add_submenu_page(
            self::SLUG,
            __( 'Dashboard', 'pagepilot' ),
            __( 'Dashboard', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG,
            array( $this, 'render_dashboard' )
        );

        add_submenu_page(
            self::SLUG,
            __( 'LMS Settings', 'pagepilot' ),
            __( 'LMS Settings', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG . '-lms',
            array( $this, 'render_lms_settings' )
        );

        add_submenu_page(
            self::SLUG,
            __( 'App Settings', 'pagepilot' ),
            __( 'App Settings', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG . '-settings',
            array( $this, 'render_app_settings' )
        );

        add_submenu_page(
            self::SLUG,
            __( 'GitHub Settings', 'pagepilot' ),
            __( 'GitHub Settings', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG . '-github',
            array( $this, 'render_github_settings' )
        );

        add_submenu_page(
            self::SLUG,
            __( 'Builds', 'pagepilot' ),
            __( 'Builds', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG . '-builds',
            array( $this, 'render_builds' )
        );

        add_submenu_page(
            self::SLUG,
            __( 'Documentation', 'pagepilot' ),
            __( 'Documentation', 'pagepilot' ),
            self::CAPABILITY,
            self::SLUG . '-docs',
            array( $this, 'render_docs' )
        );
    }

    /**
     * Enqueue admin styles and scripts only on PagePilot pages.
     *
     * @param string $hook_suffix The current admin page hook suffix.
     */
    public function enqueue_assets( $hook_suffix ) {
        if ( ! isset( $_GET['page'] ) || strpos( sanitize_text_field( wp_unslash( $_GET['page'] ) ), 'pagepilot' ) !== 0 ) {
            return;
        }

        wp_enqueue_style(
            'pagepilot-admin',
            plugins_url( 'assets/css/admin.css', $this->plugin_file ),
            array(),
            filemtime( dirname( $this->plugin_file ) . '/assets/css/admin.css' )
        );

        wp_enqueue_script(
            'pagepilot-admin',
            plugins_url( 'assets/js/admin.js', $this->plugin_file ),
            array( 'jquery' ),
            filemtime( dirname( $this->plugin_file ) . '/assets/js/admin.js' ),
            true
        );

        wp_enqueue_media();
        wp_enqueue_style( 'wp-color-picker' );

        $rest_base = home_url( '/wp-json/pagepilot/v1' );

        $js_data = array(
            'rest_nonce'        => wp_create_nonce( 'wp_rest' ),
            'rest_url'          => $rest_base,
            'admin_url'         => admin_url(),
            'ajax_url'          => admin_url( 'admin-ajax.php' ),
            'ajax_nonce'        => wp_create_nonce( 'pagepilot_ajax_nonce' ),
            'detected_plugins'  => $this->get_detected_plugins(),
            'settings'          => $this->get_current_settings(),
            'github_settings'   => $this->get_github_settings_safe(),
            'builds'            => $this->get_recent_builds( 5 ),
            'plugin_version'    => $this->version,
            'strings'           => array(
                'confirm_build'     => __( 'Are you sure you want to start a new build?', 'pagepilot' ),
                'build_started'     => __( 'Build started successfully!', 'pagepilot' ),
                'build_failed'      => __( 'Build failed to start.', 'pagepilot' ),
                'settings_saved'    => __( 'Settings saved successfully!', 'pagepilot' ),
                'settings_error'    => __( 'Error saving settings.', 'pagepilot' ),
                'loading'           => __( 'Loading...', 'pagepilot' ),
                'no_builds'         => __( 'No builds found.', 'pagepilot' ),
                'confirm_delete'    => __( 'Are you sure?', 'pagepilot' ),
                'copied'            => __( 'Copied to clipboard!', 'pagepilot' ),
            ),
        );

        wp_localize_script( 'pagepilot-admin', 'PagePilot', $js_data );
    }

    /**
     * Render the Dashboard page.
     */
    public function render_dashboard() {
        $dashboard = new PagePilot_Admin_Dashboard( $this->version, $this->plugin_file );
        $dashboard->render();
    }

    /**
     * Render the LMS Settings page.
     */
    public function render_lms_settings() {
        $settings = new PagePilot_Admin_Settings( $this->version, $this->plugin_file );
        $settings->render( 'lms' );
    }

    /**
     * Render the App Settings page.
     */
    public function render_app_settings() {
        $settings = new PagePilot_Admin_Settings( $this->version, $this->plugin_file );
        $settings->render( 'app' );
    }

    /**
     * Render the GitHub Settings page.
     */
    public function render_github_settings() {
        $settings = new PagePilot_Admin_Settings( $this->version, $this->plugin_file );
        $settings->render( 'github' );
    }

    /**
     * Render the Builds page.
     */
    public function render_builds() {
        $builds = new PagePilot_Admin_Builds( $this->version, $this->plugin_file );
        $builds->render();
    }

    /**
     * Render the Documentation page.
     */
    public function render_docs() {
        $docs = new PagePilot_Admin_Docs( $this->version, $this->plugin_file );
        $docs->render();
    }

    /**
     * Get list of detected LMS and membership plugins.
     *
     * @return array Detected plugins.
     */
    public function get_detected_plugins() {
        $detected = array(
            'lms'        => array(),
            'membership' => array(),
        );

        $lms_plugins = array(
            'learnpress/learnpress.php'            => 'LearnPress',
            'lifterlms/lifterlms.php'              => 'LifterLMS',
            'sensei-lms/sensei-lms.php'            => 'Sensei LMS',
            'learn-dash/learndash.php'             => 'LearnDash',
            'masterstudy-lms/masterstudy-lms.php'  => 'MasterStudy LMS',
            'tutor/tutor.php'                      => 'Tutor LMS',
            'wp-courseware/wp-courseware.php'       => 'WP Courseware',
            'smart-courses/smart-courses.php'      => 'Smart Courses',
        );

        $membership_plugins = array(
            'woocommerce-memberships/woocommerce-memberships.php' => 'WooCommerce Memberships',
            'memberpress/memberpress.php'                         => 'MemberPress',
            'paid-memberships-pro/paid-memberships-pro.php'       => 'Paid Memberships Pro',
            'restrict-content/restrict-content.php'               => 'Restrict Content',
            's2member/s2member.php'                               => 's2Member',
            'membership/membership.php'                           => 'Membership',
        );

        foreach ( $lms_plugins as $path => $name ) {
            if ( file_exists( WP_PLUGIN_DIR . '/' . $path ) ) {
                $is_active = is_plugin_active( $path );
                $detected['lms'][] = array(
                    'name'    => $name,
                    'slug'    => dirname( $path ),
                    'path'    => $path,
                    'active'  => $is_active,
                );
            }
        }

        foreach ( $membership_plugins as $path => $name ) {
            if ( file_exists( WP_PLUGIN_DIR . '/' . $path ) ) {
                $is_active = is_plugin_active( $path );
                $detected['membership'][] = array(
                    'name'    => $name,
                    'slug'    => dirname( $path ),
                    'path'    => $path,
                    'active'  => $is_active,
                );
            }
        }

        return $detected;
    }

    /**
     * Get current PagePilot settings from database.
     *
     * @return array Settings array.
     */
    public function get_current_settings() {
        $defaults = array(
            'lms_plugin'       => '',
            'app_name'         => get_bloginfo( 'name' ),
            'package_name'     => 'com.pagepilot.app',
            'app_version'      => '1.0.0',
            'build_number'     => '1',
            'primary_color'    => '#0073aa',
            'secondary_color'  => '#005177',
            'accent_color'     => '#00aadc',
            'background_color' => '#ffffff',
            'text_color'       => '#333333',
            'logo_url'         => '',
            'splash_url'       => '',
            'screen_courses'   => '1',
            'screen_wishlist'  => '1',
            'screen_profile'   => '1',
            'screen_quiz'      => '1',
            'screen_search'    => '1',
            'dark_mode'        => '0',
            'push_notifications' => '0',
            'social_login'     => '0',
            'offline_mode'     => '0',
        );

        $saved = get_option( 'pagepilot_settings', array() );

        return wp_parse_args( $saved, $defaults );
    }

    /**
     * Get GitHub connection settings.
     *
     * @return array GitHub settings.
     */
    public function get_github_settings() {
        $defaults = array(
            'token'          => '',
            'repository'     => '',
            'branch'         => 'main',
            'connected'      => false,
            'api_endpoint'   => '',
            'auth_method'    => 'jwt',
            'custom_headers' => '',
        );

        $saved = get_option( 'pagepilot_github_settings', array() );

        return wp_parse_args( $saved, $defaults );
    }

    /**
     * Get GitHub settings safe for JS output (no token).
     *
     * @return array GitHub settings without token.
     */
    public function get_github_settings_safe() {
        $settings = $this->get_github_settings();
        unset( $settings['token'] );
        $settings['has_token'] = ! empty( $this->get_github_settings()['token'] );
        return $settings;
    }

    /**
     * Get recent builds.
     *
     * @param int $limit Number of builds to retrieve.
     * @return array Recent builds.
     */
    public function get_recent_builds( $limit = 5 ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'pagepilot_builds';

        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
            return array();
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $builds = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );

        return $builds ? $builds : array();
    }

    /**
     * Get plugin version.
     *
     * @return string
     */
    public function get_version() {
        return $this->version;
    }
}
