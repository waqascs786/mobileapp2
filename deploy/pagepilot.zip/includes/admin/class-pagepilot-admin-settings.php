<?php
/**
 * PagePilot Admin - Settings Page
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class PagePilot_Admin_Settings
 *
 * Renders settings pages with tabs for LMS, App, and GitHub configuration.
 */
class PagePilot_Admin_Settings {

    /**
     * Plugin version.
     *
     * @var string
     */
    private $version;

    /**
     * Plugin file path.
     *
     * @var string
     */
    private $plugin_file;

    /**
     * Current settings.
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor.
     *
     * @param string $version     Plugin version.
     * @param string $plugin_file Plugin main file path.
     */
    public function __construct( $version, $plugin_file ) {
        $this->version     = $version;
        $this->plugin_file = $plugin_file;
        $this->settings    = get_option( 'pagepilot_settings', array() );

        add_action( 'wp_ajax_pagepilot_save_settings', array( $this, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_pagepilot_sync_courses', array( $this, 'ajax_sync_courses' ) );
        add_action( 'wp_ajax_pagepilot_preview_courses', array( $this, 'ajax_preview_courses' ) );
        add_action( 'wp_ajax_pagepilot_preview_course_detail', array( $this, 'ajax_preview_course_detail' ) );
        add_action( 'wp_ajax_pagepilot_preview_lessons', array( $this, 'ajax_preview_lessons' ) );

        // Prevent CDN/proxy from caching admin pages (breaks live preview).
        add_action( 'admin_page_hooks', array( $this, 'send_no_cache_headers' ) );
    }

    /**
     * Send no-cache headers for PagePilot admin pages.
     */
    public function send_no_cache_headers() {
        if ( ! is_admin() ) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification
        $page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
        if ( 0 === strpos( $page, 'pagepilot' ) ) {
            header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
            header( 'Pragma: no-cache' );
            header( 'Expires: Thu, 01 Jan 1970 00:00:00 GMT' );
            header( 'X-PagePilot-Cache-Bust: ' . time() );
        }
    }

    /**
     * Render the settings page.
     *
     * @param string $active_tab The active tab identifier.
     */
    public function render( $active_tab = 'lms' ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'pagepilot' ) );
        }

        $tabs = array(
            'lms'      => __( 'LMS', 'pagepilot' ),
            'app'      => __( 'App Settings', 'pagepilot' ),
            'github'   => __( 'GitHub Settings', 'pagepilot' ),
            'advanced' => __( 'Advanced', 'pagepilot' ),
        );

        ?>
        <div class="wrap pagepilot-wrap pagepilot-settings">
            <h1><?php esc_html_e( 'PagePilot Settings', 'pagepilot' ); ?></h1>

            <?php settings_errors( 'pagepilot_settings' ); ?>

            <nav class="nav-tab-wrapper pagepilot-tabs">
                <?php foreach ( $tabs as $tab_id => $tab_label ) : ?>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot-settings&tab=' . $tab_id ) ); ?>"
                       class="nav-tab <?php echo $active_tab === $tab_id ? 'nav-tab-active' : ''; ?>">
                        <?php echo esc_html( $tab_label ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="pagepilot-tab-content">
                <form id="pagepilot-settings-form" method="post">
                    <?php wp_nonce_field( 'pagepilot_settings_nonce', 'pagepilot_nonce' ); ?>
                    <input type="hidden" name="action" value="pagepilot_save_settings" />
                    <input type="hidden" name="active_tab" value="<?php echo esc_attr( $active_tab ); ?>" />

                    <?php
                    switch ( $active_tab ) {
                        case 'lms':
                            $this->render_lms_tab();
                            break;
                        case 'app':
                            $this->render_app_tab();
                            break;
                        case 'github':
                            $this->render_github_tab();
                            break;
                        case 'advanced':
                            $this->render_advanced_tab();
                            break;
                    }
                    ?>

                    <?php if ( ! in_array( $active_tab, array( 'advanced', 'github' ), true ) ) : ?>
                        <div class="pagepilot-settings-actions">
                            <button type="submit" class="button button-primary pagepilot-save-btn">
                                <?php esc_html_e( 'Save Settings', 'pagepilot' ); ?>
                            </button>
                            <span class="pagepilot-save-status"></span>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Render the LMS tab.
     */
    private function render_lms_tab() {
        $detected_plugins = $this->get_detected_lms_plugins();
        $selected_lms     = isset( $this->settings['lms_plugin'] ) ? $this->settings['lms_plugin'] : '';
        // Read synced courses from the cache table instead of a separate option.
        $synced_courses   = $this->get_synced_courses_from_cache();
        ?>
        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'LMS Configuration', 'pagepilot' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Select and configure your LMS plugin for mobile app integration.', 'pagepilot' ); ?></p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="lms_plugin"><?php esc_html_e( 'Active LMS Plugin', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <select name="pagepilot_settings[lms_plugin]" id="lms_plugin" class="regular-text">
                            <option value=""><?php esc_html_e( '-- Select LMS Plugin --', 'pagepilot' ); ?></option>
                            <?php foreach ( $detected_plugins as $plugin ) : ?>
                                <option value="<?php echo esc_attr( $plugin['path'] ); ?>"
                                    <?php selected( $selected_lms, $plugin['path'] ); ?>>
                                    <?php echo esc_html( $plugin['name'] ); ?>
                                    <?php if ( $plugin['active'] ) : ?>
                                        (<?php esc_html_e( 'Active', 'pagepilot' ); ?>)
                                    <?php else : ?>
                                        (<?php esc_html_e( 'Inactive', 'pagepilot' ); ?>)
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">
                            <?php esc_html_e( 'Select the LMS plugin installed on your WordPress site.', 'pagepilot' ); ?>
                        </p>
                        <?php if ( empty( $detected_plugins ) ) : ?>
                            <p class="pagepilot-notice pagepilot-notice-warning">
                                <?php esc_html_e( 'No supported LMS plugins detected. Please install one of the supported LMS plugins.', 'pagepilot' ); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( 'Course Sync', 'pagepilot' ); ?>
                    </th>
                    <td>
                        <button type="button" id="pagepilot-sync-courses" class="button button-secondary">
                            <span class="dashicons dashicons-update"></span>
                            <?php esc_html_e( 'Sync Courses', 'pagepilot' ); ?>
                        </button>
                        <span class="pagepilot-sync-status"></span>
                        <p class="description">
                            <?php esc_html_e( 'Sync your LMS courses with PagePilot to make them available in the mobile app.', 'pagepilot' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php esc_html_e( 'Synced Courses', 'pagepilot' ); ?>
                    </th>
                    <td>
                        <div class="pagepilot-synced-courses">
                            <?php if ( ! empty( $synced_courses ) ) : ?>
                                <p class="pagepilot-count">
                                    <?php
                                    printf(
                                        /* translators: %d: number of synced courses */
                                        esc_html__( '%d courses synced', 'pagepilot' ),
                                        count( $synced_courses )
                                    );
                                    ?>
                                </p>
                                <ul class="pagepilot-course-list">
                                    <?php foreach ( array_slice( $synced_courses, 0, 10 ) as $course ) : ?>
                                        <li>
                                            <span class="dashicons dashicons-yes-alt pagepilot-text-success"></span>
                                            <?php echo esc_html( $course['title'] ); ?>
                                        </li>
                                    <?php endforeach; ?>
                                    <?php if ( count( $synced_courses ) > 10 ) : ?>
                                        <li class="pagepilot-more">
                                            <?php
                                            printf(
                                                /* translators: %d: number of remaining courses */
                                                esc_html__( '...and %d more', 'pagepilot' ),
                                                count( $synced_courses ) - 10
                                            );
                                            ?>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            <?php else : ?>
                                <p class="pagepilot-empty"><?php esc_html_e( 'No courses synced yet. Click "Sync Courses" to start.', 'pagepilot' ); ?></p>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
        <?php
    }

    /**
     * Render the App Settings tab.
     */
    private function render_app_tab() {
        $app_name      = $this->get_setting( 'app_name', get_bloginfo( 'name' ) );
        $primary_color = $this->get_setting( 'primary_color', '#0073aa' );
        $bg_color      = $this->get_setting( 'background_color', '#ffffff' );
        $text_color    = $this->get_setting( 'text_color', '#333333' );
        $logo_url      = $this->get_setting( 'logo_url' );
        $rest_url      = home_url( '/wp-json/pagepilot/v1/courses/preview' );
        $ajax_url      = admin_url( 'admin-ajax.php' );
        $nonce         = wp_create_nonce( 'pagepilot_preview_nonce' );
        $preview_courses = $this->get_preview_courses_inline();
        $preview_curriculum = $this->get_preview_curriculum_inline();
        $cache_bust = time();
        ?>
        <script src="<?php echo esc_url( admin_url( 'js/jquery/jquery.colorpicker.js' ) ); ?>?v=<?php echo $cache_bust; ?>"></script>
        <script>
            window.PagePilotPreview = {
                restUrl: '<?php echo esc_url( $rest_url ); ?>',
                ajaxUrl: '<?php echo esc_url( $ajax_url ); ?>',
                ajaxNonce: '<?php echo esc_js( $nonce ); ?>',
                courses: <?php echo wp_json_encode( $preview_courses ); ?>,
                categories: <?php echo wp_json_encode( $this->get_preview_categories() ); ?>,
                curriculum: <?php echo wp_json_encode( $preview_curriculum ); ?>,
                profile: <?php echo wp_json_encode( $this->get_preview_profile_inline() ); ?>,
                certificates: <?php echo wp_json_encode( $this->get_preview_certificates_inline() ); ?>,
                _v: <?php echo $cache_bust; ?>
            };
        </script>
        <div class="pagepilot-app-layout">
            <div class="pagepilot-app-settings-col">
        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'Basic Settings', 'pagepilot' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="app_name"><?php esc_html_e( 'App Name', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[app_name]"
                               id="app_name"
                               class="regular-text"
                               value="<?php echo esc_attr( $this->get_setting( 'app_name', get_bloginfo( 'name' ) ) ); ?>"
                               placeholder="<?php esc_attr_e( 'My LMS App', 'pagepilot' ); ?>" />
                        <p class="description"><?php esc_html_e( 'The name displayed in the app and app stores.', 'pagepilot' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="package_name"><?php esc_html_e( 'Package Name', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[package_name]"
                               id="package_name"
                               class="regular-text"
                               value="<?php echo esc_attr( $this->get_setting( 'package_name', 'com.pagepilot.app' ) ); ?>"
                               placeholder="com.example.myapp" />
                        <p class="description"><?php esc_html_e( 'Unique identifier for your app (e.g., com.company.appname).', 'pagepilot' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="app_version"><?php esc_html_e( 'App Version', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[app_version]"
                               id="app_version"
                               class="small-text"
                               value="<?php echo esc_attr( $this->get_setting( 'app_version', '1.0.0' ) ); ?>"
                               placeholder="1.0.0" />
                        <p class="description"><?php esc_html_e( 'Semantic version (e.g., 1.0.0).', 'pagepilot' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="build_number"><?php esc_html_e( 'Build Number', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="number"
                               name="pagepilot_settings[build_number]"
                               id="build_number"
                               class="small-text"
                               value="<?php echo esc_attr( $this->get_setting( 'build_number', '1' ) ); ?>"
                               min="1" />
                        <p class="description"><?php esc_html_e( 'Auto-incrementing build number.', 'pagepilot' ); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'Branding', 'pagepilot' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="primary_color"><?php esc_html_e( 'Primary Color', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[primary_color]"
                               id="primary_color"
                               class="pagepilot-color-picker"
                               value="<?php echo esc_attr( $this->get_setting( 'primary_color', '#0073aa' ) ); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="secondary_color"><?php esc_html_e( 'Secondary Color', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[secondary_color]"
                               id="secondary_color"
                               class="pagepilot-color-picker"
                               value="<?php echo esc_attr( $this->get_setting( 'secondary_color', '#005177' ) ); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="accent_color"><?php esc_html_e( 'Accent Color', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[accent_color]"
                               id="accent_color"
                               class="pagepilot-color-picker"
                               value="<?php echo esc_attr( $this->get_setting( 'accent_color', '#00aadc' ) ); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="background_color"><?php esc_html_e( 'Background Color', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[background_color]"
                               id="background_color"
                               class="pagepilot-color-picker"
                               value="<?php echo esc_attr( $this->get_setting( 'background_color', '#ffffff' ) ); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="text_color"><?php esc_html_e( 'Text Color', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_settings[text_color]"
                               id="text_color"
                               class="pagepilot-color-picker"
                               value="<?php echo esc_attr( $this->get_setting( 'text_color', '#333333' ) ); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="logo_url"><?php esc_html_e( 'App Logo', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <div class="pagepilot-media-upload">
                            <input type="hidden"
                                   name="pagepilot_settings[logo_url]"
                                   id="logo_url"
                                   value="<?php echo esc_url( $this->get_setting( 'logo_url' ) ); ?>" />
                            <div class="pagepilot-media-preview" id="logo-preview">
                                <?php if ( $this->get_setting( 'logo_url' ) ) : ?>
                                    <img src="<?php echo esc_url( $this->get_setting( 'logo_url' ) ); ?>" alt="<?php esc_attr_e( 'Logo', 'pagepilot' ); ?>" />
                                <?php else : ?>
                                    <span class="dashicons dashicons-format-image"></span>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="button pagepilot-upload-btn" data-target="logo_url" data-preview="logo-preview">
                                <?php esc_html_e( 'Upload Logo', 'pagepilot' ); ?>
                            </button>
                            <button type="button" class="button pagepilot-remove-btn" data-target="logo_url" data-preview="logo-preview" <?php echo empty( $this->settings['logo_url'] ) ? 'style="display:none;"' : ''; ?>>
                                <?php esc_html_e( 'Remove', 'pagepilot' ); ?>
                            </button>
                            <p class="description"><?php esc_html_e( 'Recommended: 512x512px PNG with transparency.', 'pagepilot' ); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="splash_url"><?php esc_html_e( 'Splash Screen', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <div class="pagepilot-media-upload">
                            <input type="hidden"
                                   name="pagepilot_settings[splash_url]"
                                   id="splash_url"
                                   value="<?php echo esc_url( $this->get_setting( 'splash_url' ) ); ?>" />
                            <div class="pagepilot-media-preview pagepilot-media-preview-wide" id="splash-preview">
                                <?php if ( $this->get_setting( 'splash_url' ) ) : ?>
                                    <img src="<?php echo esc_url( $this->get_setting( 'splash_url' ) ); ?>" alt="<?php esc_attr_e( 'Splash', 'pagepilot' ); ?>" />
                                <?php else : ?>
                                    <span class="dashicons dashicons-format-image"></span>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="button pagepilot-upload-btn" data-target="splash_url" data-preview="splash-preview">
                                <?php esc_html_e( 'Upload Splash Screen', 'pagepilot' ); ?>
                            </button>
                            <button type="button" class="button pagepilot-remove-btn" data-target="splash_url" data-preview="splash-preview" <?php echo empty( $this->settings['splash_url'] ) ? 'style="display:none;"' : ''; ?>>
                                <?php esc_html_e( 'Remove', 'pagepilot' ); ?>
                            </button>
                            <p class="description"><?php esc_html_e( 'Recommended: 1242x2436px for iOS, 1080x1920px for Android.', 'pagepilot' ); ?></p>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'Screens', 'pagepilot' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Enable or disable screens in the mobile app.', 'pagepilot' ); ?></p>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e( 'Available Screens', 'pagepilot' ); ?></th>
                    <td>
                        <fieldset>
                            <label class="pagepilot-toggle-label">
                                <input type="checkbox"
                                       name="pagepilot_settings[screen_courses]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'screen_courses', '1' ), '1' ); ?> />
                                <?php esc_html_e( 'Courses', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle-label">
                                <input type="checkbox"
                                       name="pagepilot_settings[screen_wishlist]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'screen_wishlist', '1' ), '1' ); ?> />
                                <?php esc_html_e( 'Wishlist', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle-label">
                                <input type="checkbox"
                                       name="pagepilot_settings[screen_profile]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'screen_profile', '1' ), '1' ); ?> />
                                <?php esc_html_e( 'Profile', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle-label">
                                <input type="checkbox"
                                       name="pagepilot_settings[screen_quiz]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'screen_quiz', '1' ), '1' ); ?> />
                                <?php esc_html_e( 'Quiz', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle-label">
                                <input type="checkbox"
                                       name="pagepilot_settings[screen_search]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'screen_search', '1' ), '1' ); ?> />
                                <?php esc_html_e( 'Search', 'pagepilot' ); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </div>

        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'Features', 'pagepilot' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e( 'App Features', 'pagepilot' ); ?></th>
                    <td>
                        <fieldset>
                            <label class="pagepilot-toggle">
                                <input type="checkbox"
                                       name="pagepilot_settings[dark_mode]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'dark_mode', '0' ), '1' ); ?> />
                                <span class="pagepilot-toggle-slider"></span>
                                <?php esc_html_e( 'Dark Mode Support', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle">
                                <input type="checkbox"
                                       name="pagepilot_settings[push_notifications]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'push_notifications', '0' ), '1' ); ?> />
                                <span class="pagepilot-toggle-slider"></span>
                                <?php esc_html_e( 'Push Notifications', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle">
                                <input type="checkbox"
                                       name="pagepilot_settings[social_login]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'social_login', '0' ), '1' ); ?> />
                                <span class="pagepilot-toggle-slider"></span>
                                <?php esc_html_e( 'Social Login (Google/Apple)', 'pagepilot' ); ?>
                            </label>
                            <label class="pagepilot-toggle">
                                <input type="checkbox"
                                       name="pagepilot_settings[offline_mode]"
                                       value="1"
                                       <?php checked( $this->get_setting( 'offline_mode', '0' ), '1' ); ?> />
                                <span class="pagepilot-toggle-slider"></span>
                                <?php esc_html_e( 'Offline Mode', 'pagepilot' ); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </div>

            </div><!-- .pagepilot-app-settings-col -->

            <div class="pagepilot-app-preview-col">
                <div class="pagepilot-phone-frame">
                    <div class="pagepilot-phone-notch"></div>
                    <div class="pagepilot-phone-screen" id="pagepilot-preview-screen">
                        <div class="pp-preview-statusbar" style="background:<?php echo esc_attr( $primary_color ); ?>">
                            <span>9:41</span>
                            <span>&#9679;&#9679;&#9679;</span>
                        </div>
                        <div class="pp-preview-header" style="background:<?php echo esc_attr( $primary_color ); ?>">
                            <span class="pp-preview-back dashicons dashicons-arrow-left-alt2" style="display:none;cursor:pointer;color:#fff;font-size:20px;width:20px;height:20px"></span>
                            <?php if ( $logo_url ) : ?>
                                <img src="<?php echo esc_url( $logo_url ); ?>" class="pp-preview-logo" alt="" />
                            <?php endif; ?>
                            <span class="pp-preview-title"><?php echo esc_html( $app_name ); ?></span>
                        </div>
                        <div class="pp-preview-body" id="pp-preview-body" style="background:<?php echo esc_attr( $bg_color ); ?>;color:<?php echo esc_attr( $text_color ); ?>">
                            <div class="pp-preview-loading">
                                <div class="pp-preview-spinner" style="border-top-color:<?php echo esc_attr( $primary_color ); ?>"></div>
                                <span>Loading courses...</span>
                            </div>
                        </div>
                        <div class="pp-preview-navbar" id="pp-preview-navbar" style="background:<?php echo esc_attr( $primary_color ); ?>">
                            <div class="pp-preview-nav-item active"><span class="dashicons dashicons-admin-home"></span><span>Home</span></div>
                            <div class="pp-preview-nav-item"><span class="dashicons dashicons-welcome-learnmore"></span><span>Courses</span></div>
                            <div class="pp-preview-nav-item"><span class="dashicons dashicons-heart"></span><span>Wishlist</span></div>
                            <div class="pp-preview-nav-item"><span class="dashicons dashicons-admin-users"></span><span>Profile</span></div>
                        </div>
                    </div>
                </div>
                <p class="pagepilot-preview-label">Live App Preview</p>
            </div>
        </div>
        <?php
    }

    /**
     * Get courses for inline preview rendering (bypasses REST API CDN issues).
     *
     * @return array
     */
    private function get_preview_courses_inline() {
        global $wpdb;
        $table   = $wpdb->prefix . 'pagepilot_course_cache';
        $lms_key = $this->get_setting( 'lms_plugin', '' );

        if ( empty( $lms_key ) ) {
            return array();
        }

        // Detect LMS key from plugin path.
        $key = '';
        if ( strpos( $lms_key, 'learnpress' ) !== false ) {
            $key = 'learnpress';
        } elseif ( strpos( $lms_key, 'lifterlms' ) !== false ) {
            $key = 'lifterlms';
        }

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
            return array();
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT item_id, item_data FROM {$table} WHERE lms_plugin = %s AND item_type = 'course' ORDER BY last_synced DESC LIMIT 10",
                $key
            )
        );

        $courses = array();
        foreach ( $rows as $row ) {
            $data = json_decode( $row->item_data, true );
            if ( is_array( $data ) ) {
                $data['id'] = (int) $row->item_id;
                // Render shortcodes and keep HTML for course description (shows video, enrollment, progress).
                if ( isset( $data['description'] ) ) {
                    $data['description'] = $this->render_preview_html( $data['description'] );
                }
                if ( isset( $data['short_description'] ) ) {
                    $data['short_description'] = $this->render_preview_html( $data['short_description'] );
                }
                // Also read the raw course HTML from wp_posts (has shortcodes, video embeds, etc.).
                if ( function_exists( 'get_post_field' ) ) {
                    $raw_desc = get_post_field( 'post_content', $data['id'] );
                    if ( ! empty( $raw_desc ) ) {
                        $data['raw_description'] = $this->render_preview_html( $raw_desc );
                    }
                }
                // Add enrollment status and progress for demo purposes.
                if ( ! isset( $data['is_enrolled'] ) ) {
                    $data['is_enrolled'] = false;
                }
                if ( ! isset( $data['progress'] ) ) {
                    $data['progress'] = 0;
                }
                // Read course-level video URL from postmeta (both LP and LLMS meta keys).
                if ( ! isset( $data['video_url'] ) ) {
                    $video_url = $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key IN ('_lp_video_url', '_llms_video_url', '_llms_video_embed') LIMIT 1",
                            $data['id']
                        )
                    );
                    if ( ! empty( $video_url ) ) {
                        $data['video_url'] = $video_url;
                    }
                }
                $courses[] = $data;
            }
        }

        return $courses;
    }

    /**
     * Get categories from AppConfig for preview rendering.
     *
     * @return array
     */
    private function get_preview_categories() {
        $categories_json = $this->get_setting( 'categories', '[]' );
        $categories      = json_decode( $categories_json, true );
        return is_array( $categories ) ? $categories : array();
    }

    /**
     * Get all lessons and quizzes from cache, grouped by course_id for inline preview.
     *
     * @return array{byCourseId: array, lessons: array, quizzes: array}
     */
    private function get_preview_curriculum_inline() {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
            return array( 'byCourseId' => array(), 'lessons' => array(), 'quizzes' => array() );
        }

        // Step 1: Build section→course mapping from lesson _llms_parent_section + _llms_parent_course meta.
        // This is the most reliable method because it uses the same meta that links lessons to courses.
        $section_to_course = array();
        $section_course_rows = $wpdb->get_results(
            "SELECT pm.meta_value AS section_id, pm2.meta_value AS course_id
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = pm.post_id
             WHERE pm.meta_key = '_llms_parent_section' AND pm.meta_value != ''
               AND pm2.meta_key = '_llms_parent_course' AND pm2.meta_value != ''"
        );
        foreach ( $section_course_rows as $row ) {
            $sid = (int) maybe_unserialize( $row->section_id );
            $cid = (int) maybe_unserialize( $row->course_id );
            if ( $sid > 0 && $cid > 0 ) {
                $section_to_course[ $sid ] = $cid;
            }
        }

        // Step 2: Build section data from section posts.
        $section_data = array();
        if ( function_exists( 'get_post_type' ) ) {
            $section_rows = $wpdb->get_results(
                "SELECT ID, post_title, post_parent FROM {$wpdb->posts} WHERE post_type IN ('llms_section', 'section') AND post_status = 'publish'"
            );
            foreach ( $section_rows as $sr ) {
                $sid = (int) $sr->ID;
                // Resolve course_id: first try post_parent, then _llms_course_id meta, then section_to_course mapping.
                $course_id = (int) $sr->post_parent;
                if ( $course_id <= 0 ) {
                    $course_id = (int) maybe_unserialize( $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_llms_course_id' LIMIT 1",
                            $sid
                        )
                    ) );
                }
                if ( $course_id <= 0 && isset( $section_to_course[ $sid ] ) ) {
                    $course_id = $section_to_course[ $sid ];
                }
                $section_data[ $sid ] = array(
                    'id'        => $sid,
                    'title'     => $sr->post_title,
                    'course_id' => $course_id,
                    'order'     => (int) maybe_unserialize( get_post_meta( $sid, '_llms_order', true ) ),
                );
                if ( $course_id > 0 ) {
                    $section_to_course[ $sid ] = $course_id;
                }
            }
        }

        // Step 3: Build known course ID list from cache table.
        $known_course_ids = array();
        $course_rows = $wpdb->get_results(
            "SELECT item_id FROM {$table} WHERE item_type = 'course'"
        );
        foreach ( $course_rows as $cr ) {
            $known_course_ids[ (int) $cr->item_id ] = true;
        }

        // Get all lessons — read raw content from wp_posts for full HTML.
        $lesson_rows = $wpdb->get_results(
            "SELECT item_id, item_data FROM {$table} WHERE item_type = 'lesson' ORDER BY last_synced ASC LIMIT 500"
        );

        $lessons = array();
        $by_course = array();
        foreach ( $lesson_rows as $row ) {
            $data = json_decode( $row->item_data, true );
            if ( ! is_array( $data ) ) {
                continue;
            }
            $data['id'] = (int) $row->item_id;
            // Read full HTML content from wp_posts (not truncated cache).
            if ( function_exists( 'get_post_field' ) ) {
                $raw_content = get_post_field( 'post_content', $data['id'] );
                if ( ! empty( $raw_content ) ) {
                    $data['content'] = $raw_content; // Full HTML, no truncation.
                }
            }
            // Fallback: use cached content if wp_posts unavailable.
            if ( empty( $data['content'] ) && isset( $data['description'] ) ) {
                $data['content'] = $data['description'];
            }
            // Strip shortcodes from display text but keep HTML for rendering.
            if ( isset( $data['content'] ) ) {
                $data['content_display'] = $this->clean_preview_text( $data['content'] );
            }
            // Read video URL from postmeta — check both LearnPress and LifterLMS meta keys.
            $data['video_url'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key IN ('_lp_video_url', '_llms_video_url', '_llms_video_embed') LIMIT 1",
                    $data['id']
                )
            );
            $data['attachments'] = array();
            $cid = isset( $data['course_id'] ) ? (int) $data['course_id'] : 0;

            // Fix: LifterLMS stores section_id as course_id.
            // If $cid is not a known course, check if it's a section → look up its parent course.
            if ( $cid > 0 && ! isset( $known_course_ids[ $cid ] ) && isset( $section_to_course[ $cid ] ) ) {
                $cid = $section_to_course[ $cid ];
            }

            // Fallback: if course_id is still 0, try to find it via _llms_section_lessons meta.
            if ( $cid <= 0 ) {
                $found = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT p.post_parent FROM {$wpdb->posts} p
                         INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                         WHERE pm.meta_key = '_llms_section_lessons'
                           AND pm.meta_value LIKE %s
                           AND p.post_type IN ('llms_section', 'section')
                         LIMIT 1",
                        '%' . $wpdb->esc_like( $data['id'] ) . '%'
                    )
                );
                if ( $found && $found->post_parent > 0 && isset( $known_course_ids[ (int) $found->post_parent ] ) ) {
                    $cid = (int) $found->post_parent;
                }
            }

            $data['course_id'] = $cid;

            // Resolve section ID for this lesson.
            $sid = 0;
            // Check _llms_parent_section meta.
            $sid_meta = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_llms_parent_section' LIMIT 1",
                    $data['id']
                )
            );
            if ( $sid_meta ) {
                $sid = (int) maybe_unserialize( $sid_meta );
            }
            // Fallback: check if any section has _llms_section_lessons containing this lesson ID.
            if ( $sid <= 0 ) {
                $sec_row = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT pm.post_id FROM {$wpdb->postmeta} pm
                         INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                         WHERE pm.meta_key = '_llms_section_lessons'
                           AND p.post_type IN ('llms_section', 'section')
                           AND pm.meta_value LIKE %s
                         LIMIT 1",
                        '%' . $wpdb->esc_like( (string) $data['id'] ) . '%'
                    )
                );
                if ( $sec_row && $sec_row->post_id > 0 ) {
                    $sid = (int) $sec_row->post_id;
                    // Back-fill section→course mapping.
                    if ( $cid > 0 && ! isset( $section_to_course[ $sid ] ) ) {
                        $section_to_course[ $sid ] = $cid;
                    }
                }
            }
            // Fallback: check post_parent (lesson's parent might be a section).
            if ( $sid <= 0 ) {
                $lesson_post = get_post( $data['id'] );
                if ( $lesson_post && $lesson_post->post_parent > 0 ) {
                    // Check if post_parent is a section post type.
                    $parent_type = get_post_type( $lesson_post->post_parent );
                    if ( in_array( $parent_type, array( 'llms_section', 'section' ), true ) ) {
                        $sid = (int) $lesson_post->post_parent;
                        if ( $cid > 0 && ! isset( $section_to_course[ $sid ] ) ) {
                            $section_to_course[ $sid ] = $cid;
                        }
                    }
                }
            }
            $data['section_id'] = $sid;

            // Read lesson order within its section (LifterLMS course builder order).
            $data['order'] = (int) get_post_meta( $data['id'], '_llms_order', true );

            $lessons[] = $data;
            if ( $cid > 0 ) {
                if ( ! isset( $by_course[ $cid ] ) ) {
                    $by_course[ $cid ] = array( 'lessons' => array(), 'quizzes' => array(), 'sections' => array() );
                }
                $by_course[ $cid ]['lessons'][] = $data;
            }
        }

        // Get all quizzes — read questions from LifterLMS/LearnPress tables.
        $quiz_rows = $wpdb->get_results(
            "SELECT item_id, item_data FROM {$table} WHERE item_type = 'quiz' ORDER BY last_synced ASC LIMIT 500"
        );

        $quizzes = array();
        foreach ( $quiz_rows as $row ) {
            $data = json_decode( $row->item_data, true );
            if ( ! is_array( $data ) ) {
                continue;
            }
            $data['id'] = (int) $row->item_id;

            // Read quiz questions from LifterLMS question tables.
            $questions = array();
            {
                // LifterLMS: questions linked via _llms_quiz_questions meta or lifterlms_quiz_questions table.
                $q_rows = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT pm.meta_value FROM {$wpdb->postmeta} pm
                         WHERE pm.post_id = %d AND pm.meta_key = '_llms_quiz_questions'",
                        $data['id']
                    )
                );
                if ( ! empty( $q_rows ) ) {
                    $question_ids = maybe_unserialize( $q_rows[0]->meta_value );
                    if ( is_array( $question_ids ) ) {
                        foreach ( $question_ids as $qid ) {
                            $qdata = get_post( $qid );
                            if ( ! $qdata || $qdata->post_status !== 'publish' ) {
                                continue;
                            }
                            $q = array(
                                'id'       => (int) $qid,
                                'question' => wp_strip_all_tags( $qdata->post_title ),
                                'type'     => get_post_meta( $qid, '_llms_question_type', true ) ?: 'standard',
                                'options'  => array(),
                            );
                            // Read options (choices).
                            $opt_rows = $wpdb->get_results(
                                $wpdb->prepare(
                                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_llms_question_options'",
                                    $qid
                                )
                            );
                            if ( ! empty( $opt_rows ) ) {
                                $opts = maybe_unserialize( $opt_rows[0]->meta_value );
                                if ( is_array( $opts ) ) {
                                    foreach ( $opts as $oid => $opt ) {
                                        // Do NOT include 'correct' field — security.
                                        $q['options'][] = array(
                                            'id'      => $oid,
                                            'text'    => wp_strip_all_tags( isset( $opt['text'] ) ? $opt['text'] : '' ),
                                        );
                                    }
                                }
                            }
                            $questions[] = $q;
                        }
                    }
                }
            }
            // Fallback: use cached questions if available (from sync).
            if ( empty( $questions ) && ! empty( $data['questions'] ) && is_array( $data['questions'] ) ) {
                foreach ( $data['questions'] as $q ) {
                    $safe_q = array(
                        'id'       => isset( $q['id'] ) ? $q['id'] : 0,
                        'question' => wp_strip_all_tags( isset( $q['question'] ) ? $q['question'] : ( isset( $q['title'] ) ? $q['title'] : '' ) ),
                        'type'     => isset( $q['type'] ) ? $q['type'] : 'standard',
                        'options'  => array(),
                    );
                    if ( ! empty( $q['options'] ) && is_array( $q['options'] ) ) {
                        foreach ( $q['options'] as $opt ) {
                            $safe_q['options'][] = array(
                                'id'   => isset( $opt['id'] ) ? $opt['id'] : 0,
                                'text' => wp_strip_all_tags( isset( $opt['text'] ) ? $opt['text'] : ( isset( $opt['title'] ) ? $opt['title'] : '' ) ),
                            );
                        }
                    }
                    $questions[] = $safe_q;
                }
            }
            $data['questions'] = $questions;
            // Remove correct answers from pass/fail data.
            unset( $data['correct_answers'] );

            $quiz_lesson_id = isset( $data['lesson_id'] ) ? (int) $data['lesson_id'] : 0;
            $quiz_course_id = isset( $data['course_id'] ) ? (int) $data['course_id'] : 0;

            // Find the real course_id for this quiz.
            $cid = $quiz_course_id;

            // If course_id is 0 or is a section_id, resolve it.
            if ( $cid === 0 || ! isset( $known_course_ids[ $cid ] ) ) {
                // Try to find via lesson.
                if ( $quiz_lesson_id > 0 ) {
                    foreach ( $lessons as $l ) {
                        if ( $l['id'] === $quiz_lesson_id ) {
                            $cid = $l['course_id'];
                            break;
                        }
                    }
                }
                // If still not found and cid is a section, resolve it.
                if ( ( $cid === 0 || ! isset( $known_course_ids[ $cid ] ) ) && isset( $section_to_course[ $cid ] ) ) {
                    $cid = $section_to_course[ $cid ];
                }
            }

            $data['course_id'] = $cid;
            $quizzes[] = $data;
            if ( $cid > 0 ) {
                if ( ! isset( $by_course[ $cid ] ) ) {
                    $by_course[ $cid ] = array( 'lessons' => array(), 'quizzes' => array(), 'sections' => array() );
                }
                $by_course[ $cid ]['quizzes'][] = $data;
            }
        }

        // Third pass: if section still has course_id=0, infer from lessons already grouped by course.
        // Each lesson has section_id and course_id; use that to back-fill section→course mapping.
        foreach ( $lessons as $ldata ) {
            $sid = isset( $ldata['section_id'] ) ? (int) $ldata['section_id'] : 0;
            $cid = isset( $ldata['course_id'] ) ? (int) $ldata['course_id'] : 0;
            if ( $sid > 0 && $cid > 0 && isset( $section_data[ $sid ] ) && $section_data[ $sid ]['course_id'] === 0 ) {
                $section_data[ $sid ]['course_id'] = $cid;
                $section_to_course[ $sid ] = $cid;
            }
        }

        // Populate sections per course and sort by order.
        foreach ( $section_data as $sid => $sdata ) {
            $cid = $sdata['course_id'];
            if ( $cid > 0 && isset( $by_course[ $cid ] ) ) {
                $by_course[ $cid ]['sections'][ $sid ] = $sdata;
            }
        }
        // Sort sections by order within each course.
        foreach ( $by_course as $cid => &$cdata ) {
            uasort( $cdata['sections'], function ( $a, $b ) {
                return ($a['order'] ?? 0) <=> ($b['order'] ?? 0);
            });
            // Sort lessons by section order then lesson order.
            usort( $cdata['lessons'], function ( $a, $b ) use ( $cdata ) {
                $sa = $a['section_id'] ?? 0;
                $sb = $b['section_id'] ?? 0;
                $oa = $a['order'] ?? 0;
                $ob = $b['order'] ?? 0;
                // Group by section order first.
                $soa = 0;
                $sob = 0;
                if ( $sa > 0 && isset( $cdata['sections'][ $sa ] ) ) {
                    $soa = $cdata['sections'][ $sa ]['order'] ?? 0;
                }
                if ( $sb > 0 && isset( $cdata['sections'][ $sb ] ) ) {
                    $sob = $cdata['sections'][ $sb ]['order'] ?? 0;
                }
                if ( $soa !== $sob ) {
                    return $soa <=> $sob;
                }
                return $oa <=> $ob;
            });
            // Sort quizzes by section order too.
            usort( $cdata['quizzes'], function ( $a, $b ) use ( $cdata ) {
                $sa = $a['section_id'] ?? 0;
                $sb = $b['section_id'] ?? 0;
                $oa = $a['order'] ?? 0;
                $ob = $b['order'] ?? 0;
                $soa = 0;
                $sob = 0;
                if ( $sa > 0 && isset( $cdata['sections'][ $sa ] ) ) {
                    $soa = $cdata['sections'][ $sa ]['order'] ?? 0;
                }
                if ( $sb > 0 && isset( $cdata['sections'][ $sb ] ) ) {
                    $sob = $cdata['sections'][ $sb ]['order'] ?? 0;
                }
                if ( $soa !== $sob ) {
                    return $soa <=> $sob;
                }
                return $oa <=> $ob;
            });
        }
        unset( $cdata );

        // Debug: count sections per course for diagnostics.
        $debug = array();
        foreach ( $by_course as $cid => $cdata ) {
            $debug[ $cid ] = array(
                'lessons'       => count( $cdata['lessons'] ),
                'quizzes'       => count( $cdata['quizzes'] ),
                'sections'      => count( $cdata['sections'] ),
                'section_ids'   => array_keys( $cdata['sections'] ),
                'lesson_sids'   => array_map( function ( $l ) { return isset( $l['section_id'] ) ? (int) $l['section_id'] : 0; }, $cdata['lessons'] ),
            );
        }

        return array(
            'byCourseId' => $by_course,
            'lessons'    => $lessons,
            'quizzes'    => $quizzes,
            'sections'   => $section_data,
            '_debug'     => $debug,
        );
    }

    /**
     * Get profile data for inline preview rendering.
     *
     * @return array
     */
    private function get_preview_profile_inline() {
        global $wpdb;
        $table   = $wpdb->prefix . 'pagepilot_course_cache';
        $lms_key = $this->get_setting( 'lms_plugin', '' );
        $key     = '';
        if ( strpos( $lms_key, 'learnpress' ) !== false ) {
            $key = 'learnpress';
        } elseif ( strpos( $lms_key, 'lifterlms' ) !== false ) {
            $key = 'lifterlms';
        }

        // Count courses.
        $total_courses = 0;
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {
            $total_courses = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE lms_plugin = %s AND item_type = 'course'",
                    $key
                )
            );
        }

        // Generate demo profile data.
        return array(
            'name'            => 'Learner',
            'email'           => 'learner@example.com',
            'avatar'          => '',
            'enrolled'        => min( $total_courses, 3 ),
            'completed'       => 1,
            'in_progress'     => 1,
            'certificates'    => 1,
            'total_courses'   => $total_courses,
        );
    }

    /**
     * Get certificate data for inline preview rendering.
     *
     * @return array
     */
    private function get_preview_certificates_inline() {
        global $wpdb;

        // Try to get real certificates from LifterLMS certificate table.
        $certificates = array();
        $cert_table   = $wpdb->prefix . 'lifterlms_certificate_postmeta';

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$cert_table}'" ) === $cert_table ) {
            $rows = $wpdb->get_results(
                "SELECT post_id FROM {$wpdb->posts} WHERE post_type = 'llms_certificate' AND post_status = 'publish' ORDER BY post_date DESC LIMIT 10"
            );
            foreach ( $rows as $row ) {
                $title = get_post_field( 'post_title', $row->post_id );
                $date  = get_post_field( 'post_date', $row->post_id );
                $certificates[] = array(
                    'id'    => (int) $row->post_id,
                    'title' => $title ?: 'Certificate of Completion',
                    'date'  => $date ? date( 'M j, Y', strtotime( $date ) ) : '',
                    'course' => 'Course',
                );
            }
        }

        // Fallback: generate demo certificates.
        if ( empty( $certificates ) ) {
            $certificates = array(
                array(
                    'id'     => 1,
                    'title'  => 'Certificate of Completion',
                    'date'   => date( 'M j, Y' ),
                    'course' => 'Introduction to Web Development',
                ),
            );
        }

        return $certificates;
    }

    /**
     * Render the GitHub Settings tab.
     */
    private function render_github_tab() {
        $github_settings = get_option( 'pagepilot_github_settings', array() );
        $token           = isset( $github_settings['token'] ) ? $github_settings['token'] : '';
        $repository      = isset( $github_settings['repository'] ) ? $github_settings['repository'] : '';
        $branch          = isset( $github_settings['branch'] ) ? $github_settings['branch'] : 'main';
        $repo_private    = isset( $github_settings['repo_private'] ) ? $github_settings['repo_private'] : '1';
        $connected       = ! empty( $token ) && ! empty( $repository );
        ?>
        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'GitHub Connection', 'pagepilot' ); ?></h2>

            <div class="pagepilot-connection-status <?php echo $connected ? 'pagepilot-connected' : 'pagepilot-disconnected'; ?>">
                <span class="dashicons dashicons-<?php echo $connected ? 'yes-alt' : 'warning'; ?>"></span>
                <strong>
                    <?php echo $connected ? esc_html__( 'Connected to GitHub', 'pagepilot' ) : esc_html__( 'Not Connected', 'pagepilot' ); ?>
                </strong>
            </div>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="github_token"><?php esc_html_e( 'Personal Access Token', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="password"
                               name="pagepilot_github_settings[token]"
                               id="github_token"
                               class="regular-text"
                               value="<?php echo esc_attr( $token ); ?>"
                               autocomplete="off" />
                        <button type="button" class="button pagepilot-toggle-password" data-target="github_token">
                            <?php esc_html_e( 'Show', 'pagepilot' ); ?>
                        </button>
                        <p class="description">
                            <?php esc_html_e( 'Generate a token at', 'pagepilot' ); ?>
                            <a href="https://github.com/settings/tokens/new?scopes=repo,workflow&description=PagePilot" target="_blank" rel="noopener noreferrer">
                                <?php esc_html_e( 'GitHub Settings', 'pagepilot' ); ?>
                            </a>
                            <?php esc_html_e( 'with "repo" and "workflow" scopes.', 'pagepilot' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="github_repo"><?php esc_html_e( 'Repository', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_github_settings[repository]"
                               id="github_repo"
                               class="regular-text"
                               value="<?php echo esc_attr( $repository ); ?>"
                               placeholder="username/repo-name" />
                        <p class="description"><?php esc_html_e( 'Format: username/repository-name', 'pagepilot' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="github_repo_private"><?php esc_html_e( 'Repository Visibility', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <fieldset>
                            <label for="github_repo_private_on">
                                <input type="radio"
                                       name="pagepilot_github_settings[repo_private]"
                                       id="github_repo_private_on"
                                       value="1"
                                       <?php checked( $repo_private, '1' ); ?> />
                                <?php esc_html_e( 'Private', 'pagepilot' ); ?>
                            </label>
                            &nbsp;&nbsp;
                            <label for="github_repo_private_off">
                                <input type="radio"
                                       name="pagepilot_github_settings[repo_private]"
                                       id="github_repo_private_off"
                                       value="0"
                                       <?php checked( $repo_private, '0' ); ?> />
                                <?php esc_html_e( 'Public', 'pagepilot' ); ?>
                            </label>
                        </fieldset>
                        <p class="description">
                            <?php esc_html_e( 'Private repos require a paid GitHub plan for Actions minutes. Public repos are free but your source code will be visible.', 'pagepilot' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="github_branch"><?php esc_html_e( 'Default Branch', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_github_settings[branch]"
                               id="github_branch"
                               class="regular-text"
                               value="<?php echo esc_attr( $branch ); ?>"
                               placeholder="main" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="test_github"><?php esc_html_e( 'Test Connection', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <button type="button" id="pagepilot-test-github" class="button button-secondary">
                            <span class="dashicons dashicons-superhero"></span>
                            <?php esc_html_e( 'Test Connection', 'pagepilot' ); ?>
                        </button>
                        <span class="pagepilot-github-test-status"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php esc_html_e( 'Create Repository', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="text"
                                   id="pp-new-repo-name"
                                   class="regular-text"
                                   placeholder="<?php esc_attr_e( 'new-app-repo', 'pagepilot' ); ?>" />
                            <button type="button" id="pagepilot-create-repo" class="button button-secondary">
                                <span class="dashicons dashicons-plus-alt2"></span>
                                <?php esc_html_e( 'Create on GitHub', 'pagepilot' ); ?>
                            </button>
                        </div>
                        <p class="description">
                            <?php esc_html_e( 'Creates a new repository using the visibility setting above. The repo name will be auto-filled.', 'pagepilot' ); ?>
                        </p>
                        <span class="pagepilot-create-repo-status"></span>
                    </td>
                </tr>
            </table>
        </div>

        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'Appetize.io Integration', 'pagepilot' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Automatically upload builds to Appetize.io for instant testing on real devices. Get your API token from your Appetize.io dashboard.', 'pagepilot' ); ?></p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="appetize_token"><?php esc_html_e( 'API Token', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="password"
                               name="pagepilot_github_settings[appetize_token]"
                               id="appetize_token"
                               class="regular-text"
                               value="<?php echo esc_attr( isset( $github_settings['appetize_token'] ) ? $github_settings['appetize_token'] : '' ); ?>"
                               autocomplete="off"
                               placeholder="api_xxxxxxxxxxxxxxxxxxxx" />
                        <button type="button" class="button pagepilot-toggle-password" data-target="appetize_token">
                            <?php esc_html_e( 'Show', 'pagepilot' ); ?>
                        </button>
                        <p class="description">
                            <?php esc_html_e( 'Find your token at', 'pagepilot' ); ?>
                            <a href="https://appetize.io/dashboard" target="_blank" rel="noopener noreferrer">appetize.io/dashboard</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="appetize_app_key"><?php esc_html_e( 'Android App Key', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_github_settings[appetize_android_key]"
                               id="appetize_app_key"
                               class="regular-text"
                               value="<?php echo esc_attr( isset( $github_settings['appetize_android_key'] ) ? $github_settings['appetize_android_key'] : '' ); ?>"
                               placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
                        <p class="description"><?php esc_html_e( 'App key from Appetize.io for Android builds. Leave blank to auto-create.', 'pagepilot' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="appetize_ios_key"><?php esc_html_e( 'iOS App Key', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               name="pagepilot_github_settings[appetize_ios_key]"
                               id="appetize_ios_key"
                               class="regular-text"
                               value="<?php echo esc_attr( isset( $github_settings['appetize_ios_key'] ) ? $github_settings['appetize_ios_key'] : '' ); ?>"
                               placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
                        <p class="description"><?php esc_html_e( 'App key from Appetize.io for iOS builds. Leave blank to auto-create.', 'pagepilot' ); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="pagepilot-settings-actions">
            <button type="submit" class="button button-primary pagepilot-save-btn" data-section="github">
                <?php esc_html_e( 'Save GitHub Settings', 'pagepilot' ); ?>
            </button>
            <span class="pagepilot-save-status"></span>
        </div>
        <?php
    }

    /**
     * Render the Advanced tab.
     */
    private function render_advanced_tab() {
        $advanced_settings = get_option( 'pagepilot_advanced_settings', array() );
        ?>
        <div class="pagepilot-settings-section">
            <h2><?php esc_html_e( 'Advanced Settings', 'pagepilot' ); ?></h2>
            <p class="description pagepilot-notice pagepilot-notice-warning">
                <?php esc_html_e( 'Warning: These settings are for advanced users only. Incorrect configuration may break your app.', 'pagepilot' ); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="api_endpoint"><?php esc_html_e( 'Custom API Endpoint', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <input type="url"
                               name="pagepilot_advanced_settings[api_endpoint]"
                               id="api_endpoint"
                               class="large-text"
                               value="<?php echo esc_attr( isset( $advanced_settings['api_endpoint'] ) ? $advanced_settings['api_endpoint'] : '' ); ?>"
                               placeholder="<?php echo esc_url( rest_url( 'wp/v2/' ) ); ?>" />
                        <p class="description">
                            <?php esc_html_e( 'Override the default WordPress REST API endpoint. Leave empty to use the default.', 'pagepilot' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="auth_method"><?php esc_html_e( 'Authentication Method', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <select name="pagepilot_advanced_settings[auth_method]" id="auth_method" class="regular-text">
                            <option value="jwt" <?php selected( isset( $advanced_settings['auth_method'] ) ? $advanced_settings['auth_method'] : '', 'jwt' ); ?>>
                                <?php esc_html_e( 'JWT (JSON Web Token)', 'pagepilot' ); ?>
                            </option>
                            <option value="cookie" <?php selected( isset( $advanced_settings['auth_method'] ) ? $advanced_settings['auth_method'] : '', 'cookie' ); ?>>
                                <?php esc_html_e( 'Cookie-Based Authentication', 'pagepilot' ); ?>
                            </option>
                            <option value="basic" <?php selected( isset( $advanced_settings['auth_method'] ) ? $advanced_settings['auth_method'] : '', 'basic' ); ?>>
                                <?php esc_html_e( 'HTTP Basic Auth', 'pagepilot' ); ?>
                            </option>
                            <option value="none" <?php selected( isset( $advanced_settings['auth_method'] ) ? $advanced_settings['auth_method'] : '', 'none' ); ?>>
                                <?php esc_html_e( 'None (Public Only)', 'pagepilot' ); ?>
                            </option>
                        </select>
                        <p class="description">
                            <?php esc_html_e( 'Select the authentication method for API requests from the mobile app.', 'pagepilot' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="custom_headers"><?php esc_html_e( 'Custom Headers (JSON)', 'pagepilot' ); ?></label>
                    </th>
                    <td>
                        <textarea name="pagepilot_advanced_settings[custom_headers]"
                                  id="custom_headers"
                                  class="large-text code"
                                  rows="6"
                                  placeholder='{"X-Custom-Header": "value", "X-Api-Key": "your-key"}'><?php echo esc_textarea( isset( $advanced_settings['custom_headers'] ) ? $advanced_settings['custom_headers'] : '' ); ?></textarea>
                        <p class="description">
                            <?php esc_html_e( 'Add custom HTTP headers for API requests. Must be valid JSON.', 'pagepilot' ); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="pagepilot-settings-actions">
            <button type="button" id="pagepilot-save-advanced" class="button button-primary pagepilot-save-btn" data-section="advanced">
                <?php esc_html_e( 'Save Advanced Settings', 'pagepilot' ); ?>
            </button>
            <span class="pagepilot-save-status"></span>
        </div>
        <?php
    }

    /**
     * AJAX handler for saving settings.
     */
    public function ajax_save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        if ( ! isset( $_POST['pagepilot_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pagepilot_nonce'] ) ), 'pagepilot_settings_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'pagepilot' ) ) );
        }

        $section = isset( $_POST['active_tab'] ) ? sanitize_text_field( wp_unslash( $_POST['active_tab'] ) ) : '';
        $post_data = $_POST;

        unset( $post_data['action'] );
        unset( $post_data['pagepilot_nonce'] );
        unset( $post_data['active_tab'] );

        if ( 'github' === $section ) {
            $github_settings = array();
            if ( isset( $post_data['pagepilot_github_settings'] ) && is_array( $post_data['pagepilot_github_settings'] ) ) {
                foreach ( $post_data['pagepilot_github_settings'] as $key => $value ) {
                    $github_settings[ sanitize_key( $key ) ] = sanitize_text_field( wp_unslash( $value ) );
                }
            }
            update_option( 'pagepilot_github_settings', $github_settings );
            wp_send_json_success( array( 'message' => __( 'GitHub settings saved.', 'pagepilot' ) ) );
        }

        if ( 'advanced' === $section ) {
            $advanced_settings = array();
            if ( isset( $post_data['pagepilot_advanced_settings'] ) && is_array( $post_data['pagepilot_advanced_settings'] ) ) {
                foreach ( $post_data['pagepilot_advanced_settings'] as $key => $value ) {
                    if ( 'custom_headers' === $key ) {
                        $advanced_settings[ sanitize_key( $key ) ] = sanitize_textarea_field( wp_unslash( $value ) );
                    } elseif ( 'api_endpoint' === $key ) {
                        $advanced_settings[ sanitize_key( $key ) ] = esc_url_raw( wp_unslash( $value ) );
                    } else {
                        $advanced_settings[ sanitize_key( $key ) ] = sanitize_text_field( wp_unslash( $value ) );
                    }
                }
            }
            update_option( 'pagepilot_advanced_settings', $advanced_settings );
            wp_send_json_success( array( 'message' => __( 'Advanced settings saved.', 'pagepilot' ) ) );
        }

        $settings = array();
        if ( isset( $post_data['pagepilot_settings'] ) && is_array( $post_data['pagepilot_settings'] ) ) {
            foreach ( $post_data['pagepilot_settings'] as $key => $value ) {
                $clean_key = sanitize_key( $key );

                if ( in_array( $clean_key, array( 'app_name', 'package_name' ), true ) ) {
                    $settings[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
                } elseif ( in_array( $clean_key, array( 'app_version' ), true ) ) {
                    $settings[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
                } elseif ( 'build_number' === $clean_key ) {
                    $settings[ $clean_key ] = absint( $value );
                } elseif ( in_array( $clean_key, array( 'primary_color', 'secondary_color', 'accent_color', 'background_color', 'text_color' ), true ) ) {
                    $settings[ $clean_key ] = sanitize_hex_color( wp_unslash( $value ) );
                } elseif ( in_array( $clean_key, array( 'logo_url', 'splash_url' ), true ) ) {
                    $settings[ $clean_key ] = esc_url_raw( wp_unslash( $value ) );
                } elseif ( 'lms_plugin' === $clean_key ) {
                    $settings[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
                } elseif ( preg_match( '/^screen_/', $clean_key ) || preg_match( '/^(dark_mode|push_notifications|social_login|offline_mode)$/', $clean_key ) ) {
                    $settings[ $clean_key ] = '1' === $value ? '1' : '0';
                } else {
                    $settings[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
                }
            }
        }

        update_option( 'pagepilot_settings', $settings );

        wp_send_json_success( array( 'message' => __( 'Settings saved successfully.', 'pagepilot' ) ) );
    }

    /**
     * AJAX handler for syncing courses.
     */
    public function ajax_sync_courses() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        if ( ! isset( $_POST['pagepilot_ajax_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pagepilot_ajax_nonce'] ) ), 'pagepilot_ajax_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'pagepilot' ) ) );
        }

        $lms_plugin = isset( $this->settings['lms_plugin'] ) ? $this->settings['lms_plugin'] : '';

        if ( empty( $lms_plugin ) ) {
            wp_send_json_error( array( 'message' => __( 'Please select an LMS plugin first.', 'pagepilot' ) ) );
        }

        $courses = $this->fetch_courses_from_lms( $lms_plugin );

        if ( is_wp_error( $courses ) ) {
            wp_send_json_error( array( 'message' => $courses->get_error_message() ) );
        }

        update_option( 'pagepilot_synced_courses', $courses );

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: %d: number of courses synced */
                __( '%d courses synced successfully.', 'pagepilot' ),
                count( $courses )
            ),
            'count'   => count( $courses ),
            'courses' => $courses,
        ) );
    }

    /**
     * Fetch courses from the selected LMS plugin.
     *
     * @param string $lms_plugin LMS plugin identifier.
     * @return array|WP_Error Array of courses or error.
     */
    private function fetch_courses_from_lms( $lms_plugin ) {
        $courses = array();

        if ( strpos( $lms_plugin, 'learnpress' ) !== false && function_exists( 'learn_press_get_courses' ) ) {
            $raw_courses = learn_press_get_courses();
            if ( ! empty( $raw_courses ) ) {
                foreach ( $raw_courses as $course ) {
                    $courses[] = array(
                        'id'    => $course->ID,
                        'title' => $course->post_title,
                        'slug'  => $course->post_name,
                    );
                }
            }
            return $courses;
        }

        if ( strpos( $lms_plugin, 'lifterlms' ) !== false && class_exists( 'LifterLMS' ) ) {
            $args = array(
                'post_type'   => 'course',
                'numberposts' => -1,
                'post_status' => 'publish',
            );
            $raw_courses = get_posts( $args );
            foreach ( $raw_courses as $course ) {
                $courses[] = array(
                    'id'    => $course->ID,
                    'title' => $course->post_title,
                    'slug'  => $course->post_name,
                );
            }
            return $courses;
        }

        if ( strpos( $lms_plugin, 'tutor' ) !== false && function_exists( 'tutor_utils' ) ) {
            $args = array(
                'post_type'   => 'course',
                'numberposts' => -1,
                'post_status' => 'publish',
            );
            $raw_courses = get_posts( $args );
            foreach ( $raw_courses as $course ) {
                $courses[] = array(
                    'id'    => $course->ID,
                    'title' => $course->post_title,
                    'slug'  => $course->post_name,
                );
            }
            return $courses;
        }

        // Generic fallback using WP post query.
        $args = array(
            'post_type'   => 'course',
            'numberposts' => -1,
            'post_status' => 'publish',
        );
        $raw_courses = get_posts( $args );

        if ( empty( $raw_courses ) ) {
            return new WP_Error(
                'no_courses',
                __( 'No published courses found. Ensure your LMS plugin is active and has published courses.', 'pagepilot' )
            );
        }

        foreach ( $raw_courses as $course ) {
            $courses[] = array(
                'id'    => $course->ID,
                'title' => $course->post_title,
                'slug'  => $course->post_name,
            );
        }

        return $courses;
    }

    /**
     * AJAX handler: get courses for live preview.
     */
    public function ajax_preview_courses() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pagepilot_preview_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'pagepilot' ) ) );
        }

        $courses   = $this->get_preview_courses_inline();
        $categories = $this->get_preview_categories();

        wp_send_json_success( array(
            'courses'    => $courses,
            'categories' => $categories,
        ) );
    }

    /**
     * AJAX handler: get course detail with lessons for preview.
     */
    public function ajax_preview_course_detail() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pagepilot_preview_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'pagepilot' ) ) );
        }

        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        if ( ! $course_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid course ID.', 'pagepilot' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';

        // Get course data.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT item_data FROM {$table} WHERE item_id = %d AND item_type = 'course'",
                $course_id
            )
        );

        if ( ! $row ) {
            wp_send_json_error( array( 'message' => __( 'Course not found in cache.', 'pagepilot' ) ) );
        }

        $course = json_decode( $row->item_data, true );
        $course['id'] = $course_id;

        // Process shortcodes then strip HTML from description fields for clean preview display.
        if ( isset( $course['description'] ) ) {
            $course['description'] = $this->clean_preview_text( $course['description'] );
        }
        if ( isset( $course['short_description'] ) ) {
            $course['short_description'] = $this->clean_preview_text( $course['short_description'] );
        }

        // Get lessons: query all lessons and filter by course_id in PHP (more reliable than SQL LIKE on JSON).
        $all_lesson_rows = $wpdb->get_results(
            "SELECT item_id, item_data FROM {$table} WHERE item_type = 'lesson' ORDER BY last_synced ASC LIMIT 500"
        );

        $lessons = array();
        foreach ( $all_lesson_rows as $lr ) {
            $ldata = json_decode( $lr->item_data, true );
            if ( is_array( $ldata ) && isset( $ldata['course_id'] ) && (int) $ldata['course_id'] === $course_id ) {
                $ldata['id'] = (int) $lr->item_id;
                // Strip HTML from lesson content too.
                if ( isset( $ldata['content'] ) ) {
                    $ldata['content'] = wp_strip_all_tags( wpautop( $ldata['content'] ) );
                }
                $lessons[] = $ldata;
            }
        }

        // Sort lessons by order field if present.
        usort( $lessons, function ( $a, $b ) {
            $orderA = isset( $a['order'] ) ? (int) $a['order'] : 0;
            $orderB = isset( $b['order'] ) ? (int) $b['order'] : 0;
            return $orderA - $orderB;
        });

        // Get quizzes: match by lesson_id (quizzes belong to lessons, not directly to courses).
        $lesson_ids = array_map( function ( $l ) { return $l['id']; }, $lessons );
        $quizzes = array();
        if ( ! empty( $lesson_ids ) ) {
            $all_quiz_rows = $wpdb->get_results(
                "SELECT item_id, item_data FROM {$table} WHERE item_type = 'quiz' ORDER BY last_synced ASC LIMIT 500"
            );
            foreach ( $all_quiz_rows as $qr ) {
                $qdata = json_decode( $qr->item_data, true );
                if ( is_array( $qdata ) ) {
                    $quiz_lesson_id = isset( $qdata['lesson_id'] ) ? (int) $qdata['lesson_id'] : 0;
                    $quiz_course_id = isset( $qdata['course_id'] ) ? (int) $qdata['course_id'] : 0;
                    if ( in_array( $quiz_lesson_id, $lesson_ids, true ) || $quiz_course_id === $course_id ) {
                        $qdata['id'] = (int) $qr->item_id;
                        $quizzes[] = $qdata;
                    }
                }
            }
        }

        wp_send_json_success( array(
            'course' => $course,
            'lessons' => $lessons,
            'quizzes' => $quizzes,
        ) );
    }

    /**
     * AJAX handler: get all lessons from cache for preview.
     */
    public function ajax_preview_lessons() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pagepilot_preview_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'pagepilot' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';

        $rows = $wpdb->get_results(
            "SELECT item_id, item_data FROM {$table} WHERE item_type = 'lesson' ORDER BY last_synced ASC LIMIT 200"
        );

        $lessons = array();
        foreach ( $rows as $row ) {
            $data = json_decode( $row->item_data, true );
            if ( is_array( $data ) ) {
                $data['id'] = (int) $row->item_id;
                $lessons[] = $data;
            }
        }

        wp_send_json_success( array( 'lessons' => $lessons ) );
    }

    /**
     * Get detected LMS plugins.
     *
     * @return array
     */
    private function get_detected_lms_plugins() {
        $lms_plugins = array(
            'learnpress/learnpress.php'            => 'LearnPress',
            'lifterlms/lifterlms.php'              => 'LifterLMS',
            'sensei-lms/sensei-lms.php'            => 'Sensei LMS',
            'learn-dash/learndash.php'             => 'LearnDash',
            'masterstudy-lms/masterstudy-lms.php'  => 'MasterStudy LMS',
            'tutor/tutor.php'                      => 'Tutor LMS',
            'wp-courseware/wp-courseware.php'       => 'WP Courseware',
            'smart-courses/smart-courses.php'      => 'Smart Courses',
        );

        $detected = array();

        foreach ( $lms_plugins as $path => $name ) {
            if ( file_exists( WP_PLUGIN_DIR . '/' . $path ) ) {
                $detected[] = array(
                    'name'   => $name,
                    'slug'   => dirname( $path ),
                    'path'   => $path,
                    'active' => is_plugin_active( $path ),
                );
            }
        }

        return $detected;
    }

    /**
     * Get a setting value with fallback.
     *
     * @param string $key     Setting key.
     * @param mixed  $default Default value.
     * @return mixed
     */
    private function get_setting( $key, $default = '' ) {
        return isset( $this->settings[ $key ] ) && '' !== $this->settings[ $key ] ? $this->settings[ $key ] : $default;
    }

    /**
     * Clean text for preview display: remove shortcodes, HTML, and extra whitespace.
     *
     * @param string $text Raw text with possible shortcodes/HTML.
     * @return string Clean text.
     */
    private function clean_preview_text( $text ) {
        // Remove WordPress block comments.
        $text = preg_replace( '/<!--.*?-->/s', '', $text );
        // Remove all shortcodes (any [shortcode] or [shortcode attr="value"]).
        $text = preg_replace( '/\[[^\]]*\]/', '', $text );
        // Process any remaining shortcodes that might output content.
        $text = do_shortcode( $text );
        // Strip all HTML tags.
        $text = wp_strip_all_tags( $text );
        // Clean up extra whitespace/newlines.
        $text = preg_replace( '/\n{3,}/', "\n\n", $text );
        $text = trim( $text );
        return $text;
    }

    /**
     * Render HTML for preview: process shortcodes, keep HTML structure.
     * Used for course descriptions that may contain LifterLMS shortcodes.
     */
    private function render_preview_html( $text ) {
        // Remove WordPress block comments.
        $text = preg_replace( '/<!--.*?-->/s', '', $text );
        // Process shortcodes so they output HTML.
        $text = do_shortcode( $text );
        // Clean up but keep HTML.
        $text = trim( $text );
        return $text;
    }

    private function get_synced_courses_from_cache() {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';
        $lms_key = isset( $this->settings['lms_plugin'] ) ? $this->settings['lms_plugin'] : '';
        if ( empty( $lms_key ) ) {
            return array();
        }
        // Extract LMS key from plugin path (e.g. lifterlms/lifterlms.php -> lifterlms).
        if ( strpos( $lms_key, 'lifterlms' ) !== false ) {
            $lms_key = 'lifterlms';
        } elseif ( strpos( $lms_key, 'learnpress' ) !== false ) {
            $lms_key = 'learnpress';
        }
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT item_id, item_data FROM {$table} WHERE lms_plugin = %s AND item_type = 'course' ORDER BY last_synced DESC",
                $lms_key
            )
        );
        $courses = array();
        foreach ( $rows as $row ) {
            $data = json_decode( $row->item_data, true );
            if ( $data ) {
                $courses[] = $data;
            }
        }
        return $courses;
    }
}
