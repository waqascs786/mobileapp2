=== PagePilot ===
Contributors: pagepilot
Donate link: https://pagepilot.io
Tags: mobile-app, lms, learnpress, android, ios, flutter, github-actions
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate native Android and iOS mobile apps from your WordPress LMS site.

== Description ==

PagePilot transforms your WordPress-based Learning Management System into a native mobile app experience. Connect your GitHub account, configure your app settings, and trigger builds — all from your WordPress admin dashboard.

= Key Features =

* **One-Click App Generation** — Build native Android and iOS apps with a single click
* **GitHub Integration** — Connect your GitHub account and manage app repositories directly from WordPress
* **LearnPress Integration** — Automatically sync your LearnPress courses to your mobile app
* **Custom Branding** — Customize app name, primary color, logo, and splash screen
* **Build History** — Track all your app builds with status updates and downloadable artifacts
* **CI/CD with GitHub Actions** — Automated build pipeline using GitHub Actions for Android APK and iOS builds
* **REST API** — Full REST API for managing settings, triggering builds, and syncing content
* **Webhook Support** — Receive build notifications via configurable webhooks
* **Admin Dashboard** — Beautiful admin interface with real-time build status monitoring
* **No Coding Required** — Everything is managed from the WordPress admin area

= How It Works =

1. Install and activate the PagePilot plugin
2. Configure your app settings (name, colors, logo)
3. Connect your GitHub account using a personal access token
4. Select your GitHub repository
5. Trigger a build from the admin dashboard
6. Download your native Android APK or iOS build artifact

= Requirements =

* WordPress 6.0 or higher
* PHP 7.4 or higher
* A GitHub account with a personal access token
* GitHub Actions enabled on your repository

== Installation ==

1. Upload the `pagepilot` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to **PagePilot** in your admin sidebar
4. Enter your site URL and API credentials on the Settings tab
5. Connect your GitHub account on the GitHub tab
6. Configure your app settings (name, package name, colors)
7. Click **Build App** to generate your first mobile app

== Frequently Asked Questions ==

= What is PagePilot? =

PagePilot is a WordPress plugin that generates native Android and iOS mobile apps from your WordPress LMS site. It integrates with LearnPress to sync courses and uses GitHub Actions for automated builds.

= Do I need coding skills to use PagePilot? =

No. PagePilot is designed to be fully managed from the WordPress admin dashboard. You don't need to write any code to generate your mobile app.

= Which LMS plugins are supported? =

PagePilot currently supports LearnPress. We plan to add support for additional LMS plugins in future updates.

= How does the GitHub integration work? =

You create a GitHub personal access token, enter it in the PagePilot settings, and the plugin will manage your app repository through the GitHub API. Builds are triggered via GitHub Actions workflows.

= What platforms are supported? =

PagePilot generates both Android APK files and iOS build artifacts. Android builds produce downloadable APK files, while iOS builds produce unsigned Xcode archives that can be distributed through TestFlight or signed for App Store submission.

= Is there a limit on the number of builds? =

There is no limit imposed by the plugin. However, GitHub Actions has free tier limits (2,000 minutes per month for private repos). Builds typically take 5-15 minutes depending on complexity.

= Can I customize the app appearance? =

Yes. You can customize the app name, primary color, logo, and splash screen from the PagePilot settings page. All changes are applied on the next build.

= Does the plugin store any data externally? =

The plugin communicates with the GitHub API to manage builds. No course data or user data is sent to external servers. All data remains on your WordPress installation.

== Screenshots ==

1. **Dashboard** — Overview of your app status, recent builds, and quick actions
2. **Settings** — Configure app name, package name, primary color, and API settings
3. **GitHub Connection** — Connect your GitHub account and select your repository
4. **Build Triggers** — Select platform and trigger new app builds
5. **Build History** — View past builds with status, platform, and download links
6. **System Information** — View plugin and server configuration details

== Changelog ==

= 1.0.0 =
* Initial release
* Dashboard with build overview and quick actions
* App settings configuration (name, package, colors, logo)
* GitHub account integration with personal access token
* Repository selection and management
* Android APK build via GitHub Actions
* iOS build via GitHub Actions (no-codesign)
* Build history tracking with status updates
* Course sync with LearnPress
* Webhook notification support
* REST API for settings and build management
* Responsive admin interface

== Upgrade Notice ==

= 1.0.0 =
Initial release of PagePilot.
