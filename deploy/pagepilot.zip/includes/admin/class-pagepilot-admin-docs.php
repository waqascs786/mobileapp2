<?php
/**
 * PagePilot Admin - Documentation Page
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class PagePilot_Admin_Docs
 *
 * Renders the documentation page with setup guide, prerequisites, troubleshooting, and changelog.
 */
class PagePilot_Admin_Docs {

    /**
     * Plugin version.
     *
     * @var string
     */
    private $version;

    /**
     * Plugin file path.
     *
     * @var string
     */
    private $plugin_file;

    /**
     * Constructor.
     *
     * @param string $version     Plugin version.
     * @param string $plugin_file Plugin main file path.
     */
    public function __construct( $version, $plugin_file ) {
        $this->version     = $version;
        $this->plugin_file = $plugin_file;
    }

    /**
     * Render the documentation page.
     */
    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'pagepilot' ) );
        }
        ?>
        <div class="wrap pagepilot-wrap pagepilot-docs-page">
            <h1><?php esc_html_e( 'PagePilot Documentation', 'pagepilot' ); ?></h1>

            <div class="pagepilot-docs-layout">
                <nav class="pagepilot-docs-nav">
                    <ul>
                        <li><a href="#setup-guide" class="pagepilot-docs-link active"><?php esc_html_e( 'Setup Guide', 'pagepilot' ); ?></a></li>
                        <li><a href="#prerequisites" class="pagepilot-docs-link"><?php esc_html_e( 'Prerequisites', 'pagepilot' ); ?></a></li>
                        <li><a href="#github-token" class="pagepilot-docs-link"><?php esc_html_e( 'GitHub Token', 'pagepilot' ); ?></a></li>
                        <li><a href="#ios-signing" class="pagepilot-docs-link"><?php esc_html_e( 'iOS Code Signing', 'pagepilot' ); ?></a></li>
                        <li><a href="#troubleshooting" class="pagepilot-docs-link"><?php esc_html_e( 'Troubleshooting', 'pagepilot' ); ?></a></li>
                        <li><a href="#video-tutorials" class="pagepilot-docs-link"><?php esc_html_e( 'Video Tutorials', 'pagepilot' ); ?></a></li>
                        <li><a href="#changelog" class="pagepilot-docs-link"><?php esc_html_e( 'Changelog', 'pagepilot' ); ?></a></li>
                    </ul>
                </nav>

                <div class="pagepilot-docs-content">

                    <section id="setup-guide" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'Setup Guide', 'pagepilot' ); ?></h2>

                        <div class="pagepilot-steps">
                            <div class="pagepilot-step">
                                <div class="pagepilot-step-number">1</div>
                                <div class="pagepilot-step-content">
                                    <h3><?php esc_html_e( 'Install & Activate PagePilot', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Install the PagePilot plugin from the WordPress plugin directory and activate it. You will see the PagePilot menu in your admin sidebar.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-step">
                                <div class="pagepilot-step-number">2</div>
                                <div class="pagepilot-step-content">
                                    <h3><?php esc_html_e( 'Configure LMS Plugin', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Navigate to PagePilot > LMS Settings and select your active LMS plugin from the dropdown. Click "Sync Courses" to import your course data.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-step">
                                <div class="pagepilot-step-number">3</div>
                                <div class="pagepilot-step-content">
                                    <h3><?php esc_html_e( 'Set Up GitHub Connection', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Go to PagePilot > GitHub Settings. Enter your GitHub Personal Access Token and repository name. Click "Test Connection" to verify.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-step">
                                <div class="pagepilot-step-number">4</div>
                                <div class="pagepilot-step-content">
                                    <h3><?php esc_html_e( 'Configure App Settings', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Visit PagePilot > App Settings to customize your app name, branding colors, logo, and enable/disable features. These settings will be applied during the build.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-step">
                                <div class="pagepilot-step-number">5</div>
                                <div class="pagepilot-step-content">
                                    <h3><?php esc_html_e( 'Build Your App', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Go to PagePilot > Builds and click "New Build". Select your repository and branch, then click "Start Build". The build process will run on GitHub Actions.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-step">
                                <div class="pagepilot-step-number">6</div>
                                <div class="pagepilot-step-content">
                                    <h3><?php esc_html_e( 'Download & Distribute', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Once the build is complete, download the artifacts. For iOS, you will need to sign the app with your Apple Developer certificate. For Android, you can distribute the APK directly.', 'pagepilot' ); ?></p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section id="prerequisites" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'Prerequisites', 'pagepilot' ); ?></h2>

                        <div class="pagepilot-checklist">
                            <h3><?php esc_html_e( 'Before You Start', 'pagepilot' ); ?></h3>
                            <ul class="pagepilot-prereq-list">
                                <li>
                                    <span class="dashicons dashicons-yes-alt pagepilot-text-success"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'WordPress with LMS Plugin', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'A WordPress installation with one of the supported LMS plugins (LearnPress, LifterLMS, Tutor LMS, Sensei LMS, LearnDash, or MasterStudy LMS) installed and configured.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <span class="dashicons dashicons-yes-alt pagepilot-text-success"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'GitHub Account', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'A GitHub account (free tier works). This is used to build your mobile app using GitHub Actions.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <span class="dashicons dashicons-yes-alt pagepilot-text-success"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'GitHub Personal Access Token', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'A Personal Access Token with "repo" and "workflow" scopes to allow PagePilot to trigger builds on your behalf.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <span class="dashicons dashicons-yes-alt pagepilot-text-success"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'SSL/HTTPS Enabled', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'Your WordPress site must have SSL/HTTPS enabled for secure API communication with the mobile app.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <span class="dashicons dashicons-yes-alt pagepilot-text-success"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'REST API Enabled', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'The WordPress REST API must be accessible. Some security plugins may block REST API requests — ensure it is allowed.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                            </ul>
                        </div>

                        <div class="pagepilot-checklist">
                            <h3><?php esc_html_e( 'For iOS Builds (Optional)', 'pagepilot' ); ?></h3>
                            <ul class="pagepilot-prereq-list">
                                <li>
                                    <span class="dashicons dashicons-yes pagepilot-text-muted"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'Apple Developer Account', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'Required for distributing to the App Store. A paid account ($99/year) is needed for code signing.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <span class="dashicons dashicons-yes pagepilot-text-muted"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'App Store Connect App', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'An app entry in App Store Connect with a Bundle ID matching your configured package name.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                            </ul>
                        </div>

                        <div class="pagepilot-checklist">
                            <h3><?php esc_html_e( 'For Android Builds (Optional)', 'pagepilot' ); ?></h3>
                            <ul class="pagepilot-prereq-list">
                                <li>
                                    <span class="dashicons dashicons-yes pagepilot-text-muted"></span>
                                    <div>
                                        <strong><?php esc_html_e( 'Google Play Developer Account', 'pagepilot' ); ?></strong>
                                        <p><?php esc_html_e( 'Required for distributing to the Google Play Store. A one-time $25 fee is needed.', 'pagepilot' ); ?></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </section>

                    <section id="github-token" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'How to Generate a GitHub Personal Access Token', 'pagepilot' ); ?></h2>

                        <div class="pagepilot-guide-steps">
                            <ol>
                                <li>
                                    <p>
                                        <?php
                                        printf(
                                            /* translators: %s: URL link */
                                            esc_html__( 'Go to %sGitHub Token Settings%s.', 'pagepilot' ),
                                            '<a href="https://github.com/settings/tokens/new?scopes=repo,workflow&description=PagePilot" target="_blank" rel="noopener noreferrer">',
                                            '</a>'
                                        );
                                        ?>
                                    </p>
                                </li>
                                <li>
                                    <p><?php esc_html_e( 'Give your token a descriptive name, such as "PagePilot Build Token".', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <p><?php esc_html_e( 'Set the expiration to your preferred duration (90 days recommended for security).', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <p><?php esc_html_e( 'Under "Select scopes", check the following:', 'pagepilot' ); ?></p>
                                    <ul>
                                        <li><code>repo</code> — <?php esc_html_e( 'Full control of private repositories (required to access your code).', 'pagepilot' ); ?></li>
                                        <li><code>workflow</code> — <?php esc_html_e( 'Update GitHub Action workflows (required to trigger builds).', 'pagepilot' ); ?></li>
                                    </ul>
                                </li>
                                <li>
                                    <p><?php esc_html_e( 'Click "Generate token" and copy it immediately. You won\'t be able to see it again.', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <p><?php esc_html_e( 'Paste the token into PagePilot > GitHub Settings > Personal Access Token.', 'pagepilot' ); ?></p>
                                </li>
                            </ol>
                        </div>

                        <div class="pagepilot-screenshot-placeholder">
                            <div class="pagepilot-screenshot">
                                <span class="dashicons dashicons-format-image"></span>
                                <p><?php esc_html_e( 'GitHub Token Creation Screen', 'pagepilot' ); ?></p>
                            </div>
                            <p class="description"><?php esc_html_e( 'Screenshot: GitHub token creation page showing repository and workflow scopes selected.', 'pagepilot' ); ?></p>
                        </div>

                        <div class="pagepilot-notice pagepilot-notice-warning">
                            <span class="dashicons dashicons-warning"></span>
                            <p>
                                <strong><?php esc_html_e( 'Security Warning:', 'pagepilot' ); ?></strong>
                                <?php esc_html_e( 'Keep your token secret. Never commit it to version control or share it publicly. If compromised, revoke it immediately at GitHub Settings > Developer settings > Personal access tokens.', 'pagepilot' ); ?>
                            </p>
                        </div>
                    </section>

                    <section id="ios-signing" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'How to Set Up iOS Code Signing', 'pagepilot' ); ?></h2>

                        <p><?php esc_html_e( 'To distribute your iOS app, you need to code sign it with your Apple Developer certificate. Follow these steps:', 'pagepilot' ); ?></p>

                        <div class="pagepilot-guide-steps">
                            <ol>
                                <li>
                                    <h4><?php esc_html_e( 'Create an App ID', 'pagepilot' ); ?></h4>
                                    <p><?php esc_html_e( 'Go to Apple Developer > Identifiers and create a new App ID matching your configured package name (e.g., com.yourcompany.appname).', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <h4><?php esc_html_e( 'Create a Distribution Certificate', 'pagepilot' ); ?></h4>
                                    <p><?php esc_html_e( 'In Apple Developer > Certificates, create a new "iOS Distribution" certificate. Follow the instructions to generate a Certificate Signing Request (CSR) using Keychain Access on your Mac.', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <h4><?php esc_html_e( 'Create a Provisioning Profile', 'pagepilot' ); ?></h4>
                                    <p><?php esc_html_e( 'Create a new "App Store" provisioning profile and link it to your App ID and distribution certificate.', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <h4><?php esc_html_e( 'Export Certificates', 'pagepilot' ); ?></h4>
                                    <p><?php esc_html_e( 'Export your certificate and provisioning profile as .p12 and .mobileprovision files. You will need these for CI/CD builds.', 'pagepilot' ); ?></p>
                                </li>
                                <li>
                                    <h4><?php esc_html_e( 'Configure in Repository', 'pagepilot' ); ?></h4>
                                    <p><?php esc_html_e( 'Add your certificate and provisioning profile as GitHub repository secrets. The PagePilot build workflow will use them to sign your app automatically.', 'pagepilot' ); ?></p>
                                </li>
                            </ol>
                        </div>

                        <div class="pagepilot-screenshot-placeholder">
                            <div class="pagepilot-screenshot">
                                <span class="dashicons dashicons-format-image"></span>
                                <p><?php esc_html_e( 'Apple Developer Certificates Page', 'pagepilot' ); ?></p>
                            </div>
                            <p class="description"><?php esc_html_e( 'Screenshot: Apple Developer portal showing certificate creation.', 'pagepilot' ); ?></p>
                        </div>
                    </section>

                    <section id="troubleshooting" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'Troubleshooting FAQ', 'pagepilot' ); ?></h2>

                        <div class="pagepilot-faq">
                            <div class="pagepilot-faq-item">
                                <h3 class="pagepilot-faq-question">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    <?php esc_html_e( 'My courses are not syncing. What should I do?', 'pagepilot' ); ?>
                                </h3>
                                <div class="pagepilot-faq-answer">
                                    <ol>
                                        <li><?php esc_html_e( 'Ensure your LMS plugin is installed and activated.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Verify that you have published courses in your LMS.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Check that the correct LMS plugin is selected in PagePilot > LMS Settings.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Try clicking "Sync Courses" again after a few seconds.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Check the WordPress error log for any PHP errors.', 'pagepilot' ); ?></li>
                                    </ol>
                                </div>
                            </div>

                            <div class="pagepilot-faq-item">
                                <h3 class="pagepilot-faq-question">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    <?php esc_html_e( 'The GitHub connection test fails. How do I fix it?', 'pagepilot' ); ?>
                                </h3>
                                <div class="pagepilot-faq-answer">
                                    <ol>
                                        <li><?php esc_html_e( 'Verify your Personal Access Token has the correct scopes (repo + workflow).', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Ensure the repository name is in the correct format: owner/repo-name.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Check that the token has not expired at GitHub Settings > Developer settings > Personal access tokens.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Confirm your server can reach api.github.com (check firewall/proxy settings).', 'pagepilot' ); ?></li>
                                    </ol>
                                </div>
                            </div>

                            <div class="pagepilot-faq-item">
                                <h3 class="pagepilot-faq-question">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    <?php esc_html_e( 'My build fails with "workflow not found". What does this mean?', 'pagepilot' ); ?>
                                </h3>
                                <div class="pagepilot-faq-answer">
                                    <p><?php esc_html_e( 'This means the build.yml workflow file does not exist in your repository\'s .github/workflows/ directory. Ensure you have forked or cloned the PagePilot template repository correctly.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-faq-item">
                                <h3 class="pagepilot-faq-question">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    <?php esc_html_e( 'The app builds but crashes on launch. What should I check?', 'pagepilot' ); ?>
                                </h3>
                                <div class="pagepilot-faq-answer">
                                    <ol>
                                        <li><?php esc_html_e( 'Verify your REST API endpoint is accessible from a mobile device.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Check that your SSL certificate is valid and not self-signed.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Ensure the package name matches what is configured in the app settings.', 'pagepilot' ); ?></li>
                                        <li><?php esc_html_e( 'Review the build logs for any configuration errors.', 'pagepilot' ); ?></li>
                                    </ol>
                                </div>
                            </div>

                            <div class="pagepilot-faq-item">
                                <h3 class="pagepilot-faq-question">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    <?php esc_html_e( 'How do I update the app after making changes?', 'pagepilot' ); ?>
                                </h3>
                                <div class="pagepilot-faq-answer">
                                    <p><?php esc_html_e( 'Simply go to PagePilot > Builds, click "New Build", and trigger a new build. Each build creates a new version. Increment the build number in App Settings before each release.', 'pagepilot' ); ?></p>
                                </div>
                            </div>

                            <div class="pagepilot-faq-item">
                                <h3 class="pagepilot-faq-question">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    <?php esc_html_e( 'Can I customize the app beyond what the settings offer?', 'pagepilot' ); ?>
                                </h3>
                                <div class="pagepilot-faq-answer">
                                    <p><?php esc_html_e( 'Yes! The generated app is open source. After building, you can download the source code and make any modifications you need. The Advanced Settings tab also allows custom API endpoints and headers.', 'pagepilot' ); ?></p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section id="video-tutorials" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'Video Tutorials', 'pagepilot' ); ?></h2>

                        <div class="pagepilot-video-grid">
                            <div class="pagepilot-video-card">
                                <div class="pagepilot-video-thumbnail">
                                    <span class="dashicons dashicons-playback"></span>
                                </div>
                                <div class="pagepilot-video-info">
                                    <h3><?php esc_html_e( 'Getting Started with PagePilot', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Learn the basics of setting up PagePilot and creating your first build.', 'pagepilot' ); ?></p>
                                    <a href="https://pagepilot.dev/tutorials/getting-started" target="_blank" rel="noopener noreferrer" class="button button-small">
                                        <?php esc_html_e( 'Watch Tutorial', 'pagepilot' ); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="pagepilot-video-card">
                                <div class="pagepilot-video-thumbnail">
                                    <span class="dashicons dashicons-playback"></span>
                                </div>
                                <div class="pagepilot-video-info">
                                    <h3><?php esc_html_e( 'Configuring LMS Integration', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Step-by-step guide to connecting your LMS plugin with PagePilot.', 'pagepilot' ); ?></p>
                                    <a href="https://pagepilot.dev/tutorials/lms-setup" target="_blank" rel="noopener noreferrer" class="button button-small">
                                        <?php esc_html_e( 'Watch Tutorial', 'pagepilot' ); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="pagepilot-video-card">
                                <div class="pagepilot-video-thumbnail">
                                    <span class="dashicons dashicons-playback"></span>
                                </div>
                                <div class="pagepilot-video-info">
                                    <h3><?php esc_html_e( 'Setting Up GitHub for Builds', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'How to create tokens, set up repositories, and configure GitHub Actions.', 'pagepilot' ); ?></p>
                                    <a href="https://pagepilot.dev/tutorials/github-setup" target="_blank" rel="noopener noreferrer" class="button button-small">
                                        <?php esc_html_e( 'Watch Tutorial', 'pagepilot' ); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="pagepilot-video-card">
                                <div class="pagepilot-video-thumbnail">
                                    <span class="dashicons dashicons-playback"></span>
                                </div>
                                <div class="pagepilot-video-info">
                                    <h3><?php esc_html_e( 'Publishing to App Stores', 'pagepilot' ); ?></h3>
                                    <p><?php esc_html_e( 'Complete walkthrough of submitting your app to the Apple App Store and Google Play.', 'pagepilot' ); ?></p>
                                    <a href="https://pagepilot.dev/tutorials/app-store-publishing" target="_blank" rel="noopener noreferrer" class="button button-small">
                                        <?php esc_html_e( 'Watch Tutorial', 'pagepilot' ); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section id="changelog" class="pagepilot-docs-section">
                        <h2><?php esc_html_e( 'Changelog', 'pagepilot' ); ?></h2>

                        <div class="pagepilot-changelog">
                            <div class="pagepilot-changelog-entry">
                                <h3>
                                    <span class="pagepilot-changelog-version">v<?php echo esc_html( $this->version ); ?></span>
                                    <span class="pagepilot-changelog-date"><?php echo esc_html( gmdate( 'F j, Y' ) ); ?></span>
                                </h3>
                                <ul>
                                    <li><?php esc_html_e( 'Initial release of PagePilot WordPress plugin.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'LMS integration with LearnPress, LifterLMS, Tutor LMS, Sensei, LearnDash, and MasterStudy.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'GitHub Actions build pipeline integration.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'App customization: colors, logo, splash screen, and feature toggles.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'Build history and status tracking.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'Course sync from LMS plugins.', 'pagepilot' ); ?></li>
                                </ul>
                            </div>

                            <div class="pagepilot-changelog-entry">
                                <h3>
                                    <span class="pagepilot-changelog-version">v1.1.0</span>
                                    <span class="pagepilot-changelog-date"><?php esc_html_e( 'Upcoming', 'pagepilot' ); ?></span>
                                </h3>
                                <ul>
                                    <li><?php esc_html_e( 'Push notifications support.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'Social login integration (Google, Apple).', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'Offline mode for downloaded courses.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'Enhanced build configuration options.', 'pagepilot' ); ?></li>
                                    <li><?php esc_html_e( 'Webhook support for build notifications.', 'pagepilot' ); ?></li>
                                </ul>
                            </div>
                        </div>
                    </section>

                </div>
            </div>
        </div>
        <?php
    }
}
