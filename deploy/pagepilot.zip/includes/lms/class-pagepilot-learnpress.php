<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * LearnPress LMS handler.
 *
 * Integrates with LearnPress REST API at /wp-json/lp/v1/
 * Normalizes all data to PagePilot's standard format.
 */
class PagePilot_LearnPress extends PagePilot_LMS_Base {

    protected $lms_key = 'learnpress';
    protected $api_base = '/wp-json/lp/v1';

    private $request_timeout = 15;

    /**
     * Fetch courses with pagination, search, and category filters.
     *
     * @param array $args {
     *     @type int    $page     Page number. Default 1.
     *     @type int    $per_page Items per page. Default 12.
     *     @type string $search   Search keyword.
     *     @type int    $category Category ID to filter by.
     *     @type string $orderby  Order by field. Default 'date'.
     *     @type string $order    ASC or DESC. Default 'DESC'.
     * }
     * @return array{
     *     courses: array,
     *     total: int,
     *     pages: int,
     *     current_page: int,
     * }
     */
    public function get_courses( $args = array() ) {
        $defaults = array(
            'page'     => 1,
            'per_page' => 12,
            'search'   => '',
            'category' => 0,
            'orderby'  => 'date',
            'order'    => 'DESC',
            'status'   => 'publish',
        );
        $args = wp_parse_args( $args, $defaults );

        $cache_key = 'lp_courses_' . md5( wp_json_encode( $args ) );
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $endpoint = '/courses/archive-course';
        $params = array(
            'page'     => $args['page'],
            'per_page' => $args['per_page'],
            'orderby'  => $args['orderby'],
            'order'    => $args['order'],
            'status'   => $args['status'],
        );

        if ( ! empty( $args['search'] ) ) {
            $params['search'] = sanitize_text_field( $args['search'] );
        }

        if ( ! empty( $args['category'] ) ) {
            $params['cat'] = absint( $args['category'] );
        }

        $response = $this->make_api_request( $endpoint, $params );

        if ( is_wp_error( $response ) ) {
            $this->log_error( $response->get_error_message(), 'get_courses' );
            return array(
                'courses'      => array(),
                'total'        => 0,
                'pages'        => 0,
                'current_page' => $args['page'],
            );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $total = 0;
        $pages = 0;

        $total_header = wp_remote_retrieve_header( $response, 'x-wp-total' );
        $pages_header = wp_remote_retrieve_header( $response, 'x-wp-totalpages' );
        if ( $total_header ) {
            $total = (int) $total_header;
        }
        if ( $pages_header ) {
            $pages = (int) $pages_header;
        }

        $courses = array();
        $raw_courses = isset( $body['courses'] ) ? $body['courses'] : ( isset( $body['items'] ) ? $body['items'] : array() );

        if ( is_array( $raw_courses ) ) {
            foreach ( $raw_courses as $raw ) {
                $courses[] = $this->format_course( $raw );
            }
        }

        if ( ! $total && ! empty( $body['total'] ) ) {
            $total = (int) $body['total'];
        }
        if ( ! $pages && $total && $args['per_page'] > 0 ) {
            $pages = (int) ceil( $total / $args['per_page'] );
        }

        $result = array(
            'courses'      => $courses,
            'total'        => $total,
            'pages'        => $pages,
            'current_page' => $args['page'],
        );

        $this->cache_set( $cache_key, $result, 'pagepilot_lms', 5 * MINUTE_IN_SECONDS );
        return $result;
    }

    /**
     * Get a single course with full details including curriculum.
     *
     * @param int $id Course ID.
     * @return array|null Normalized course data or null on failure.
     */
    public function get_course( $id ) {
        $id = absint( $id );
        if ( ! $id ) {
            return null;
        }

        $cache_key = 'lp_course_' . $id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $endpoint = '/courses/' . $id;
        $response = $this->make_api_request( $endpoint );

        if ( is_wp_error( $response ) ) {
            $this->log_error( $response->get_error_message(), 'get_course' );
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body ) ) {
            return null;
        }

        $course = $this->format_course( $body );

        $this->cache_set( $cache_key, $course, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
        $this->store_in_cache_table( 'course', $id, $course );

        return $course;
    }

    /**
     * Get lessons for a course from its curriculum.
     *
     * @param int $course_id Course ID.
     * @return array List of normalized lesson data.
     */
    public function get_lessons( $course_id ) {
        $course_id = absint( $course_id );
        if ( ! $course_id ) {
            return array();
        }

        $cache_key = 'lp_lessons_' . $course_id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $course = $this->get_course( $course_id );
        $lessons = array();

        if ( empty( $course['curriculum'] ) ) {
            $this->cache_set( $cache_key, $lessons, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
            return $lessons;
        }

        foreach ( $course['curriculum'] as $section ) {
            if ( empty( $section['items'] ) ) {
                continue;
            }
            foreach ( $section['items'] as $item ) {
                if ( $item['type'] === 'lesson' ) {
                    $lesson_data = $this->get_lesson( $item['id'] );
                    if ( $lesson_data ) {
                        $lessons[] = $lesson_data;
                    }
                }
            }
        }

        $this->cache_set( $cache_key, $lessons, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
        return $lessons;
    }

    /**
     * Get a single lesson with content.
     *
     * @param int $id Lesson ID.
     * @return array|null Normalized lesson data or null on failure.
     */
    public function get_lesson( $id ) {
        $id = absint( $id );
        if ( ! $id ) {
            return null;
        }

        $cache_key = 'lp_lesson_' . $id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $response = $this->make_api_request( '/lessons/' . $id );

        if ( is_wp_error( $response ) ) {
            $this->log_error( $response->get_error_message(), 'get_lesson' );
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body ) ) {
            return null;
        }

        $lesson = $this->format_lesson( $body );

        $this->cache_set( $cache_key, $lesson, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
        $this->store_in_cache_table( 'lesson', $id, $lesson );

        return $lesson;
    }

    /**
     * Get quizzes for a course from its curriculum.
     *
     * @param int $course_id Course ID.
     * @return array List of normalized quiz data.
     */
    public function get_quizzes( $course_id ) {
        $course_id = absint( $course_id );
        if ( ! $course_id ) {
            return array();
        }

        $cache_key = 'lp_quizzes_' . $course_id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $course = $this->get_course( $course_id );
        $quizzes = array();

        if ( empty( $course['curriculum'] ) ) {
            $this->cache_set( $cache_key, $quizzes, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
            return $quizzes;
        }

        foreach ( $course['curriculum'] as $section ) {
            if ( empty( $section['items'] ) ) {
                continue;
            }
            foreach ( $section['items'] as $item ) {
                if ( $item['type'] === 'quiz' ) {
                    $quiz_data = $this->get_quiz( $item['id'] );
                    if ( $quiz_data ) {
                        $quizzes[] = $quiz_data;
                    }
                }
            }
        }

        $this->cache_set( $cache_key, $quizzes, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
        return $quizzes;
    }

    /**
     * Get a single quiz with questions and settings.
     *
     * @param int $id Quiz ID.
     * @return array|null Normalized quiz data or null on failure.
     */
    public function get_quiz( $id ) {
        $id = absint( $id );
        if ( ! $id ) {
            return null;
        }

        $cache_key = 'lp_quiz_' . $id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $response = $this->make_api_request( '/quizzes/' . $id );

        if ( is_wp_error( $response ) ) {
            $this->log_error( $response->get_error_message(), 'get_quiz' );
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body ) ) {
            return null;
        }

        $quiz = $this->format_quiz( $body );

        $this->cache_set( $cache_key, $quiz, 'pagepilot_lms', 10 * MINUTE_IN_SECONDS );
        $this->store_in_cache_table( 'quiz', $id, $quiz );

        return $quiz;
    }

    /**
     * Get user's progress for a course.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID. Defaults to current user.
     * @return array{
     *     completed_lessons: int,
     *     total_lessons: int,
     *     percentage: float,
     *     completed_items: array,
     *     status: string,
     *     last_activity: string|null,
     * }
     */
    public function get_course_progress( $course_id, $user_id = 0 ) {
        $course_id = absint( $course_id );
        $user_id   = $user_id ? absint( $user_id ) : get_current_user_id();

        if ( ! $course_id || ! $user_id ) {
            return array(
                'completed_lessons' => 0,
                'total_lessons'     => 0,
                'percentage'        => 0,
                'completed_items'   => array(),
                'status'            => 'not_enrolled',
                'last_activity'     => null,
            );
        }

        $cache_key = 'lp_progress_' . $course_id . '_' . $user_id;
        $cached = $this->cache_get( $cache_key, 'pagepilot_lms_progress' );
        if ( $cached !== false ) {
            return $cached;
        }

        $progress = $this->calculate_progress_from_lp( $course_id, $user_id );

        $this->cache_set( $cache_key, $progress, 'pagepilot_lms_progress', 2 * MINUTE_IN_SECONDS );
        return $progress;
    }

    /**
     * Get all course categories.
     *
     * @return array List of categories with id, name, slug, count.
     */
    public function get_categories() {
        $cache_key = 'lp_categories';
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $terms = get_terms( array(
            'taxonomy'   => 'course_cat',
            'hide_empty' => true,
        ) );

        if ( is_wp_error( $terms ) ) {
            $this->log_error( $terms->get_error_message(), 'get_categories' );
            return array();
        }

        $categories = array();
        foreach ( $terms as $term ) {
            $categories[] = array(
                'id'    => (int) $term->term_id,
                'name'  => $term->name,
                'slug'  => $term->slug,
                'count' => (int) $term->count,
            );
        }

        $this->cache_set( $cache_key, $categories, 'pagepilot_lms', 30 * MINUTE_IN_SECONDS );
        return $categories;
    }

    /**
     * Get all course tags.
     *
     * @return array List of tags with id, name, slug, count.
     */
    public function get_tags() {
        $cache_key = 'lp_tags';
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $terms = get_terms( array(
            'taxonomy'   => 'course_tag',
            'hide_empty' => true,
        ) );

        if ( is_wp_error( $terms ) ) {
            $this->log_error( $terms->get_error_message(), 'get_tags' );
            return array();
        }

        $tags = array();
        foreach ( $terms as $term ) {
            $tags[] = array(
                'id'    => (int) $term->term_id,
                'name'  => $term->name,
                'slug'  => $term->slug,
                'count' => (int) $term->count,
            );
        }

        $this->cache_set( $cache_key, $tags, 'pagepilot_lms', 30 * MINUTE_IN_SECONDS );
        return $tags;
    }

    /**
     * Get LearnPress instructors.
     *
     * @return array List of instructors with id, name, avatar, description, course_count.
     */
    public function get_instructors() {
        $cache_key = 'lp_instructors';
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $instructors = array();

        $response = $this->make_api_request( '/instructors' );

        if ( ! is_wp_error( $response ) ) {
            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            $raw_instructors = isset( $body['instructors'] ) ? $body['instructors'] : ( is_array( $body ) ? $body : array() );

            foreach ( $raw_instructors as $raw ) {
                $user_id = isset( $raw['id'] ) ? (int) $raw['id'] : ( isset( $raw['user_id'] ) ? (int) $raw['user_id'] : 0 );
                if ( ! $user_id ) {
                    continue;
                }

                $display_name = isset( $raw['display_name'] ) ? $raw['display_name'] : ( isset( $raw['name'] ) ? $raw['name'] : '' );
                $avatar_url  = isset( $raw['avatar_url'] ) ? $raw['avatar_url'] : get_avatar_url( $user_id, array( 'size' => 150 ) );
                $description = isset( $raw['description'] ) ? $raw['description'] : '';
                $course_count = isset( $raw['course_count'] ) ? (int) $raw['course_count'] : 0;

                if ( ! $display_name ) {
                    $user_obj = get_userdata( $user_id );
                    $display_name = $user_obj ? $user_obj->display_name : '';
                }

                $instructors[] = array(
                    'id'          => $user_id,
                    'name'        => $display_name,
                    'avatar'      => $avatar_url,
                    'description' => wp_strip_all_tags( $description ),
                    'course_count' => $course_count,
                );
            }
        }

        if ( empty( $instructors ) ) {
            $instructors = $this->get_instructors_from_courses();
        }

        $this->cache_set( $cache_key, $instructors, 'pagepilot_lms', 30 * MINUTE_IN_SECONDS );
        return $instructors;
    }

    /**
     * Sync all courses to the pagepilot_course_cache table.
     *
     * @return array{
     *     synced: int,
     *     errors: int,
     * }
     */
    public function sync_courses() {
        $page     = 1;
        $per_page = 50;
        $synced   = 0;
        $errors   = 0;

        do {
            $result = $this->get_courses( array(
                'page'     => $page,
                'per_page' => $per_page,
                'status'   => 'publish',
            ) );

            if ( empty( $result['courses'] ) ) {
                break;
            }

            foreach ( $result['courses'] as $course ) {
                if ( empty( $course['id'] ) ) {
                    $errors++;
                    continue;
                }

                $full_course = $this->get_course( $course['id'] );
                if ( $full_course ) {
                    $this->store_in_cache_table( 'course', $course['id'], $full_course );
                    $synced++;

                    if ( ! empty( $full_course['curriculum'] ) ) {
                        foreach ( $full_course['curriculum'] as $section ) {
                            if ( empty( $section['items'] ) ) {
                                continue;
                            }
                            foreach ( $section['items'] as $item ) {
                                if ( $item['type'] === 'lesson' ) {
                                    $lesson = $this->get_lesson( $item['id'] );
                                    if ( $lesson ) {
                                        $this->store_in_cache_table( 'lesson', $item['id'], $lesson );
                                    }
                                } elseif ( $item['type'] === 'quiz' ) {
                                    $quiz = $this->get_quiz( $item['id'] );
                                    if ( $quiz ) {
                                        $this->store_in_cache_table( 'quiz', $item['id'], $quiz );
                                    }
                                }
                            }
                        }
                    }
                } else {
                    $errors++;
                }
            }

            $page++;
        } while ( $page <= $result['pages'] );

        $this->cache_delete( 'lp_courses_' );
        $this->cache_delete( 'lp_categories' );
        $this->cache_delete( 'lp_tags' );
        $this->cache_delete( 'lp_instructors' );

        return array(
            'synced' => $synced,
            'errors' => $errors,
        );
    }

    /**
     * Make an authenticated request to the LearnPress REST API.
     *
     * @param string $endpoint API endpoint path (e.g. '/courses').
     * @param array  $params   Query parameters.
     * @return WP_Error|WP_Response
     */
    private function make_api_request( $endpoint, $params = array() ) {
        $url = home_url( $this->api_base . $endpoint );

        $defaults = array(
            'timeout' => $this->request_timeout,
            'headers' => array(
                'Accept'       => 'application/json',
                'Content-Type' => 'application/json',
            ),
        );

        $auth_headers = $this->get_auth_headers();
        if ( $auth_headers ) {
            $defaults['headers'] = array_merge( $defaults['headers'], $auth_headers );
        }

        if ( ! empty( $params ) ) {
            $url = add_query_arg( $params, $url );
        }

        $response = wp_remote_get( $url, $defaults );

        if ( is_wp_error( $response ) ) {
            $this->log_error( $response->get_error_message(), 'api_request' );
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code >= 400 ) {
            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            $message = isset( $body['message'] ) ? $body['message'] : 'HTTP ' . $code;
            $this->log_error( 'API error ' . $code . ': ' . $message, 'api_request' );
            return new WP_Error( 'lp_api_error', $message, array( 'status' => $code ) );
        }

        return $response;
    }

    /**
     * Get authentication headers for API requests.
     *
     * @return array|null Headers array or null if no auth available.
     */
    private function get_auth_headers() {
        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return null;
        }

        $token = get_user_meta( $user_id, '_lp_token', true );
        if ( $token ) {
            return array( 'X-LP-Token' => $token );
        }

        return null;
    }

    /**
     * Normalize raw LearnPress course data to standard format.
     *
     * @param array $raw_course Raw course data from LearnPress API or WP_Post.
     * @return array Normalized course data.
     */
    private function format_course( $raw_course ) {
        $id = isset( $raw_course['id'] ) ? (int) $raw_course['id'] : ( isset( $raw_course['ID'] ) ? (int) $raw_course['ID'] : 0 );

        $price = '';
        if ( isset( $raw_course['price'] ) ) {
            $price = is_array( $raw_course['price'] ) ? ( isset( $raw_course['price']['regular'] ) ? $raw_course['price']['regular'] : '' ) : $raw_course['price'];
        } elseif ( $id ) {
            $price = get_post_meta( $id, '_lp_price', true );
        }
        if ( is_numeric( $price ) ) {
            $price = (float) $price > 0 ? get_currency_symbol() . number_format( (float) $price, 2 ) : __( 'Free', 'pagepilot' );
        } elseif ( $price === '' || $price === '0' ) {
            $price = __( 'Free', 'pagepilot' );
        }

        $duration = '';
        if ( isset( $raw_course['duration'] ) ) {
            $duration = $raw_course['duration'];
        } elseif ( $id ) {
            $meta_duration = get_post_meta( $id, '_lp_duration', true );
            if ( $meta_duration ) {
                $duration = is_array( $meta_duration )
                    ? ( isset( $meta_duration['value'] ) ? $meta_duration['value'] . ' ' . ( isset( $meta_duration['unit'] ) ? $meta_duration['unit'] : '' ) : '' )
                    : $meta_duration;
            }
        }

        $instructor = array( 'name' => '', 'avatar' => '' );
        if ( ! empty( $raw_course['author'] ) ) {
            $author = $raw_course['author'];
            $instructor = array(
                'name'   => isset( $author['name'] ) ? $author['name'] : ( isset( $author['display_name'] ) ? $author['display_name'] : '' ),
                'avatar' => isset( $author['avatar_url'] ) ? $author['avatar_url'] : ( isset( $author['avatar'] ) ? $author['avatar'] : '' ),
            );
        } elseif ( ! empty( $raw_course['instructor'] ) ) {
            $instr = $raw_course['instructor'];
            if ( is_array( $instr ) && ! empty( $instr[0] ) ) {
                $instr = $instr[0];
            }
            $instructor = array(
                'name'   => isset( $instr['display_name'] ) ? $instr['display_name'] : ( isset( $instr['name'] ) ? $instr['name'] : '' ),
                'avatar' => isset( $instr['avatar_url'] ) ? $instr['avatar_url'] : ( isset( $instr['avatar'] ) ? $instr['avatar'] : '' ),
            );
        } elseif ( $id ) {
            $author_id = (int) get_post_field( 'post_author', $id );
            if ( $author_id ) {
                $user_data = get_userdata( $author_id );
                if ( $user_data ) {
                    $instructor = array(
                        'name'   => $user_data->display_name,
                        'avatar' => get_avatar_url( $author_id, array( 'size' => 150 ) ),
                    );
                }
            }
        }

        $rating = 0.0;
        if ( isset( $raw_course['rating'] ) ) {
            $rating = (float) $raw_course['rating'];
        } elseif ( isset( $raw_course['average_rating'] ) ) {
            $rating = (float) $raw_course['average_rating'];
        } elseif ( $id ) {
            $rating = (float) get_post_meta( $id, '_lp_average_rating', true );
        }

        $students_count = 0;
        if ( isset( $raw_course['students'] ) ) {
            $students_count = (int) $raw_course['students'];
        } elseif ( isset( $raw_course['enrolled_students_count'] ) ) {
            $students_count = (int) $raw_course['enrolled_students_count'];
        } elseif ( $id ) {
            $students_count = (int) get_post_meta( $id, '_lp_student_count', true );
        }

        $thumbnail = '';
        if ( isset( $raw_course['image'] ) ) {
            $img = $raw_course['image'];
            $thumbnail = is_array( $img ) ? ( isset( $img['url'] ) ? $img['url'] : '' ) : $img;
        } elseif ( isset( $raw_course['thumbnail'] ) ) {
            $thumbnail = is_array( $raw_course['thumbnail'] ) ? $raw_course['thumbnail']['url'] : $raw_course['thumbnail'];
        } elseif ( $id ) {
            $thumb_id = get_post_thumbnail_id( $id );
            if ( $thumb_id ) {
                $thumbnail = wp_get_attachment_image_url( $thumb_id, 'large' );
            }
        }

        $curriculum = $this->extract_curriculum( $raw_course, $id );

        $lessons_count  = 0;
        $quizzes_count  = 0;
        foreach ( $curriculum as $section ) {
            if ( empty( $section['items'] ) ) {
                continue;
            }
            foreach ( $section['items'] as $item ) {
                if ( $item['type'] === 'lesson' ) {
                    $lessons_count++;
                } elseif ( $item['type'] === 'quiz' ) {
                    $quizzes_count++;
                }
            }
        }

        $categories = array();
        if ( ! empty( $raw_course['categories'] ) && is_array( $raw_course['categories'] ) ) {
            foreach ( $raw_course['categories'] as $cat ) {
                $categories[] = is_array( $cat )
                    ? array( 'id' => isset( $cat['id'] ) ? (int) $cat['id'] : 0, 'name' => isset( $cat['name'] ) ? $cat['name'] : '' )
                    : array( 'id' => 0, 'name' => (string) $cat );
            }
        } elseif ( $id ) {
            $cats = get_the_terms( $id, 'course_cat' );
            if ( $cats && ! is_wp_error( $cats ) ) {
                foreach ( $cats as $cat ) {
                    $categories[] = array( 'id' => (int) $cat->term_id, 'name' => $cat->name );
                }
            }
        }

        $tags = array();
        if ( ! empty( $raw_course['tags'] ) && is_array( $raw_course['tags'] ) ) {
            foreach ( $raw_course['tags'] as $tag ) {
                $tags[] = is_array( $tag )
                    ? array( 'id' => isset( $tag['id'] ) ? (int) $tag['id'] : 0, 'name' => isset( $tag['name'] ) ? $tag['name'] : '' )
                    : array( 'id' => 0, 'name' => (string) $tag );
            }
        } elseif ( $id ) {
            $wp_tags = get_the_terms( $id, 'course_tag' );
            if ( $wp_tags && ! is_wp_error( $wp_tags ) ) {
                foreach ( $wp_tags as $tag ) {
                    $tags[] = array( 'id' => (int) $tag->term_id, 'name' => $tag->name );
                }
            }
        }

        $description = '';
        if ( isset( $raw_course['description'] ) ) {
            $description = $raw_course['description'];
        } elseif ( $id ) {
            $description = get_post_field( 'post_content', $id );
        }

        $status = 'publish';
        if ( isset( $raw_course['status'] ) ) {
            $status = $raw_course['status'];
        } elseif ( $id ) {
            $status = get_post_status( $id );
        }

        return array(
            'id'              => $id,
            'title'           => isset( $raw_course['title'] ) ? ( is_array( $raw_course['title'] ) ? wp_strip_all_tags( $raw_course['title']['rendered'] ?? '' ) : wp_strip_all_tags( $raw_course['title'] ) ) : ( $id ? wp_strip_all_tags( get_the_title( $id ) ) : '' ),
            'description'     => $description,
            'thumbnail'       => $thumbnail,
            'price'           => (string) $price,
            'duration'        => (string) $duration,
            'instructor'      => $instructor,
            'rating'          => $rating,
            'students_count'  => $students_count,
            'lessons_count'   => $lessons_count,
            'quizzes_count'   => $quizzes_count,
            'categories'      => $categories,
            'tags'            => $tags,
            'curriculum'      => $curriculum,
            'status'          => $status,
            'url'             => $id ? get_permalink( $id ) : '',
            'date'            => $id ? get_the_date( 'Y-m-d H:i:s', $id ) : '',
            'modified'        => $id ? get_the_modified_date( 'Y-m-d H:i:s', $id ) : '',
        );
    }

    /**
     * Normalize raw LearnPress lesson data to standard format.
     *
     * @param array $raw_lesson Raw lesson data from LP API or WP_Post.
     * @return array Normalized lesson data.
     */
    private function format_lesson( $raw_lesson ) {
        $id = isset( $raw_lesson['id'] ) ? (int) $raw_lesson['id'] : ( isset( $raw_lesson['ID'] ) ? (int) $raw_lesson['ID'] : 0 );

        $content = '';
        if ( isset( $raw_lesson['content'] ) ) {
            $content = is_array( $raw_lesson['content'] ) ? ( $raw_lesson['content']['rendered'] ?? '' ) : $raw_lesson['content'];
        } elseif ( $id ) {
            $content = get_post_field( 'post_content', $id );
        }

        $excerpt = '';
        if ( isset( $raw_lesson['excerpt'] ) ) {
            $excerpt = is_array( $raw_lesson['excerpt'] ) ? ( $raw_lesson['excerpt']['rendered'] ?? '' ) : $raw_lesson['excerpt'];
        } elseif ( $id ) {
            $excerpt = get_post_field( 'post_excerpt', $id );
        }

        $duration = '';
        if ( isset( $raw_lesson['duration'] ) ) {
            $duration = $raw_lesson['duration'];
        } elseif ( $id ) {
            $meta_duration = get_post_meta( $id, '_lp_duration', true );
            if ( $meta_duration ) {
                $duration = is_array( $meta_duration )
                    ? ( isset( $meta_duration['value'] ) ? $meta_duration['value'] . ' ' . ( isset( $meta_duration['unit'] ) ? $meta_duration['unit'] : '' ) : '' )
                    : $meta_duration;
            }
        }

        $thumbnail = '';
        if ( $id ) {
            $thumb_id = get_post_thumbnail_id( $id );
            if ( $thumb_id ) {
                $thumbnail = wp_get_attachment_image_url( $thumb_id, 'large' );
            }
        }

        $course_id = 0;
        if ( isset( $raw_lesson['course_id'] ) ) {
            $course_id = (int) $raw_lesson['course_id'];
        } elseif ( isset( $raw_lesson['parent_id'] ) ) {
            $course_id = (int) $raw_lesson['parent_id'];
        } elseif ( $id ) {
            $course_id = (int) get_post_meta( $id, '_lp_course', true );
        }

        return array(
            'id'          => $id,
            'title'       => isset( $raw_lesson['title'] ) ? ( is_array( $raw_lesson['title'] ) ? wp_strip_all_tags( $raw_lesson['title']['rendered'] ?? '' ) : wp_strip_all_tags( $raw_lesson['title'] ) ) : ( $id ? wp_strip_all_tags( get_the_title( $id ) ) : '' ),
            'content'     => $content,
            'excerpt'     => wp_strip_all_tags( $excerpt ),
            'thumbnail'   => $thumbnail,
            'duration'    => (string) $duration,
            'course_id'   => $course_id,
            'type'        => 'lesson',
            'url'         => $id ? get_permalink( $id ) : '',
            'order'       => isset( $raw_lesson['order'] ) ? (int) $raw_lesson['order'] : 0,
        );
    }

    /**
     * Normalize raw LearnPress quiz data to standard format.
     *
     * @param array $raw_quiz Raw quiz data from LP API or WP_Post.
     * @return array Normalized quiz data.
     */
    private function format_quiz( $raw_quiz ) {
        $id = isset( $raw_quiz['id'] ) ? (int) $raw_quiz['id'] : ( isset( $raw_quiz['ID'] ) ? (int) $raw_quiz['ID'] : 0 );

        $content = '';
        if ( isset( $raw_quiz['content'] ) ) {
            $content = is_array( $raw_quiz['content'] ) ? ( $raw_quiz['content']['rendered'] ?? '' ) : $raw_quiz['content'];
        } elseif ( $id ) {
            $content = get_post_field( 'post_content', $id );
        }

        $questions = array();
        if ( isset( $raw_quiz['questions'] ) && is_array( $raw_quiz['questions'] ) ) {
            foreach ( $raw_quiz['questions'] as $q ) {
                $questions[] = $this->format_question( $q );
            }
        } elseif ( $id ) {
            $questions = $this->get_quiz_questions( $id );
        }

        $duration = '';
        if ( isset( $raw_quiz['duration'] ) ) {
            $duration = $raw_quiz['duration'];
        } elseif ( $id ) {
            $meta_duration = get_post_meta( $id, '_lp_duration', true );
            if ( $meta_duration ) {
                $duration = is_array( $meta_duration )
                    ? ( isset( $meta_duration['value'] ) ? $meta_duration['value'] . ' ' . ( isset( $meta_duration['unit'] ) ? $meta_duration['unit'] : '' ) : '' )
                    : $meta_duration;
            }
        }

        $passing_grade = 0;
        if ( isset( $raw_quiz['passing_grade'] ) ) {
            $passing_grade = (int) $raw_quiz['passing_grade'];
        } elseif ( $id ) {
            $passing_grade = (int) get_post_meta( $id, '_lp_passing_grade', true );
        }

        $max_attempts = 0;
        if ( isset( $raw_quiz['max_attempts'] ) ) {
            $max_attempts = (int) $raw_quiz['max_attempts'];
        } elseif ( $id ) {
            $max_attempts = (int) get_post_meta( $id, '_lp_max_attempts', true );
        }

        $course_id = 0;
        if ( isset( $raw_quiz['course_id'] ) ) {
            $course_id = (int) $raw_quiz['course_id'];
        } elseif ( $id ) {
            $course_id = (int) get_post_meta( $id, '_lp_course', true );
        }

        return array(
            'id'             => $id,
            'title'          => isset( $raw_quiz['title'] ) ? ( is_array( $raw_quiz['title'] ) ? wp_strip_all_tags( $raw_quiz['title']['rendered'] ?? '' ) : wp_strip_all_tags( $raw_quiz['title'] ) ) : ( $id ? wp_strip_all_tags( get_the_title( $id ) ) : '' ),
            'content'        => $content,
            'duration'       => (string) $duration,
            'passing_grade'  => $passing_grade,
            'max_attempts'   => $max_attempts,
            'questions_count' => count( $questions ),
            'questions'      => $questions,
            'course_id'      => $course_id,
            'type'           => 'quiz',
            'url'            => $id ? get_permalink( $id ) : '',
        );
    }

    /**
     * Format a single quiz question.
     *
     * @param array $raw_question Raw question data.
     * @return array Normalized question data.
     */
    private function format_question( $raw_question ) {
        $id = isset( $raw_question['id'] ) ? (int) $raw_question['id'] : 0;

        $type = 'multiple_choice';
        if ( isset( $raw_question['type'] ) ) {
            $type = $raw_question['type'];
        } elseif ( $id ) {
            $type = get_post_meta( $id, '_lp_type', true ) ?: 'multiple_choice';
        }

        $options = array();
        if ( ! empty( $raw_question['options'] ) && is_array( $raw_question['options'] ) ) {
            foreach ( $raw_question['options'] as $option ) {
                $options[] = array(
                    'id'        => isset( $option['id'] ) ? $option['id' ] : '',
                    'value'     => isset( $option['value'] ) ? $option['value'] : ( isset( $option['title'] ) ? $option['title'] : '' ),
                    'is_correct' => ! empty( $option['is_correct'] ),
                );
            }
        } elseif ( $id ) {
            $raw_options = get_post_meta( $id, '_lp_option', true );
            $correct     = get_post_meta( $id, '_lp_option_right', true );
            if ( is_array( $raw_options ) ) {
                foreach ( $raw_options as $idx => $opt ) {
                    $options[] = array(
                        'id'        => $idx,
                        'value'     => $opt,
                        'is_correct' => is_array( $correct ) && in_array( $idx, $correct, true ),
                    );
                }
            }
        }

        return array(
            'id'        => $id,
            'title'     => isset( $raw_question['title'] ) ? wp_strip_all_tags( $raw_question['title'] ) : ( $id ? wp_strip_all_tags( get_the_title( $id ) ) : '' ),
            'content'   => isset( $raw_question['content'] ) ? $raw_question['content'] : ( $id ? get_post_field( 'post_content', $id ) : '' ),
            'type'      => $type,
            'options'   => $options,
            'order'     => isset( $raw_question['order'] ) ? (int) $raw_question['order'] : 0,
        );
    }

    /**
     * Get quiz questions from WP post meta.
     *
     * @param int $quiz_id Quiz post ID.
     * @return array List of formatted questions.
     */
    private function get_quiz_questions( $quiz_id ) {
        $question_ids = get_post_meta( $quiz_id, '_question_ids', true );
        $questions = array();

        if ( empty( $question_ids ) || ! is_array( $question_ids ) ) {
            return $questions;
        }

        foreach ( $question_ids as $q_id ) {
            $q_id = absint( $q_id );
            if ( ! $q_id ) {
                continue;
            }
            $raw = array(
                'id'    => $q_id,
                'title' => get_the_title( $q_id ),
                'type'  => get_post_meta( $q_id, '_lp_type', true ) ?: 'multiple_choice',
            );
            $questions[] = $this->format_question( $raw );
        }

        return $questions;
    }

    /**
     * Extract curriculum structure from raw course data.
     *
     * @param array $raw_course Raw course data.
     * @param int   $course_id  Course post ID for fallback data.
     * @return array Curriculum structure with sections and items.
     */
    private function extract_curriculum( $raw_course, $course_id ) {
        if ( ! empty( $raw_course['curriculum'] ) && is_array( $raw_course['curriculum'] ) ) {
            $curriculum = array();
            foreach ( $raw_course['curriculum'] as $section_idx => $section ) {
                $section_title = '';
                if ( isset( $section['title'] ) ) {
                    $section_title = $section['title'];
                } elseif ( isset( $section['name'] ) ) {
                    $section_title = $section['name'];
                } else {
                    $section_title = sprintf( __( 'Section %d', 'pagepilot' ), $section_idx + 1 );
                }

                $items = array();
                if ( ! empty( $section['items'] ) && is_array( $section['items'] ) ) {
                    foreach ( $section['items'] as $item ) {
                        $item_id    = isset( $item['id'] ) ? (int) $item['id'] : 0;
                        $item_title = isset( $item['title'] ) ? $item['title'] : '';
                        $item_type  = isset( $item['type'] ) ? $item['type'] : ( isset( $item['item_type'] ) ? $item['item_type'] : 'lesson' );
                        $item_duration = '';
                        if ( isset( $item['duration'] ) ) {
                            $item_duration = $item['duration'];
                        }

                        $items[] = array(
                            'type'     => $item_type,
                            'id'       => $item_id,
                            'title'    => $item_title,
                            'duration' => (string) $item_duration,
                        );
                    }
                }

                $curriculum[] = array(
                    'section_title' => $section_title,
                    'items'         => $items,
                );
            }
            return $curriculum;
        }

        if ( $course_id ) {
            return $this->build_curriculum_from_meta( $course_id );
        }

        return array();
    }

    /**
     * Build curriculum from LearnPress post meta when API data lacks curriculum.
     *
     * @param int $course_id Course post ID.
     * @return array Curriculum structure.
     */
    private function build_curriculum_from_meta( $course_id ) {
        $curriculum = array();
        $sections   = get_post_meta( $course_id, '_lp_curriculum', true );

        if ( empty( $sections ) || ! is_array( $sections ) ) {
            $section_ids = get_post_meta( $course_id, '_section_ids', true );
            if ( is_array( $section_ids ) ) {
                foreach ( $section_ids as $s_idx => $s_id ) {
                    $s_id = absint( $s_id );
                    if ( ! $s_id ) {
                        continue;
                    }
                    $section_title = get_the_title( $s_id );
                    $item_ids      = get_post_meta( $s_id, '_item_ids', true );
                    $items         = array();

                    if ( is_array( $item_ids ) ) {
                        foreach ( $item_ids as $item_id ) {
                            $item_id = absint( $item_id );
                            if ( ! $item_id ) {
                                continue;
                            }
                            $post_type = get_post_type( $item_id );
                            $type = 'lesson';
                            if ( $post_type === 'lp_quiz' ) {
                                $type = 'quiz';
                            }

                            $item_duration = '';
                            if ( $type === 'lesson' ) {
                                $meta_dur = get_post_meta( $item_id, '_lp_duration', true );
                                if ( $meta_dur && is_array( $meta_dur ) ) {
                                    $item_duration = ( isset( $meta_dur['value'] ) ? $meta_dur['value'] : '' ) . ' ' . ( isset( $meta_dur['unit'] ) ? $meta_dur['unit'] : '' );
                                } elseif ( $meta_dur ) {
                                    $item_duration = (string) $meta_dur;
                                }
                            }

                            $items[] = array(
                                'type'     => $type,
                                'id'       => $item_id,
                                'title'    => wp_strip_all_tags( get_the_title( $item_id ) ),
                                'duration' => trim( $item_duration ),
                            );
                        }
                    }

                    $curriculum[] = array(
                        'section_title' => wp_strip_all_tags( $section_title ),
                        'items'         => $items,
                    );
                }
            }
        } else {
            foreach ( $sections as $s_idx => $section ) {
                $section_title = isset( $section['title'] ) ? $section['title'] : sprintf( __( 'Section %d', 'pagepilot' ), $s_idx + 1 );
                $items = array();

                if ( ! empty( $section['items'] ) && is_array( $section['items'] ) ) {
                    foreach ( $section['items'] as $item ) {
                        $items[] = array(
                            'type'     => isset( $item['type'] ) ? $item['type'] : 'lesson',
                            'id'       => isset( $item['id'] ) ? (int) $item['id'] : 0,
                            'title'    => isset( $item['title'] ) ? $item['title'] : '',
                            'duration' => isset( $item['duration'] ) ? (string) $item['duration'] : '',
                        );
                    }
                }

                $curriculum[] = array(
                    'section_title' => wp_strip_all_tags( $section_title ),
                    'items'         => $items,
                );
            }
        }

        return $curriculum;
    }

    /**
     * Calculate course progress by querying LearnPress data directly.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return array Progress data.
     */
    private function calculate_progress_from_lp( $course_id, $user_id ) {
        global $wpdb;

        $result = array(
            'completed_lessons' => 0,
            'total_lessons'     => 0,
            'percentage'        => 0,
            'completed_items'   => array(),
            'status'            => 'not_enrolled',
            'last_activity'     => null,
        );

        $enrolled = false;
        $statuses = array( 'enrolled', 'pursuing', 'completed' );
        foreach ( $statuses as $status ) {
            $count = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}learnpress_user_items
                    WHERE user_id = %d AND item_id = %d AND item_type = %s AND status = %s",
                    $user_id,
                    $course_id,
                    'lp_course',
                    $status
                )
            );
            if ( $count && (int) $count > 0 ) {
                $enrolled = true;
                if ( $status === 'completed' ) {
                    $result['status'] = 'completed';
                } else {
                    $result['status'] = 'enrolled';
                }
                break;
            }
        }

        if ( ! $enrolled ) {
            return $result;
        }

        $course = $this->get_course( $course_id );
        if ( empty( $course['curriculum'] ) ) {
            return $result;
        }

        $all_lesson_ids = array();
        foreach ( $course['curriculum'] as $section ) {
            if ( empty( $section['items'] ) ) {
                continue;
            }
            foreach ( $section['items'] as $item ) {
                if ( $item['type'] === 'lesson' && ! empty( $item['id'] ) ) {
                    $all_lesson_ids[] = $item['id'];
                }
            }
        }

        $result['total_lessons'] = count( $all_lesson_ids );

        if ( $result['total_lessons'] === 0 ) {
            return $result;
        }

        $placeholders = implode( ',', array_fill( 0, count( $all_lesson_ids ), '%d' ) );
        $completed = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT item_id FROM {$wpdb->prefix}learnpress_user_items
                WHERE user_id = %d AND item_type = %s AND status = %s AND item_id IN ($placeholders)",
                array_merge( array( $user_id, 'lp_lesson', 'completed' ), $all_lesson_ids )
            )
        );

        $result['completed_lessons'] = count( $completed );
        $result['completed_items']   = array_map( 'absint', $completed );
        $result['percentage']        = $result['total_lessons'] > 0
            ? round( ( $result['completed_lessons'] / $result['total_lessons'] ) * 100, 1 )
            : 0;

        if ( $result['percentage'] >= 100 ) {
            $result['status'] = 'completed';
        }

        $last_activity = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT MAX(last_activity) FROM {$wpdb->prefix}learnpress_user_items
                WHERE user_id = %d AND item_id = %d AND item_type = %s",
                $user_id,
                $course_id,
                'lp_course'
            )
        );
        $result['last_activity'] = $last_activity;

        return $result;
    }

    /**
     * Fallback: extract instructors from courses when dedicated endpoint fails.
     *
     * @return array List of instructors.
     */
    private function get_instructors_from_courses() {
        $instructors = array();
        $seen = array();

        $courses_result = $this->get_courses( array( 'per_page' => 100, 'page' => 1 ) );
        if ( empty( $courses_result['courses'] ) ) {
            return $instructors;
        }

        foreach ( $courses_result['courses'] as $course ) {
            if ( empty( $course['instructor']['name'] ) ) {
                continue;
            }

            $name = $course['instructor']['name'];
            if ( in_array( $name, $seen, true ) ) {
                continue;
            }
            $seen[] = $name;

            $instructors[] = array(
                'id'           => 0,
                'name'         => $name,
                'avatar'       => $course['instructor']['avatar'],
                'description'  => '',
                'course_count' => 1,
            );
        }

        return $instructors;
    }

    /**
     * Get a currency symbol for price formatting.
     *
     * @return string
     */
    private function get_currency_symbol() {
        if ( function_exists( 'wc_price' ) ) {
            return get_woocommerce_currency_symbol();
        }

        $currency = get_option( 'pagepilot_currency', 'USD' );
        $symbols = array(
            'USD' => '$',
            'EUR' => "\xE2\x82\xAC",
            'GBP' => "\xC2\xA3",
            'INR' => "\xE2\x82\xB9",
            'AUD' => 'A$',
            'CAD' => 'C$',
        );

        return isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : '$';
    }
}
