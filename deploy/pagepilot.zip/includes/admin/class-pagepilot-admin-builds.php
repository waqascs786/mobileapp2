<?php
/**
 * Admin page for viewing and triggering app builds.
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Builds admin page.
 */
class PagePilot_Admin_Builds {

    /**
     * Constructor.
     *
     * @param string $version     Plugin version.
     * @param string $plugin_file Plugin main file path.
     */
    public function __construct( $version = '', $plugin_file = '' ) {
        $this->version     = $version;
        $this->plugin_file = $plugin_file;
        add_action( 'wp_ajax_pagepilot_get_builds', array( $this, 'ajax_get_builds' ) );
        add_action( 'wp_ajax_pagepilot_get_build_status', array( $this, 'ajax_get_build_status' ) );
    }

    /**
     * Render the builds page.
     */
    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'pagepilot' ) );
        }

        $settings    = PagePilot_Activator::get_all_settings();
        $github_settings = get_option( 'pagepilot_github_settings', array() );
        $repository  = sanitize_text_field( $github_settings['repository'] ?? '' );
        $repo_owner  = '';
        $repo_name   = '';
        if ( ! empty( $repository ) && strpos( $repository, '/' ) !== false ) {
            $parts = explode( '/', $repository, 2 );
            $repo_owner = $parts[0];
            $repo_name  = $parts[1];
        }
        $default_branch = sanitize_text_field( $github_settings['branch'] ?? 'main' );
        $github_connected = ! empty( $repo_owner ) && ! empty( $repo_name );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php esc_html_e( 'App Builds', 'pagepilot' ); ?></h1>
            <a href="#" class="page-title-action" id="pagepilot-new-build-btn" style="display:<?php echo $github_connected ? 'inline-block' : 'none'; ?>">
                <?php esc_html_e( 'New Build', 'pagepilot' ); ?>
            </a>
            <hr class="wp-header-end">

            <?php if ( ! $github_connected ) : ?>
                <div class="notice notice-warning inline">
                    <p><?php esc_html_e( 'GitHub is not connected. Please configure your GitHub settings first.', 'pagepilot' ); ?></p>
                    <p><a href="<?php echo esc_url( admin_url( 'admin.php?page=pagepilot&tab=settings&section=github' ) ); ?>"><?php esc_html_e( 'Go to GitHub Settings', 'pagepilot' ); ?></a></p>
                </div>
            <?php endif; ?>

            <!-- Build History Table -->
            <div id="pp-builds-container">
                <table class="wp-list-table widefat fixed striped" id="pp-builds-table">
                    <thead>
                        <tr>
                            <th style="width:50px"><?php esc_html_e( '#', 'pagepilot' ); ?></th>
                            <th style="width:120px"><?php esc_html_e( 'Platform', 'pagepilot' ); ?></th>
                            <th style="width:120px"><?php esc_html_e( 'Status', 'pagepilot' ); ?></th>
                            <th><?php esc_html_e( 'Commit', 'pagepilot' ); ?></th>
                            <th style="width:180px"><?php esc_html_e( 'Date', 'pagepilot' ); ?></th>
                            <th style="width:150px"><?php esc_html_e( 'Actions', 'pagepilot' ); ?></th>
                        </tr>
                    </thead>
                    <tbody id="pp-builds-list">
                        <?php
                        global $wpdb;
                        $table_name = $wpdb->prefix . 'pagepilot_builds';
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                        $builds = $wpdb->get_results( "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT 50", ARRAY_A );
                        if ( ! empty( $builds ) ) {
                            foreach ( $builds as $build ) {
                                $status_class = 'pagepilot-status-running';
                                if ( in_array( $build['status'], array( 'completed', 'success' ), true ) ) {
                                    $status_class = 'pagepilot-status-success';
                                } elseif ( 'failed' === $build['status'] ) {
                                    $status_class = 'pagepilot-status-error';
                                }
                                $commit_short = ! empty( $build['commit_sha'] ) ? substr( $build['commit_sha'], 0, 10 ) : '—';
                                $date = ! empty( $build['created_at'] ) ? $build['created_at'] : '—';
                                $link = '';
                                if ( ! empty( $build['workflow_run_id'] ) && ! empty( $build['repo_owner'] ) && ! empty( $build['repo_name'] ) ) {
                                    $run_url = 'https://github.com/' . esc_attr( $build['repo_owner'] ) . '/' . esc_attr( $build['repo_name'] ) . '/actions/runs/' . esc_attr( $build['workflow_run_id'] );
                                    $link = '<a href="' . $run_url . '" target="_blank">' . esc_html__( 'View', 'pagepilot' ) . '</a>';
                                }
                                echo '<tr>';
                                echo '<td>#' . esc_html( $build['id'] ) . '</td>';
                                echo '<td>' . esc_html( $build['platform'] ?? 'android' ) . '</td>';
                                echo '<td><span class="' . esc_attr( $status_class ) . '">' . esc_html( $build['status'] ?? 'unknown' ) . '</span></td>';
                                echo '<td>' . esc_html( $commit_short ) . '</td>';
                                echo '<td>' . esc_html( $date ) . '</td>';
                                echo '<td>' . $link . '</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="6">' . esc_html__( 'No builds found.', 'pagepilot' ) . '</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Build Modal -->
            <div id="pagepilot-build-modal" class="pagepilot-modal" style="display:none">
                <div class="pagepilot-modal-content">
                    <span class="pagepilot-modal-close">&times;</span>
                    <h2><?php esc_html_e( 'Trigger New Build', 'pagepilot' ); ?></h2>
                    <form id="pp-build-form">
                        <table class="form-table">
                            <tr>
                                <th><label for="build-platform"><?php esc_html_e( 'Platform', 'pagepilot' ); ?></label></th>
                                <td>
                                    <label><input type="radio" name="pagepilot_build_platform" value="android" checked> <?php esc_html_e( 'Android', 'pagepilot' ); ?></label>
                                    <label style="margin-left:15px"><input type="radio" name="pagepilot_build_platform" value="ios"> <?php esc_html_e( 'iOS (Simulator)', 'pagepilot' ); ?></label>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="build-repository"><?php esc_html_e( 'Repository', 'pagepilot' ); ?></label></th>
                                <td><input type="text" id="build-repository" class="regular-text" value="<?php echo esc_attr( $repo_owner . '/' . $repo_name ); ?>" readonly></td>
                            </tr>
                            <tr>
                                <th><label for="build-branch"><?php esc_html_e( 'Branch', 'pagepilot' ); ?></label></th>
                                <td><input type="text" id="build-branch" class="regular-text" value="<?php echo esc_attr( $default_branch ); ?>"></td>
                            </tr>
                        </table>
                        <p class="submit">
                            <button type="submit" class="button button-primary" id="pagepilot-start-build"><?php esc_html_e( 'Start Build', 'pagepilot' ); ?></button>
                            <button type="button" class="button pagepilot-modal-close"><?php esc_html_e( 'Cancel', 'pagepilot' ); ?></button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Trigger GitHub Actions workflow via repository_dispatch.
     *
     * @param string $repository Owner/repo string.
     * @param string $branch     Branch name.
     * @param string $platform   android or ios.
     * @return array|WP_Error    Build info on success.
     */
    public function trigger_github_workflow( $repository, $branch, $platform ) {
        $token = '';
        $github_settings = get_option( 'pagepilot_github_settings', array() );
        $token = $github_settings['token'] ?? '';
        $app_name = $github_settings['app_name'] ?? 'PagePilot';

        $settings    = PagePilot_Activator::get_all_settings();
        $build_number = (string) ( $settings['build_number'] ?? '1' );
        $app_name    = $settings['app_name'] ?? $app_name;
        $site_url    = home_url();
        $api_url     = home_url( '/wp-json' );
        $package     = $settings['package_name'] ?? 'com.pagepilot.app';
        $primary     = $settings['primary_color'] ?? '#4F46E5';
        $build_num   = $settings['build_number'] ?? '1';

        // Use repository_dispatch so the workflow can conditionally run jobs.
        $url = 'https://api.github.com/repos/' . rawurlencode( $repository ) . '/dispatches';

        $body = array(
            'event_type' => 'pagepilot_build',
            'client_payload' => array(
                'build_id'        => '0',
                'branch'          => $branch,
                'platform'        => $platform,
                'app_name'        => $app_name,
                'app_package'     => $package,
                'primary_color'   => $primary,
                'api_url'         => $api_url,
                'build_number'    => $build_num,
                'appetize_token'       => $github_settings['appetize_token'] ?? '',
                'appetize_android_key' => $github_settings['appetize_android_key'] ?? '',
                'appetize_ios_key'     => $github_settings['appetize_ios_key'] ?? '',
            ),
        );

        $dispatch_body  = wp_json_encode( $body );
        $dispatch_token = $token ?: '';

        $result = $this->dispatch_via_curl( $url, $dispatch_token, $dispatch_body );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return array(
            'url' => 'https://github.com/' . $repository . '/actions',
        );
    }

    /**
     * AJAX handler to get build status.
     */
    public function ajax_get_build_status() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        if ( ! isset( $_POST['pagepilot_ajax_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pagepilot_ajax_nonce'] ) ), 'pagepilot_ajax_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'pagepilot' ) ) );
        }

        $build_id = isset( $_POST['build_id'] ) ? absint( $_POST['build_id'] ) : 0;

        if ( ! $build_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid build ID.', 'pagepilot' ) ) );
        }

        global $wpdb;
        $table  = $wpdb->prefix . 'pagepilot_builds';
        $build  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $build_id ), ARRAY_A );

        if ( ! $build ) {
            wp_send_json_error( array( 'message' => __( 'Build not found.', 'pagepilot' ) ) );
        }

        wp_send_json_success( $build );
    }

    /**
     * AJAX handler to get builds list.
     */
    public function ajax_get_builds() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'pagepilot' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_builds';
        $builds = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 50", ARRAY_A );

        wp_send_json_success( $builds ?: array() );
    }

    /**
     * Send a POST request via wp_remote_request.
     *
     * @param string $url  Request URL.
     * @param string $auth Authorization header value.
     * @param string $body JSON body.
     * @return true|WP_Error True on success.
     */
    private function dispatch_via_curl( $url, $auth, $body ) {
        $response = wp_remote_request( $url, array(
            'method'  => 'POST',
            'headers' => array(
                'Authorization' => 'token ' . $auth,
                'Accept'        => 'application/vnd.github.v3+json',
                'Content-Type'  => 'application/json',
                'User-Agent'    => 'PagePilot-WordPress/' . PAGEPILOT_VERSION,
            ),
            'body'    => $body,
            'timeout' => 30,
        ) );

        if ( is_wp_error( $response ) ) {
            error_log( '[PagePilot] dispatch error: ' . $response->get_error_message() );
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );

        error_log( '[PagePilot] dispatch http_code=' . $code );

        if ( $code >= 200 && $code < 300 ) {
            return true;
        }

        return new WP_Error( 'http_error', sprintf( 'HTTP %d: %s', $code, wp_remote_retrieve_body( $response ) ) );
    }
}
