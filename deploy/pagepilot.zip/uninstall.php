<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}pagepilot_settings" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}pagepilot_builds" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}pagepilot_course_cache" );

$options = array(
    'app_name', 'package_name', 'primary_color', 'secondary_color',
    'accent_color', 'bg_color', 'text_color', 'github_token',
    'github_repo', 'github_owner', 'github_branch', 'github_repo_private',
    'lms_plugin', 'site_url', 'enable_courses', 'enable_wishlist',
    'enable_profile', 'enable_quiz', 'enable_search', 'enable_dark_mode',
    'enable_push_notifications', 'enable_social_login', 'enable_offline_mode',
    'splash_bg_color', 'app_version', 'build_number',
);

foreach ( $options as $option ) {
    delete_option( 'pagepilot_' . $option );
}

$upload_dir = wp_upload_dir();
$target_dir = $upload_dir['basedir'] . '/pagepilot';
if ( is_dir( $target_dir ) ) {
    array_map( 'unlink', glob( "$target_dir/*" ) );
    rmdir( $target_dir );
}
