/**
 * PagePilot Admin JavaScript
 */
(function () {
  'use strict';

  function ppInit() {
    if (typeof jQuery === 'undefined') {
      setTimeout(ppInit, 200);
      return;
    }

    var $ = jQuery;
    var d = window.PagePilot || {};
    var PP = {
      restUrl: d.rest_url || '',
      restNonce: d.rest_nonce || '',
      ajaxUrl: d.ajax_url || '',
      ajaxNonce: d.ajax_nonce || ''
    };

    function ppAjax(method, endpoint, data, callback) {
      var url = PP.restUrl;
      if (url.charAt(url.length - 1) !== '/') url += '/';
      url += endpoint;

      $.ajax({
        url: url,
        method: method,
        contentType: 'application/json',
        data: method === 'POST' ? JSON.stringify(data) : null,
        headers: { 'X-WP-Nonce': PP.restNonce },
        dataType: 'json',
        success: function (res) { callback(res); },
        error: function (xhr) {
          var msg = 'Request failed.';
          try { msg = JSON.parse(xhr.responseText).message || msg; } catch (e) {}
          callback({ success: false, message: msg });
        }
      });
    }

    // Sync Courses
    $(document).on('click', '#pagepilot-sync-courses', function (e) {
      e.preventDefault();
      var btn = $(this);
      var lmsVal = $('#lms_plugin').val();
      if (!lmsVal) { ppToast('Select an LMS plugin first.', 'error'); return; }
      btn.prop('disabled', true).text('Syncing...');
      ppAjax('POST', 'courses/sync', { lms_plugin: lmsVal }, function (res) {
        btn.prop('disabled', false).text('Sync Courses');
        if (res.success) {
          ppToast(res.message || 'Courses synced.', 'success');
        } else {
          ppToast(res.message || 'Sync failed.', 'error');
        }
      });
    });

    // Test GitHub Connection
    $(document).on('click', '#pagepilot-test-github', function (e) {
      e.preventDefault();
      var btn = $(this);
      var token = $('#github_token').val();
      if (!token) { ppToast('Enter a GitHub token first.', 'error'); return; }
      btn.prop('disabled', true).text('Testing...');
      $('.pagepilot-github-test-status').text('');
      ppAjax('POST', 'github/connect', { token: token }, function (res) {
        btn.prop('disabled', false).text('Test Connection');
        if (res.success) {
          $('.pagepilot-github-test-status')
            .html('<span style="color:#00a32a">&#10003; Connected as <strong>' + (res.data.login || '') + '</strong></span>');
          ppToast('GitHub connected.', 'success');
        } else {
          $('.pagepilot-github-test-status')
            .html('<span style="color:#d63638">' + (res.message || 'Failed') + '</span>');
          ppToast(res.message || 'Connection failed.', 'error');
        }
      });
    });

    // Create Repository
    $(document).on('click', '#pagepilot-create-repo', function (e) {
      e.preventDefault();
      var btn = $(this);
      var name = $('#pp-new-repo-name').val();
      if (!name) { ppToast('Enter a repository name.', 'error'); return; }
      name = name.trim().toLowerCase().replace(/[^a-z0-9\-_.]/g, '-');
      var priv = $('input[name="pagepilot_github_settings[repo_private]"]:checked').val();
      var isPrivate = priv === '1';
      btn.prop('disabled', true).text('Creating...');
      $('.pagepilot-create-repo-status').text('');
      ppAjax('POST', 'github/create-repo', {
        name: name,
        private: isPrivate,
        description: 'Mobile app built with PagePilot'
      }, function (res) {
        btn.prop('disabled', false).text('Create on GitHub');
        if (res.success) {
          var vis = isPrivate ? 'Private' : 'Public';
          $('.pagepilot-create-repo-status')
            .html('<span style="color:#00a32a">&#10003; Created: <a href="' +
              (res.data.html_url || '#') + '" target="_blank">' + name + '</a> (' + vis + ')</span>');
          $('#github_repo').val(res.data.full_name || name);
          ppToast('Repository created: ' + name, 'success');
        } else {
          $('.pagepilot-create-repo-status')
            .html('<span style="color:#d63638">' + (res.message || 'Failed') + '</span>');
          ppToast(res.message || 'Failed to create repo.', 'error');
        }
      });
    });

    // Save Settings
    $(document).on('click', '.pagepilot-save-btn', function (e) {
      e.preventDefault();
      var btn = $(this);
      var form = btn.closest('form');
      if (!form) return;

      var section = btn.data('section') || '';
      var data = {};
      var endpoint = 'settings';

      if (section === 'github') {
        endpoint = 'github/save-settings';
        data.token = form.find('[name="pagepilot_github_settings[token]"]').val() || '';
        data.repository = form.find('[name="pagepilot_github_settings[repository]"]').val() || '';
        data.branch = form.find('[name="pagepilot_github_settings[branch]"]').val() || 'main';
        var privRadio = form.find('input[name="pagepilot_github_settings[repo_private]"]:checked');
        data.repo_private = privRadio.length ? privRadio.val() : '1';
        data.appetize_token = form.find('[name="pagepilot_github_settings[appetize_token]"]').val() || '';
        data.appetize_android_key = form.find('[name="pagepilot_github_settings[appetize_android_key]"]').val() || '';
        data.appetize_ios_key = form.find('[name="pagepilot_github_settings[appetize_ios_key]"]').val() || '';
      } else if (section === 'advanced') {
        endpoint = 'advanced/save-settings';
        data.api_endpoint = form.find('[name="pagepilot_advanced_settings[api_endpoint]"]').val() || '';
        data.auth_method = form.find('[name="pagepilot_advanced_settings[auth_method]"]').val() || '';
        data.custom_headers = form.find('[name="pagepilot_advanced_settings[custom_headers]"]').val() || '';
      } else {
        form.find('input, select, textarea').each(function () {
          var el = $(this);
          var name = el.attr('name');
          if (!name) return;
          if (el.attr('type') === 'checkbox') {
            data[name] = el.is(':checked') ? '1' : '0';
          } else if (el.attr('type') === 'radio') {
            if (el.is(':checked')) data[name] = el.val();
          } else {
            data[name] = el.val();
          }
        });
      }

      var origText = btn.text();
      btn.prop('disabled', true).text('Saving...');
      ppAjax('POST', endpoint, data, function (res) {
        btn.prop('disabled', false).text(origText);
        if (res.success) {
          ppToast('Settings saved.', 'success');
        } else {
          ppToast(res.message || 'Save failed.', 'error');
        }
      });
    });

    // Media upload (Logo, Splash)
    $(document).on('click', '.pagepilot-upload-btn', function (e) {
      e.preventDefault();
      var btn = $(this);
      var targetId = btn.data('target');
      var previewId = btn.data('preview');
      if (typeof wp === 'undefined' || !wp.media) {
        ppToast('Media library not available.', 'error');
        return;
      }
      var frame = wp.media({
        title: 'Select Image',
        multiple: false,
        library: { type: 'image' },
        button: { text: 'Use This Image' }
      });
      frame.on('select', function () {
        var attachment = frame.state().get('selection').first().toJSON();
        var url = attachment.url;
        $('#' + targetId).val(url).trigger('change');
        if (previewId) {
          var prev = $('#' + previewId);
          prev.html('<img src="' + url + '" alt="" />');
        }
        btn.closest('.pagepilot-media-upload').find('.pagepilot-remove-btn').show();
      });
      frame.open();
    });

    $(document).on('click', '.pagepilot-remove-btn', function (e) {
      e.preventDefault();
      var btn = $(this);
      var targetId = btn.data('target');
      var previewId = btn.data('preview');
      $('#' + targetId).val('').trigger('change');
      if (previewId) {
        $('#' + previewId).html('<span class="dashicons dashicons-format-image"></span>');
      }
      btn.hide();
    });

    // Init color pickers
    if ($.fn.wpColorPicker) {
      $('.pagepilot-color-picker').wpColorPicker();
    }

    // Show/hide password toggle
    $(document).on('click', '.pagepilot-toggle-password', function (e) {
      e.preventDefault();
      var targetId = $(this).data('target');
      if (!targetId) return;
      var input = $('#' + targetId);
      if (input.attr('type') === 'password') {
        input.attr('type', 'text');
        $(this).text('Hide');
      } else {
        input.attr('type', 'password');
        $(this).text('Show');
      }
    });

    // Build modal
    $(document).on('click', '#pagepilot-new-build-btn, #pagepilot-quick-build', function (e) {
      e.preventDefault();
      $('#pagepilot-build-modal').show();
    });

    $(document).on('click', '.pagepilot-modal-cancel, .pagepilot-modal-close', function (e) {
      e.preventDefault();
      $('#pagepilot-build-modal').hide();
    });

    $(document).on('click', '#pagepilot-build-modal', function (e) {
      if (e.target === this || $(e.target).hasClass('pagepilot-modal-overlay')) {
        $(this).hide();
      }
    });

    $(document).on('click', '#pagepilot-start-build', function (e) {
      e.preventDefault();
      var repo = $('#build-repository').val() || '';
      var branch = $('#build-branch').val() || 'main';
      var platform = $('input[name="pagepilot_build_platform"]:checked').val() || 'android';
      if (!repo) { ppToast('Configure a repository first.', 'error'); return; }
      var btn = $(this);
      btn.prop('disabled', true).text('Starting ' + platform + ' build...');
      ppAjax('POST', 'build/trigger', { repository: repo, branch: branch, platform: platform }, function (res) {
        btn.prop('disabled', false).html('<span class="dashicons dashicons-build"></span> Start Build');
        if (res.success) {
          ppToast(platform.charAt(0).toUpperCase() + platform.slice(1) + ' build started!', 'success');
          $('#pagepilot-build-modal').hide();
          setTimeout(function () { location.reload(); }, 1500);
        } else {
          ppToast(res.message || 'Build failed.', 'error');
        }
      });
    });

    // =========================================================================
    // Live phone preview — fully interactive mini-app matching the Flutter app
    // =========================================================================
    var $previewScreen = $('#pagepilot-preview-screen');
    if ($previewScreen.length) {
      var previewCourses = [];
      var previewCategories = [];
      var previewLessons = [];
      var previewCurriculum = {};
      var previewProfile = {};
      var previewCertificates = [];
      var previewData = window.PagePilotPreview || {};
      var previewAjaxUrl = previewData.ajaxUrl || '';
      var previewAjaxNonce = previewData.ajaxNonce || '';

      // Quiz state
      var quizState = {
        quizId: null,
        currentQuestion: 0,
        answers: {},
        submitted: false,
        score: 0
      };

      // Completed lessons state
      var completedLessons = {};

      // Navigation state
      var navStack = [];
      var currentTab = 'home';
      var currentView = 'home';
      var currentCourseId = null;
      var searchQuery = '';

      function pc() { return $('#primary_color').val() || '#0073aa'; }
      function tc() { return $('#text_color').val() || '#333333'; }
      function bc() { return $('#background_color').val() || '#ffffff'; }

      function darkenColor(hex, pct) {
        hex = hex.replace('#', '');
        var r = Math.max(0, parseInt(hex.substring(0, 2), 16) - pct);
        var g = Math.max(0, parseInt(hex.substring(2, 4), 16) - pct);
        var b = Math.max(0, parseInt(hex.substring(4, 6), 16) - pct);
        return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
      }

      function escapeHtml(text) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text || ''));
        return div.innerHTML;
      }

      function stripHtml(html) {
        if (!html) return '';
        var tmp = document.createElement('div');
        tmp.innerHTML = html;
        return (tmp.textContent || tmp.innerText || '').trim();
      }

      function getCategoryIcon(name) {
        var l = (name || '').toLowerCase();
        if (l.indexOf('web') >= 0 || l.indexOf('frontend') >= 0) return 'dashicons-admin-site';
        if (l.indexOf('mobile') >= 0 || l.indexOf('flutter') >= 0) return 'dashicons-smartphone';
        if (l.indexOf('design') >= 0) return 'dashicons-admin-appearance';
        if (l.indexOf('data') >= 0 || l.indexOf('ai') >= 0) return 'dashicons-chart-bar';
        if (l.indexOf('backend') >= 0 || l.indexOf('server') >= 0) return 'dashicons-database';
        if (l.indexOf('business') >= 0 || l.indexOf('market') >= 0) return 'dashicons-chart-line';
        if (l.indexOf('photo') >= 0 || l.indexOf('video') >= 0) return 'dashicons-video-alt3';
        return 'dashicons-category';
      }

      function formatPrice(course) {
        var price = parseFloat(course.price) || 0;
        var salePrice = parseFloat(course.sale_price) || 0;
        var isFree = course.is_free || price === 0 || course.price === 'Free' || course.price === 'free';
        if (isFree) return { text: 'Free', free: true };
        if (salePrice > 0 && salePrice < price) return { text: '$' + salePrice.toFixed(2), free: false };
        if (price > 0) return { text: '$' + price.toFixed(2), free: false };
        return { text: 'View', free: false };
      }

      function renderProgressBar(progress, p) {
        return '<div class="pp-preview-progress-bar">' +
          '<div class="pp-preview-progress-fill" style="width:' + Math.min(100, Math.max(0, progress)) + '%;background:' + p + '"></div>' +
          '</div><div class="pp-preview-progress-text" style="color:' + p + '">' + Math.round(progress) + '% Complete</div>';
      }

      function renderVideoEmbed(url, p) {
        if (!url) return '';
        // YouTube embed.
        var ytMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
        if (ytMatch) {
          return '<div class="pp-preview-video-embed">' +
            '<iframe src="https://www.youtube.com/embed/' + ytMatch[1] + '" frameborder="0" allowfullscreen></iframe>' +
            '</div>';
        }
        // Vimeo embed.
        var vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
        if (vimeoMatch) {
          return '<div class="pp-preview-video-embed">' +
            '<iframe src="https://player.vimeo.com/video/' + vimeoMatch[1] + '" frameborder="0" allowfullscreen></iframe>' +
            '</div>';
        }
        // Generic video.
        return '<div class="pp-preview-video-placeholder">' +
          '<span class="dashicons dashicons-video-alt3" style="color:' + p + ';font-size:48px;width:48px;height:48px"></span>' +
          '<div style="color:#999;font-size:11px;margin-top:8px">Video Lesson</div>' +
          '</div>';
      }

      // ---- Navigation ----
      function navigateTo(view, opts) {
        opts = opts || {};
        navStack.push({ view: currentView, tab: currentTab, courseId: currentCourseId, query: searchQuery });
        currentView = view;
        if (opts.tab) currentTab = opts.tab;
        if (opts.courseId !== undefined) currentCourseId = opts.courseId;
        if (opts.query !== undefined) searchQuery = opts.query;
        renderCurrentView();
        updateNavHighlight();
        updateHeaderForView();
      }

      function goBack() {
        if (navStack.length === 0) return;
        var prev = navStack.pop();
        currentView = prev.view;
        currentTab = prev.tab;
        currentCourseId = prev.courseId;
        searchQuery = prev.query || '';
        renderCurrentView();
        updateNavHighlight();
        updateHeaderForView();
      }

      function updateNavHighlight() {
        $previewScreen.find('.pp-preview-nav-item').removeClass('active');
        var tabMap = { home: 0, courses: 1, wishlist: 2, profile: 3 };
        var idx = tabMap[currentTab];
        if (idx !== undefined) {
          $previewScreen.find('.pp-preview-nav-item').eq(idx).addClass('active');
        }
      }

      function updateHeaderForView() {
        var $header = $previewScreen.find('.pp-preview-header');
        var $title = $previewScreen.find('.pp-preview-title');
        var $back = $previewScreen.find('.pp-preview-back');
        var appName = $('#app_name').val() || 'My App';

        if (currentView === 'courseDetail' || currentView === 'lessonDetail' || currentView === 'search' || currentView === 'quizView' || currentView === 'certificates' || currentView === 'myCourses') {
          $back.show();
          if (currentView === 'courseDetail') $title.text('Course Details');
          else if (currentView === 'lessonDetail') $title.text('Lesson');
          else if (currentView === 'quizView') $title.text('Quiz');
          else if (currentView === 'certificates') $title.text('Certificates');
          else if (currentView === 'myCourses') $title.text('My Courses');
          else $title.text('Search');
        } else {
          $back.hide();
          $title.text(appName);
        }
      }

      // ---- Render dispatcher ----
      function renderCurrentView() {
        switch (currentView) {
          case 'home': renderHome(); break;
          case 'courses': renderCoursesList(); break;
          case 'wishlist': renderWishlist(); break;
          case 'profile': renderProfile(); break;
          case 'courseDetail': renderCourseDetail(); break;
          case 'lessonDetail': renderLessonDetail(); break;
          case 'quizView': renderQuizView(); break;
          case 'search': renderSearch(); break;
          case 'certificates': renderCertificates(); break;
          case 'myCourses': renderMyCourses(); break;
          default: renderHome();
        }
      }

      // ---- Home View ----
      function renderHome() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();
        var hour = new Date().getHours();
        var greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

        var html = '';

        // Welcome banner
        html += '<div class="pp-preview-greeting" style="background:linear-gradient(135deg,' + p + ',' + darkenColor(p, 30) + ')">';
        html += '<span>' + greeting + ',</span>';
        html += '<span class="pp-preview-greeting-name">Learner</span>';
        html += '<div class="pp-preview-greeting-sub">Continue your learning journey. You\'re doing great!</div>';
        html += '</div>';

        // Search bar
        html += '<div class="pp-preview-search pp-clickable" data-action="search">';
        html += '<span class="dashicons dashicons-search" style="color:' + p + '"></span>';
        html += '<span>Search courses...</span>';
        html += '</div>';

        if (previewCourses.length === 0) {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-welcome-learnmore pp-preview-empty-icon"></span>';
          html += 'No courses found.<br>Sync courses from the LMS tab.';
          html += '</div>';
        } else {
          // Featured courses
          html += '<div class="pp-preview-section">';
          html += '<div class="pp-preview-section-header">';
          html += '<span class="pp-preview-section-title" style="color:' + t + '">Featured Courses</span>';
          html += '<span class="pp-preview-view-all pp-clickable" data-action="viewAllCourses" style="color:' + p + '">View All</span>';
          html += '</div>';
          html += '<div class="pp-preview-courses-row">';
          previewCourses.slice(0, 5).forEach(function (c) { html += renderCourseCard(c); });
          html += '</div></div>';

          // Popular courses
          html += '<div class="pp-preview-section">';
          html += '<div class="pp-preview-section-header">';
          html += '<span class="pp-preview-section-title" style="color:' + t + '">Popular Courses</span>';
          html += '<span class="pp-preview-view-all pp-clickable" data-action="viewAllCourses" style="color:' + p + '">View All</span>';
          html += '</div>';
          html += '<div class="pp-preview-courses-row">';
          previewCourses.slice(0, 5).forEach(function (c) { html += renderCourseCard(c); });
          html += '</div></div>';

          // Categories
          html += '<div class="pp-preview-section">';
          html += '<div class="pp-preview-section-header">';
          html += '<span class="pp-preview-section-title" style="color:' + t + '">Categories</span>';
          html += '</div>';
          html += '<div class="pp-preview-categories-grid">';
          var cats = previewCategories.length > 0
            ? previewCategories.map(function (c) { return c.name || c; })
            : ['Development', 'Business', 'Design', 'Marketing', 'Photography'];
          cats.forEach(function (cat) {
            html += '<div class="pp-preview-category-item pp-clickable" data-action="filterCategory" data-category="' + escapeHtml(cat) + '" style="background:' + p + '0d;border-color:' + p + '1e">';
            html += '<span class="dashicons ' + getCategoryIcon(cat) + '" style="color:' + p + '"></span>';
            html += '<span class="pp-preview-category-name" style="color:' + t + '">' + escapeHtml(cat) + '</span>';
            html += '</div>';
          });
          html += '</div></div>';
        }

        body.html(html).scrollTop(0);
      }

      // ---- Courses List View ----
      function renderCoursesList() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();
        var html = '';

        // Search bar
        html += '<div class="pp-preview-search pp-clickable" data-action="search">';
        html += '<span class="dashicons dashicons-search" style="color:' + p + '"></span>';
        html += '<span>Search courses...</span>';
        html += '</div>';

        if (previewCourses.length === 0) {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-welcome-learnmore pp-preview-empty-icon"></span>';
          html += 'No courses found.<br>Sync courses from the LMS tab.';
          html += '</div>';
        } else {
          html += '<div class="pp-preview-section">';
          html += '<div class="pp-preview-section-header">';
          html += '<span class="pp-preview-section-title" style="color:' + t + '">All Courses (' + previewCourses.length + ')</span>';
          html += '</div>';
          html += '<div class="pp-preview-courses-grid">';
          previewCourses.forEach(function (c) { html += renderCourseCardVertical(c); });
          html += '</div></div>';
        }

        body.html(html).scrollTop(0);
      }

      // ---- Search View ----
      function renderSearch() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();
        var html = '';

        // Active search input
        html += '<div class="pp-preview-search-active">';
        html += '<span class="dashicons dashicons-search" style="color:' + p + '"></span>';
        html += '<input type="text" class="pp-preview-search-input" id="pp-preview-search-input" placeholder="Search courses..." value="' + escapeHtml(searchQuery) + '" style="color:' + t + '" />';
        html += '<span class="dashicons dashicons-no-alt pp-clickable" data-action="clearSearch" style="color:#999"></span>';
        html += '</div>';

        var filtered = previewCourses;
        if (searchQuery) {
          var q = searchQuery.toLowerCase();
          filtered = previewCourses.filter(function (c) {
            var title = (c.name || c.title || '').toLowerCase();
            var instr = (c.instructor && typeof c.instructor === 'object') ? (c.instructor.name || '').toLowerCase() : '';
            var cats = (c.categories || []).join(' ').toLowerCase();
            return title.indexOf(q) >= 0 || instr.indexOf(q) >= 0 || cats.indexOf(q) >= 0;
          });
        }

        if (filtered.length === 0) {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-search pp-preview-empty-icon"></span>';
          html += searchQuery ? 'No courses match "' + escapeHtml(searchQuery) + '"' : 'Type to search courses...';
          html += '</div>';
        } else {
          html += '<div class="pp-preview-section">';
          html += '<div class="pp-preview-section-header">';
          html += '<span class="pp-preview-section-title" style="color:' + t + '">' + filtered.length + ' result' + (filtered.length !== 1 ? 's' : '') + '</span>';
          html += '</div>';
          html += '<div class="pp-preview-courses-grid">';
          filtered.forEach(function (c) { html += renderCourseCardVertical(c); });
          html += '</div></div>';
        }

        body.html(html).scrollTop(0);
        setTimeout(function () { $('#pp-preview-search-input').focus(); }, 100);
      }

      // ---- Course Detail View ----
      function renderCourseDetail() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();
        var course = previewCourses.find(function (c) { return c.id == currentCourseId; });

        if (!course) {
          html = '<div class="pp-preview-empty"><span class="dashicons dashicons-warning pp-preview-empty-icon"></span>Course not found.</div>';
          body.html(html);
          return;
        }

        var title = course.name || course.title || 'Untitled';
        var instructor = course.instructor || course.author || {};
        var instructorName = typeof instructor === 'string' ? instructor : (instructor.name || instructor.display_name || '');
        var instructorAvatar = (typeof instructor === 'object') ? (instructor.avatar || '') : '';
        var thumbnail = course.thumbnail || course.image || '';
        var rating = parseFloat(course.rating || course.average_rating || 0);
        var ratingCount = parseInt(course.rating_count || 0, 10);
        var studentsCount = parseInt(course.students_count || 0, 10);
        var lessonsCount = parseInt(course.lessons_count || 0, 10);
        var quizzesCount = parseInt(course.quizzes_count || 0, 10);
        var duration = course.duration || '';
        var description = stripHtml(course.short_description || course.description || '');
        var rawDescription = course.raw_description || course.description || '';
        var cats = course.categories || [];
        var priceInfo = formatPrice(course);
        var isEnrolled = course.is_enrolled || false;
        var progress = course.progress || 0;

        var html = '';

        // Hero image
        if (thumbnail) {
          html += '<div class="pp-preview-detail-hero">';
          html += '<img src="' + thumbnail + '" alt="" onerror="this.parentElement.style.display=\'none\'" />';
          html += '</div>';
        }

        // Course-level video embed
        var videoUrl = course.video_url || '';
        if (videoUrl) {
          html += renderVideoEmbed(videoUrl, p);
        }

        // Title + Price
        html += '<div class="pp-preview-detail-body">';
        html += '<div class="pp-preview-detail-title" style="color:' + t + '">' + escapeHtml(title) + '</div>';

        // Enrollment badge or price
        if (isEnrolled) {
          html += '<div class="pp-preview-enrolled-badge" style="background:' + p + '20;color:' + p + '"><span class="dashicons dashicons-yes-alt"></span> Enrolled</div>';
        } else {
          html += '<div class="pp-preview-detail-price" style="background:' + p + '">' + (priceInfo.free ? 'Free' : priceInfo.text) + '</div>';
        }

        // Progress bar (always show in preview for demo)
        html += '<div class="pp-preview-course-progress">';
        html += '<div class="pp-preview-course-progress-title" style="color:' + t + '">Course Progress</div>';
        var displayProgress = isEnrolled ? progress : 5;
        html += renderProgressBar(displayProgress, p);
        if (isEnrolled && progress > 0) {
          html += '<div class="pp-preview-enroll-btn pp-clickable" data-action="enrollCourse" data-course-id="' + course.id + '" style="background:' + p + '">Continue</div>';
        }
        html += '</div>';

        // Meta row (rating, students, lessons)
        html += '<div class="pp-preview-detail-meta">';
        if (rating > 0) {
          html += '<span class="pp-preview-meta-item"><span class="dashicons dashicons-star-filled" style="color:#f5a623"></span> ' + rating.toFixed(1);
          if (ratingCount > 0) html += ' <span style="color:#999">(' + ratingCount + ')</span>';
          html += '</span>';
        }
        if (studentsCount > 0) {
          html += '<span class="pp-preview-meta-item"><span class="dashicons dashicons-groups"></span> ' + studentsCount + ' students</span>';
        }
        if (lessonsCount > 0) {
          html += '<span class="pp-preview-meta-item"><span class="dashicons dashicons-media-default"></span> ' + lessonsCount + ' lessons</span>';
        }
        if (duration) {
          html += '<span class="pp-preview-meta-item"><span class="dashicons dashicons-clock"></span> ' + escapeHtml(duration) + '</span>';
        }
        html += '</div>';

        // Instructor
        if (instructorName) {
          html += '<div class="pp-preview-detail-instructor">';
          if (instructorAvatar) {
            html += '<img class="pp-preview-instructor-avatar" src="' + instructorAvatar + '" alt="" onerror="this.style.display=\'none\'" />';
          }
          html += '<div>';
          html += '<div class="pp-preview-instructor-label" style="color:#999">Instructor</div>';
          html += '<div class="pp-preview-instructor-name" style="color:' + t + '">' + escapeHtml(instructorName) + '</div>';
          html += '</div></div>';
        }

        // Categories
        if (cats.length > 0) {
          html += '<div class="pp-preview-detail-tags">';
          cats.forEach(function (cat) {
            html += '<span class="pp-preview-tag" style="background:' + p + '15;color:' + p + '">' + escapeHtml(cat) + '</span>';
          });
          html += '</div>';
        }

        // Description — render HTML with shortcodes (video, enrollment buttons, etc.)
        var hasRawDesc = rawDescription && /<[a-z][\s\S]*>/i.test(rawDescription);
        if (hasRawDesc) {
          html += '<div class="pp-preview-detail-section">';
          html += '<div class="pp-preview-detail-section-title" style="color:' + t + '">About this course</div>';
          html += '<div class="pp-preview-lesson-html-content" style="color:' + t + '">' + rawDescription + '</div>';
          html += '</div>';
        } else if (description) {
          html += '<div class="pp-preview-detail-section">';
          html += '<div class="pp-preview-detail-section-title" style="color:' + t + '">About this course</div>';
          html += '<div class="pp-preview-detail-desc" style="color:' + t + '">' + escapeHtml(description).substring(0, 300) + (description.length > 300 ? '...' : '') + '</div>';
          html += '</div>';
        }

        // Curriculum
        html += '<div class="pp-preview-detail-section">';
        html += '<div class="pp-preview-detail-section-title" style="color:' + t + '">Curriculum</div>';

        var courseLessons = previewLessons || [];
        var courseQuizzes = window._ppPreviewQuizzes || [];
        var courseSections = window._ppPreviewSections || {};

        if (courseLessons.length > 0 || courseQuizzes.length > 0) {
          // Check if we have sections to group by
          var sectionKeys = Object.keys(courseSections);
          if (sectionKeys.length > 0) {
            // Group by sections
            sectionKeys.sort(function (a, b) {
              var orderA = courseSections[a].order || 0;
              var orderB = courseSections[b].order || 0;
              return orderA - orderB;
            });

            var globalNum = 0;
            sectionKeys.forEach(function (sid) {
              var section = courseSections[sid];
              var sectionLessons = courseLessons.filter(function (l) { return l.section_id == sid; });
              var sectionQuizzes = courseQuizzes.filter(function (q) { return q.section_id == sid; });

              if (sectionLessons.length === 0 && sectionQuizzes.length === 0) return;

              // Section header
              html += '<div class="pp-preview-section-header-item">';
              html += '<div class="pp-preview-section-icon"><span class="dashicons dashicons-folder"></span></div>';
              html += '<div class="pp-preview-section-title-text">' + escapeHtml(section.title || 'Section') + '</div>';
              html += '<div class="pp-preview-section-count">' + (sectionLessons.length + sectionQuizzes.length) + ' items</div>';
              html += '</div>';

              // Lessons in this section
              var localNum = 0;
              sectionLessons.forEach(function (lesson) {
                globalNum++;
                localNum++;
                var lessonTitle = stripHtml(lesson.title || lesson.name || ('Lesson ' + globalNum));
                var hasQuiz = lesson.has_quiz || lesson.quiz_id;
                var isComplete = completedLessons[lesson.id] || false;
                var checkIcon = isComplete ? 'dashicons-yes-alt' : 'dashicons-lock';
                var checkColor = isComplete ? '#00a32a' : '#999';
                html += '<div class="pp-preview-lesson-item pp-preview-lesson-nested pp-clickable" data-action="openLesson" data-lesson-id="' + lesson.id + '">';
                html += '<div class="pp-preview-lesson-num" style="background:' + (isComplete ? '#00a32a15' : p + '15') + ';color:' + (isComplete ? '#00a32a' : p) + '">' + (isComplete ? '<span class="dashicons dashicons-yes-alt" style="font-size:14px;width:14px;height:14px"></span>' : localNum) + '</div>';
                html += '<div class="pp-preview-lesson-info">';
                html += '<div class="pp-preview-lesson-title" style="color:' + t + '">' + escapeHtml(lessonTitle) + '</div>';
                var lessonMeta = [];
                if (lesson.video_url || lesson.video) lessonMeta.push('<span class="dashicons dashicons-video-alt3"></span> Video');
                if (hasQuiz) lessonMeta.push('<span class="dashicons dashicons-clipboard"></span> Quiz');
                if (lesson.duration) lessonMeta.push(lesson.duration);
                if (lessonMeta.length > 0) {
                  html += '<div class="pp-preview-lesson-meta">' + lessonMeta.join(' · ') + '</div>';
                }
                html += '</div>';
                html += '<span class="pp-preview-lesson-counter" style="color:#999">' + localNum + ' of ' + sectionLessons.length + '</span>';
                html += '</div>';
              });

              // Quizzes in this section
              sectionQuizzes.forEach(function (quiz) {
                var quizTitle = stripHtml(quiz.title || quiz.name || 'Quiz');
                html += '<div class="pp-preview-lesson-item pp-preview-lesson-nested pp-preview-quiz-item pp-clickable" data-action="openQuiz" data-quiz-id="' + quiz.id + '">';
                html += '<div class="pp-preview-lesson-num" style="background:' + p + '25;color:' + p + '"><span class="dashicons dashicons-clipboard" style="font-size:12px;width:12px;height:12px"></span></div>';
                html += '<div class="pp-preview-lesson-info">';
                html += '<div class="pp-preview-lesson-title" style="color:' + t + '">' + escapeHtml(quizTitle) + '</div>';
                var quizMeta = [];
                if (quiz.passing_grade) quizMeta.push(quiz.passing_grade + '% to pass');
                if (quiz.duration || quiz.time_limit) quizMeta.push(quiz.duration || quiz.time_limit);
                var questionCount = quiz.questions ? quiz.questions.length : 0;
                if (questionCount > 0) quizMeta.push(questionCount + ' questions');
                if (quizMeta.length > 0) {
                  html += '<div class="pp-preview-lesson-meta">' + quizMeta.join(' · ') + '</div>';
                }
                html += '</div>';
                html += '<span class="dashicons dashicons-arrow-right-alt2" style="color:#ccc"></span>';
                html += '</div>';
              });
            });

            // Lessons/quizzes without a section (orphans)
            var orphanLessons = courseLessons.filter(function (l) { return !l.section_id || !courseSections[l.section_id]; });
            var orphanQuizzes = courseQuizzes.filter(function (q) { return !q.section_id || !courseSections[q.section_id]; });
            if (orphanLessons.length > 0 || orphanQuizzes.length > 0) {
              orphanLessons.forEach(function (lesson) {
                globalNum++;
                var lessonTitle = stripHtml(lesson.title || lesson.name || ('Lesson ' + globalNum));
                var hasQuiz = lesson.has_quiz || lesson.quiz_id;
                var isComplete = completedLessons[lesson.id] || false;
                var checkIcon = isComplete ? 'dashicons-yes-alt' : 'dashicons-lock';
                var checkColor = isComplete ? '#00a32a' : '#ccc';
                html += '<div class="pp-preview-lesson-item pp-clickable" data-action="openLesson" data-lesson-id="' + lesson.id + '">';
                html += '<div class="pp-preview-lesson-num" style="background:' + (isComplete ? '#00a32a15' : p + '15') + ';color:' + (isComplete ? '#00a32a' : p) + '">' + globalNum + '</div>';
                html += '<div class="pp-preview-lesson-info">';
                html += '<div class="pp-preview-lesson-title" style="color:' + t + '">' + escapeHtml(lessonTitle) + '</div>';
                var lessonMeta = [];
                if (lesson.duration) lessonMeta.push(lesson.duration);
                if (lesson.video_url || lesson.video) lessonMeta.push('<span class="dashicons dashicons-video-alt3"></span> Video');
                if (hasQuiz) lessonMeta.push('<span class="dashicons dashicons-clipboard"></span> Quiz');
                if (lessonMeta.length > 0) {
                  html += '<div class="pp-preview-lesson-meta">' + lessonMeta.join(' · ') + '</div>';
                }
                html += '</div>';
                html += '<span class="dashicons ' + checkIcon + '" style="color:' + checkColor + '"></span>';
                html += '</div>';
              });
              orphanQuizzes.forEach(function (quiz) {
                var quizTitle = stripHtml(quiz.title || quiz.name || 'Quiz');
                html += '<div class="pp-preview-lesson-item pp-preview-quiz-item pp-clickable" data-action="openQuiz" data-quiz-id="' + quiz.id + '">';
                html += '<div class="pp-preview-lesson-num" style="background:' + p + '25;color:' + p + '"><span class="dashicons dashicons-clipboard" style="font-size:12px;width:12px;height:12px"></span></div>';
                html += '<div class="pp-preview-lesson-info">';
                html += '<div class="pp-preview-lesson-title" style="color:' + t + '">' + escapeHtml(quizTitle) + '</div>';
                html += '</div>';
                html += '<span class="dashicons dashicons-arrow-right-alt2" style="color:#ccc"></span>';
                html += '</div>';
              });
            }
          } else {
            // No sections — flat list (LearnPress style)
            var items = [];
            courseLessons.forEach(function (lesson) {
              items.push({ type: 'lesson', data: lesson });
            });
            courseQuizzes.forEach(function (quiz) {
              items.push({ type: 'quiz', data: quiz });
            });

            items.sort(function (a, b) {
              var orderA = a.data.order || 0;
              var orderB = b.data.order || 0;
              return orderA - orderB;
            });

            var lessonNum = 0;
            items.forEach(function (item, i) {
              if (item.type === 'lesson') {
                lessonNum++;
                var lesson = item.data;
                var lessonTitle = stripHtml(lesson.title || lesson.name || ('Lesson ' + lessonNum));
                var hasQuiz = lesson.has_quiz || lesson.quiz_id;
                var isComplete = completedLessons[lesson.id] || false;
                var checkIcon = isComplete ? 'dashicons-yes-alt' : 'dashicons-lock';
                var checkColor = isComplete ? '#00a32a' : '#ccc';
                html += '<div class="pp-preview-lesson-item pp-clickable" data-action="openLesson" data-lesson-id="' + lesson.id + '">';
                html += '<div class="pp-preview-lesson-num" style="background:' + (isComplete ? '#00a32a15' : p + '15') + ';color:' + (isComplete ? '#00a32a' : p) + '">' + lessonNum + '</div>';
                html += '<div class="pp-preview-lesson-info">';
                html += '<div class="pp-preview-lesson-title" style="color:' + t + '">' + escapeHtml(lessonTitle) + '</div>';
                var lessonMeta = [];
                if (lesson.duration) lessonMeta.push(lesson.duration);
                if (lesson.video_url || lesson.video) lessonMeta.push('<span class="dashicons dashicons-video-alt3"></span> Video');
                if (hasQuiz) lessonMeta.push('<span class="dashicons dashicons-clipboard"></span> Quiz');
                if (lessonMeta.length > 0) {
                  html += '<div class="pp-preview-lesson-meta">' + lessonMeta.join(' · ') + '</div>';
                }
                html += '</div>';
                html += '<span class="dashicons ' + checkIcon + '" style="color:' + checkColor + '"></span>';
                html += '</div>';
              } else {
                var quiz = item.data;
                var quizTitle = stripHtml(quiz.title || quiz.name || ('Quiz ' + (i + 1)));
                html += '<div class="pp-preview-lesson-item pp-preview-quiz-item pp-clickable" data-action="openQuiz" data-quiz-id="' + quiz.id + '">';
                html += '<div class="pp-preview-lesson-num" style="background:' + p + '25;color:' + p + '"><span class="dashicons dashicons-clipboard" style="font-size:12px;width:12px;height:12px"></span></div>';
                html += '<div class="pp-preview-lesson-info">';
                html += '<div class="pp-preview-lesson-title" style="color:' + t + '">' + escapeHtml(quizTitle) + '</div>';
                var quizMeta = [];
                if (quiz.passing_grade) quizMeta.push(quiz.passing_grade + '% to pass');
                if (quiz.duration || quiz.time_limit) quizMeta.push(quiz.duration || quiz.time_limit);
                var questionCount = quiz.questions ? quiz.questions.length : 0;
                if (questionCount > 0) quizMeta.push(questionCount + ' questions');
                if (quizMeta.length > 0) {
                  html += '<div class="pp-preview-lesson-meta">' + quizMeta.join(' · ') + '</div>';
                }
                html += '</div>';
                html += '<span class="dashicons dashicons-arrow-right-alt2" style="color:#ccc"></span>';
                html += '</div>';
              }
            });
          }
        } else if (lessonsCount > 0) {
          for (var i = 0; i < Math.min(lessonsCount, 10); i++) {
            html += '<div class="pp-preview-lesson-item">';
            html += '<div class="pp-preview-lesson-num" style="background:' + p + '15;color:' + p + '">' + (i + 1) + '</div>';
            html += '<div class="pp-preview-lesson-info">';
            html += '<div class="pp-preview-lesson-title" style="color:' + t + '">Lesson ' + (i + 1) + '</div>';
            html += '<div class="pp-preview-lesson-meta">Tap to preview</div>';
            html += '</div>';
            html += '<span class="dashicons dashicons-lock" style="color:#ccc"></span>';
            html += '</div>';
          }
        } else {
          html += '<div class="pp-preview-empty" style="padding:16px"><span class="dashicons dashicons-clipboard pp-preview-empty-icon"></span>Curriculum not available yet.</div>';
        }

        html += '</div>'; // end curriculum section

        // Enroll button (if not enrolled)
        if (!isEnrolled) {
          html += '<div class="pp-preview-enroll-btn" data-action="enrollCourse" data-course-id="' + course.id + '" style="background:' + p + '">';
          html += priceInfo.free ? 'Enroll for Free' : 'Enroll Now - ' + priceInfo.text;
          html += '</div>';
        }

        html += '</div>'; // end detail body

        body.html(html).scrollTop(0);
      }

      // ---- Lesson Detail View ----
      function renderLessonDetail() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();

        var lesson = previewLessons.find(function (l) { return l.id == currentCourseId; });
        var title = lesson ? stripHtml(lesson.title || lesson.name || 'Lesson') : 'Lesson';
        var content = lesson ? (lesson.content || lesson.content_display || '') : '';
        var contentDisplay = lesson ? stripHtml(lesson.content || lesson.content_display || '') : '';
        var videoUrl = lesson ? (lesson.video_url || lesson.video || '') : '';
        var attachments = lesson ? (lesson.attachments || []) : [];
        var isComplete = lesson ? (completedLessons[lesson.id] || false) : false;

        var html = '';
        html += '<div class="pp-preview-detail-body">';

        // Title
        html += '<div class="pp-preview-detail-title" style="color:' + t + '">' + escapeHtml(title) + '</div>';

        // Video embed (real YouTube/Vimeo or placeholder)
        if (videoUrl) {
          html += renderVideoEmbed(videoUrl, p);
        }

        // Content — show full HTML if available, otherwise stripped text
        if (content) {
          // If content has HTML tags, render it as-is (for lessons with real HTML content)
          var hasHtmlTags = /<[a-z][\s\S]*>/i.test(content);
          html += '<div class="pp-preview-detail-section">';
          html += '<div class="pp-preview-detail-section-title" style="color:' + t + '">Lesson Content</div>';
          if (hasHtmlTags && content.length < 10000) {
            html += '<div class="pp-preview-lesson-html-content" style="color:' + t + '">' + content + '</div>';
          } else if (contentDisplay) {
            var truncated = contentDisplay.substring(0, 1000);
            if (contentDisplay.length > 1000) truncated += '...';
            html += '<div class="pp-preview-detail-desc" style="color:' + t + '">' + escapeHtml(truncated) + '</div>';
          }
          html += '</div>';
        } else {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-media-default pp-preview-empty-icon"></span>';
          html += 'Lesson content will appear here in the app.';
          html += '</div>';
        }

        // Attachments
        if (attachments && attachments.length > 0) {
          html += '<div class="pp-preview-detail-section">';
          html += '<div class="pp-preview-detail-section-title" style="color:' + t + '">Attachments</div>';
          attachments.forEach(function (att) {
            html += '<div class="pp-preview-attachment-item">';
            html += '<span class="dashicons dashicons-media-default" style="color:' + p + '"></span>';
            html += '<span style="color:' + t + '">' + escapeHtml(att.name || att.title || 'File') + '</span>';
            html += '</div>';
          });
          html += '</div>';
        }

        // Mark Complete button
        html += '<div class="pp-preview-mark-complete">';
        if (isComplete) {
          html += '<div class="pp-preview-complete-badge" style="background:#00a32a20;color:#00a32a">';
          html += '<span class="dashicons dashicons-yes-alt"></span> Completed';
          html += '</div>';
        } else {
          html += '<div class="pp-preview-mark-complete-btn pp-clickable" data-action="markComplete" data-lesson-id="' + (lesson ? lesson.id : 0) + '" style="background:' + p + '">';
          html += '<span class="dashicons dashicons-yes"></span> Mark as Complete';
          html += '</div>';
        }
        html += '</div>';

        // Quiz prompt
        if (lesson && (lesson.has_quiz || lesson.quiz_id)) {
          var quizId = lesson.quiz_id || lesson.has_quiz;
          html += '<div class="pp-preview-detail-section">';
          html += '<div class="pp-preview-lesson-quiz-banner pp-clickable" data-action="openQuiz" data-quiz-id="' + quizId + '" style="background:' + p + '10;border:1px solid ' + p + '30">';
          html += '<span class="dashicons dashicons-clipboard" style="color:' + p + '"></span>';
          html += '<div><div style="font-weight:600;color:' + t + '">Quiz Available</div>';
          html += '<div style="font-size:10px;color:#999">Test your knowledge after this lesson</div></div>';
          html += '</div></div>';
        }

        // Prev/Next navigation
        if (lesson) {
          var allLessons = previewLessons || [];
          var currentIdx = -1;
          for (var i = 0; i < allLessons.length; i++) {
            if (allLessons[i].id == lesson.id) { currentIdx = i; break; }
          }
          var prevLesson = currentIdx > 0 ? allLessons[currentIdx - 1] : null;
          var nextLesson = currentIdx >= 0 && currentIdx < allLessons.length - 1 ? allLessons[currentIdx + 1] : null;

          if (prevLesson || nextLesson) {
            html += '<div class="pp-preview-lesson-nav">';
            if (prevLesson) {
              html += '<div class="pp-preview-lesson-nav-btn pp-clickable" data-action="openLesson" data-lesson-id="' + prevLesson.id + '" style="border:1px solid ' + p + ';color:' + p + '">';
              html += '<span class="dashicons dashicons-arrow-left-alt2"></span> ';
              html += escapeHtml(stripHtml(prevLesson.title || prevLesson.name || 'Previous'));
              html += '</div>';
            } else {
              html += '<div class="pp-preview-lesson-nav-btn disabled">';
              html += '<span class="dashicons dashicons-arrow-left-alt2"></span> Previous';
              html += '</div>';
            }
            if (nextLesson) {
              html += '<div class="pp-preview-lesson-nav-btn pp-clickable" data-action="openLesson" data-lesson-id="' + nextLesson.id + '" style="background:' + p + ';color:#fff">';
              html += escapeHtml(stripHtml(nextLesson.title || nextLesson.name || 'Next'));
              html += ' <span class="dashicons dashicons-arrow-right-alt2"></span>';
              html += '</div>';
            } else {
              html += '<div class="pp-preview-lesson-nav-btn disabled">';
              html += 'Next <span class="dashicons dashicons-arrow-right-alt2"></span>';
              html += '</div>';
            }
            html += '</div>';
          }
        }

        html += '</div>';
        body.html(html).scrollTop(0);
      }

      // ---- Quiz View ----
      function renderQuizView() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();

        var quiz = null;
        // Find quiz in curriculum data
        var curriculumData = previewCurriculum.byCourseId || {};
        Object.keys(curriculumData).forEach(function (cid) {
          var quizzes = curriculumData[cid].quizzes || [];
          quizzes.forEach(function (q) {
            if (q.id == currentCourseId) quiz = q;
          });
        });

        if (!quiz) {
          body.html('<div class="pp-preview-empty"><span class="dashicons dashicons-warning pp-preview-empty-icon"></span>Quiz not found.</div>');
          return;
        }

        var questions = quiz.questions || [];
        if (questions.length === 0) {
          body.html('<div class="pp-preview-empty"><span class="dashicons dashicons-clipboard pp-preview-empty-icon"></span>No questions available for this quiz.</div>');
          return;
        }

        var html = '';
        html += '<div class="pp-preview-detail-body">';

        // Quiz header
        html += '<div class="pp-preview-quiz-header">';
        html += '<div class="pp-preview-quiz-title" style="color:' + t + '">' + escapeHtml(stripHtml(quiz.title || quiz.name || 'Quiz')) + '</div>';
        if (quiz.passing_grade) {
          html += '<div class="pp-preview-quiz-meta" style="color:#999">' + quiz.passing_grade + '% to pass · ' + questions.length + ' questions</div>';
        }
        html += '</div>';

        if (quizState.submitted) {
          // Show results
          var totalQuestions = questions.length;
          var correctCount = 0;
          questions.forEach(function (q, qi) {
            if (quizState.answers[qi] !== undefined) {
              // We don't have correct answers in preview, just show what was selected
            }
          });
          var score = Math.round((quizState.score / totalQuestions) * 100);
          var passed = score >= (quiz.passing_grade || 70);

          html += '<div class="pp-preview-quiz-results">';
          html += '<div class="pp-preview-quiz-score-circle" style="border-color:' + (passed ? '#00a32a' : '#d63638') + '">';
          html += '<div class="pp-preview-quiz-score-num" style="color:' + (passed ? '#00a32a' : '#d63638') + '">' + score + '%</div>';
          html += '<div class="pp-preview-quiz-score-label">' + (passed ? 'Passed!' : 'Not Passed') + '</div>';
          html += '</div>';
          html += '<div class="pp-preview-quiz-score-detail" style="color:' + t + '">' + quizState.score + ' of ' + totalQuestions + ' correct</div>';
          html += '<div class="pp-preview-quiz-retake pp-clickable" data-action="retakeQuiz" data-quiz-id="' + quiz.id + '" style="background:' + p + '">Retake Quiz</div>';
          html += '</div>';
        } else {
          // Show questions
          var currentQ = quizState.currentQuestion;
          var q = questions[currentQ];
          if (q) {
            html += '<div class="pp-preview-quiz-progress">';
            html += '<div class="pp-preview-quiz-progress-text" style="color:#999">Question ' + (currentQ + 1) + ' of ' + questions.length + '</div>';
            html += '<div class="pp-preview-quiz-progress-bar"><div class="pp-preview-quiz-progress-fill" style="width:' + ((currentQ + 1) / questions.length * 100) + '%;background:' + p + '"></div></div>';
            html += '</div>';

            html += '<div class="pp-preview-quiz-question">';
            html += '<div class="pp-preview-quiz-question-text" style="color:' + t + '">' + escapeHtml(q.question) + '</div>';
            html += '</div>';

            html += '<div class="pp-preview-quiz-options">';
            (q.options || []).forEach(function (opt, oi) {
              var isSelected = quizState.answers[currentQ] === oi;
              html += '<div class="pp-preview-quiz-option pp-clickable' + (isSelected ? ' selected' : '') + '" data-action="selectOption" data-question="' + currentQ + '" data-option="' + oi + '" style="border-color:' + (isSelected ? p : '#e0e0e0') + ';background:' + (isSelected ? p + '10' : 'transparent') + '">';
              html += '<div class="pp-preview-quiz-option-letter" style="background:' + (isSelected ? p : '#f0f0f0') + ';color:' + (isSelected ? '#fff' : '#666') + '">' + String.fromCharCode(65 + oi) + '</div>';
              html += '<div class="pp-preview-quiz-option-text" style="color:' + t + '">' + escapeHtml(opt.text) + '</div>';
              html += '</div>';
            });
            html += '</div>';

            // Navigation
            html += '<div class="pp-preview-quiz-nav">';
            if (currentQ > 0) {
              html += '<div class="pp-preview-quiz-nav-btn pp-clickable" data-action="quizPrev" style="border:1px solid ' + p + ';color:' + p + '">Previous</div>';
            }
            if (currentQ < questions.length - 1) {
              html += '<div class="pp-preview-quiz-nav-btn pp-clickable" data-action="quizNext" style="background:' + p + ';color:#fff">Next</div>';
            } else {
              html += '<div class="pp-preview-quiz-nav-btn pp-clickable" data-action="submitQuiz" style="background:#00a32a;color:#fff">Submit</div>';
            }
            html += '</div>';
          }
        }

        html += '</div>';
        body.html(html).scrollTop(0);
      }

      // ---- Wishlist View ----
      function renderWishlist() {
        var body = $previewScreen.find('#pp-preview-body');
        var t = tc(), p = pc();
        var html = '<div class="pp-preview-section" style="padding-top:40px">';
        html += '<div class="pp-preview-section-header">';
        html += '<span class="pp-preview-section-title" style="color:' + t + '">My Wishlist</span>';
        html += '</div></div>';

        // Show first 2 courses as "wishlisted" for demo
        var wishlisted = previewCourses.slice(0, 2);
        if (wishlisted.length > 0) {
          html += '<div class="pp-preview-courses-grid">';
          wishlisted.forEach(function (c) { html += renderCourseCardVertical(c); });
          html += '</div>';
        } else {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-heart pp-preview-empty-icon" style="color:#e74c3c"></span>';
          html += 'Your wishlist is empty.<br>Browse courses and save your favorites!';
          html += '</div>';
        }
        body.html(html).scrollTop(0);
      }

      // ---- My Courses View ----
      function renderMyCourses() {
        var body = $previewScreen.find('#pp-preview-body');
        var t = tc(), p = pc();
        var html = '<div class="pp-preview-section" style="padding-top:40px">';
        html += '<div class="pp-preview-section-header">';
        html += '<span class="pp-preview-section-title" style="color:' + t + '">My Courses</span>';
        html += '</div></div>';

        // Show enrolled courses (first 2 for demo)
        var enrolled = previewCourses.slice(0, 2);
        if (enrolled.length > 0) {
          html += '<div class="pp-preview-courses-grid">';
          enrolled.forEach(function (c) {
            c.is_enrolled = true;
            c.progress = Math.floor(Math.random() * 80) + 10;
            html += renderCourseCardVertical(c);
          });
          html += '</div>';
        } else {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-welcome-learnmore pp-preview-empty-icon"></span>';
          html += 'You haven\'t enrolled in any courses yet.';
          html += '</div>';
        }
        body.html(html).scrollTop(0);
      }

      // ---- Certificates View ----
      function renderCertificates() {
        var body = $previewScreen.find('#pp-preview-body');
        var t = tc(), p = pc();
        var certs = previewCertificates || [];

        var html = '<div class="pp-preview-section" style="padding-top:40px">';
        html += '<div class="pp-preview-section-header">';
        html += '<span class="pp-preview-section-title" style="color:' + t + '">My Certificates</span>';
        html += '</div></div>';

        if (certs.length > 0) {
          certs.forEach(function (cert) {
            html += '<div class="pp-preview-certificate-card">';
            html += '<div class="pp-preview-certificate-icon" style="background:' + p + '15;color:' + p + '">';
            html += '<span class="dashicons dashicons-tickets-alt"></span>';
            html += '</div>';
            html += '<div class="pp-preview-certificate-info">';
            html += '<div class="pp-preview-certificate-title" style="color:' + t + '">' + escapeHtml(cert.title) + '</div>';
            html += '<div class="pp-preview-certificate-course" style="color:#999">' + escapeHtml(cert.course) + '</div>';
            html += '<div class="pp-preview-certificate-date" style="color:#999">' + escapeHtml(cert.date) + '</div>';
            html += '</div>';
            html += '</div>';
          });
        } else {
          html += '<div class="pp-preview-empty">';
          html += '<span class="dashicons dashicons-tickets-alt pp-preview-empty-icon" style="color:' + p + '"></span>';
          html += 'No certificates earned yet.<br>Complete courses to earn certificates!';
          html += '</div>';
        }
        body.html(html).scrollTop(0);
      }

      // ---- Profile View ----
      function renderProfile() {
        var body = $previewScreen.find('#pp-preview-body');
        var p = pc(), t = tc();
        var profile = previewProfile || {};
        var html = '';

        // Profile header with avatar
        html += '<div class="pp-preview-profile-header" style="background:linear-gradient(135deg,' + p + ',' + darkenColor(p, 30) + ')">';
        html += '<div class="pp-preview-profile-avatar">';
        if (profile.avatar) {
          html += '<img src="' + profile.avatar + '" alt="" style="width:100%;height:100%;border-radius:50%;object-fit:cover" />';
        } else {
          html += '<span class="dashicons dashicons-admin-users" style="color:' + p + ';font-size:28px;width:28px;height:28px"></span>';
        }
        html += '</div>';
        html += '<div class="pp-preview-profile-name">' + escapeHtml(profile.name || 'Learner') + '</div>';
        html += '<div class="pp-preview-profile-email">' + escapeHtml(profile.email || 'learner@example.com') + '</div>';
        html += '</div>';

        // Stats cards
        html += '<div class="pp-preview-profile-stats">';
        html += '<div class="pp-preview-stat-card">';
        html += '<div class="pp-preview-stat-num" style="color:' + p + '">' + (profile.enrolled || 0) + '</div>';
        html += '<div class="pp-preview-stat-label">Enrolled</div>';
        html += '</div>';
        html += '<div class="pp-preview-stat-card">';
        html += '<div class="pp-preview-stat-num" style="color:#00a32a">' + (profile.completed || 0) + '</div>';
        html += '<div class="pp-preview-stat-label">Completed</div>';
        html += '</div>';
        html += '<div class="pp-preview-stat-card">';
        html += '<div class="pp-preview-stat-num" style="color:#f5a623">' + (profile.certificates || 0) + '</div>';
        html += '<div class="pp-preview-stat-label">Certificates</div>';
        html += '</div>';
        html += '</div>';

        // Menu items
        html += '<div class="pp-preview-profile-menu">';
        var menuItems = [
          { icon: 'dashicons-welcome-learnmore', label: 'My Courses', action: 'goMyCourses' },
          { icon: 'dashicons-heart', label: 'Wishlist', action: 'goWishlist' },
          { icon: 'dashicons-tickets-alt', label: 'Certificates', action: 'goCertificates' },
          { icon: 'dashicons-admin-generic', label: 'Settings', action: 'none' },
          { icon: 'dashicons-logout', label: 'Logout', action: 'none' }
        ];
        menuItems.forEach(function (item) {
          html += '<div class="pp-preview-menu-item pp-clickable" data-action="' + item.action + '">';
          html += '<span class="dashicons ' + item.icon + '" style="color:' + p + '"></span>';
          html += '<span style="color:' + t + '">' + item.label + '</span>';
          html += '<span class="dashicons dashicons-arrow-right-alt2" style="color:#ccc"></span>';
          html += '</div>';
        });
        html += '</div>';
        body.html(html).scrollTop(0);
      }

      // ---- Card renderers ----
      function renderCourseCard(course) {
        var title = course.name || course.title || 'Untitled';
        var instructor = course.instructor || course.author || {};
        var instructorName = typeof instructor === 'string' ? instructor : (instructor.name || instructor.display_name || '');
        var thumbnail = course.thumbnail || course.image || '';
        var rating = parseFloat(course.rating || course.average_rating || 0);
        var ratingCount = parseInt(course.rating_count || 0, 10);
        var priceInfo = formatPrice(course);
        var isEnrolled = course.is_enrolled || false;
        var progress = course.progress || 0;
        var p = pc(), t = tc();

        var html = '<div class="pp-preview-course-card pp-clickable" data-action="openCourse" data-course-id="' + course.id + '">';

        if (thumbnail) {
          html += '<img class="pp-preview-course-thumb" src="' + thumbnail + '" alt="" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'" />';
          html += '<div class="pp-preview-course-thumb-placeholder" style="display:none;background:' + p + '22;color:' + p + '">&#128218;</div>';
        } else {
          html += '<div class="pp-preview-course-thumb-placeholder" style="background:' + p + '15;color:' + p + '">&#128218;</div>';
        }

        // Enrollment badge
        if (isEnrolled) {
          html += '<div class="pp-preview-course-enrolled-badge" style="background:' + p + '">Enrolled</div>';
        }

        html += '<div class="pp-preview-course-info">';
        html += '<div class="pp-preview-course-name" style="color:' + t + '">' + escapeHtml(title) + '</div>';
        if (instructorName) {
          html += '<div class="pp-preview-course-instructor">' + escapeHtml(instructorName) + '</div>';
        }
        if (rating > 0) {
          html += '<div class="pp-preview-course-rating">';
          html += '<span style="color:#f5a623">&#9733;</span> ' + rating.toFixed(1);
          if (ratingCount > 0) html += ' <span style="color:#999">(' + ratingCount + ')</span>';
          html += '</div>';
        }
        if (isEnrolled && progress > 0) {
          html += renderProgressBar(progress, p);
        } else {
          html += '<span class="pp-preview-course-price' + (priceInfo.free ? ' free' : '') + '" style="background:' + p + '">' + priceInfo.text + '</span>';
        }
        html += '</div></div>';
        return html;
      }

      function renderCourseCardVertical(course) {
        var title = course.name || course.title || 'Untitled';
        var instructor = course.instructor || course.author || {};
        var instructorName = typeof instructor === 'string' ? instructor : (instructor.name || instructor.display_name || '');
        var thumbnail = course.thumbnail || course.image || '';
        var rating = parseFloat(course.rating || course.average_rating || 0);
        var ratingCount = parseInt(course.rating_count || 0, 10);
        var lessonsCount = parseInt(course.lessons_count || 0, 10);
        var duration = course.duration || '';
        var priceInfo = formatPrice(course);
        var isEnrolled = course.is_enrolled || false;
        var progress = course.progress || 0;
        var p = pc(), t = tc();

        var html = '<div class="pp-preview-course-card-v pp-clickable" data-action="openCourse" data-course-id="' + course.id + '">';

        if (thumbnail) {
          html += '<img class="pp-preview-course-thumb-v" src="' + thumbnail + '" alt="" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'" />';
          html += '<div class="pp-preview-course-thumb-placeholder-v" style="display:none;background:' + p + '15;color:' + p + '">&#128218;</div>';
        } else {
          html += '<div class="pp-preview-course-thumb-placeholder-v" style="background:' + p + '15;color:' + p + '">&#128218;</div>';
        }

        // Enrollment badge
        if (isEnrolled) {
          html += '<div class="pp-preview-course-enrolled-badge-v" style="background:' + p + '">Enrolled</div>';
        }

        html += '<div class="pp-preview-course-info-v">';
        html += '<div class="pp-preview-course-name-v" style="color:' + t + '">' + escapeHtml(title) + '</div>';
        if (instructorName) {
          html += '<div class="pp-preview-course-instructor-v">' + escapeHtml(instructorName) + '</div>';
        }
        html += '<div class="pp-preview-course-meta-v">';
        if (rating > 0) {
          html += '<span><span style="color:#f5a623">&#9733;</span> ' + rating.toFixed(1) + '</span>';
        }
        if (lessonsCount > 0) {
          html += '<span><span class="dashicons dashicons-media-default" style="font-size:11px;width:11px;height:11px"></span> ' + lessonsCount + '</span>';
        }
        if (duration) {
          html += '<span><span class="dashicons dashicons-clock" style="font-size:11px;width:11px;height:11px"></span> ' + escapeHtml(duration) + '</span>';
        }
        html += '</div>';
        if (isEnrolled && progress > 0) {
          html += renderProgressBar(progress, p);
        } else {
          html += '<span class="pp-preview-course-price' + (priceInfo.free ? ' free' : '') + '" style="background:' + p + '">' + priceInfo.text + '</span>';
        }
        html += '</div></div>';
        return html;
      }

      // ---- Update colors ----
      function updatePreviewColors() {
        var p = pc();
        var logoInput = $('#logo_url').val();

        $previewScreen.find('.pp-preview-statusbar').css('background', p);
        $previewScreen.find('.pp-preview-header').css('background', p);
        $previewScreen.find('.pp-preview-title').text($('#app_name').val() || 'My App');
        $previewScreen.find('.pp-preview-body').css({ background: bc(), color: tc() });
        $previewScreen.find('.pp-preview-navbar').css('background', p);

        if (logoInput) {
          if (!$previewScreen.find('.pp-preview-logo').length) {
            $previewScreen.find('.pp-preview-header').prepend('<img class="pp-preview-logo" src="' + logoInput + '" alt="" />');
          } else {
            $previewScreen.find('.pp-preview-logo').attr('src', logoInput).show();
          }
        } else {
          $previewScreen.find('.pp-preview-logo').hide();
        }
      }

      // ---- Load course detail via inline data ----
      function loadCourseDetail(courseId) {
        currentCourseId = courseId;
        currentView = 'courseDetail';
        navStack.push({ view: currentTab, tab: currentTab });
        updateHeaderForView();

        var curriculumData = previewCurriculum.byCourseId || {};
        var courseData = curriculumData[courseId] || {};
        previewLessons = courseData.lessons || [];
        window._ppPreviewQuizzes = courseData.quizzes || [];
        window._ppPreviewSections = courseData.sections || {};

        renderCourseDetail();
      }

      // ---- Event delegation ----
      $previewScreen.on('click', '.pp-clickable', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var $el = $(this);
        var action = $el.data('action');

        switch (action) {
          case 'openCourse':
            var courseId = $el.data('course-id');
            if (courseId) loadCourseDetail(courseId);
            break;
          case 'openLesson':
            var lessonId = $el.data('lesson-id');
            navigateTo('lessonDetail', { courseId: lessonId });
            break;
          case 'openQuiz':
            var quizId = $el.data('quiz-id');
            if (quizId) {
              quizState = { quizId: quizId, currentQuestion: 0, answers: {}, submitted: false, score: 0 };
              navigateTo('quizView', { courseId: quizId });
            }
            break;
          case 'selectOption':
            var qi = parseInt($el.data('question'));
            var oi = parseInt($el.data('option'));
            quizState.answers[qi] = oi;
            renderQuizView();
            break;
          case 'quizNext':
            if (quizState.currentQuestion < 20) {
              quizState.currentQuestion++;
              renderQuizView();
            }
            break;
          case 'quizPrev':
            if (quizState.currentQuestion > 0) {
              quizState.currentQuestion--;
              renderQuizView();
            }
            break;
          case 'submitQuiz':
            // Score: give random 60-100 for demo (real grading is server-side)
            quizState.score = Math.floor(Math.random() * 40) + 60;
            quizState.submitted = true;
            renderQuizView();
            break;
          case 'retakeQuiz':
            quizState = { quizId: quizState.quizId, currentQuestion: 0, answers: {}, submitted: false, score: 0 };
            renderQuizView();
            break;
          case 'markComplete':
            var lid = $el.data('lesson-id');
            if (lid) {
              completedLessons[lid] = true;
              renderLessonDetail();
            }
            break;
          case 'enrollCourse':
            var eid = $el.data('course-id');
            if (eid) {
              var course = previewCourses.find(function (c) { return c.id == eid; });
              if (course) {
                course.is_enrolled = true;
                course.progress = 5;
              }
              renderCourseDetail();
            }
            break;
          case 'search':
            navigateTo('search', { tab: currentTab });
            break;
          case 'viewAllCourses':
            navigateTo('courses', { tab: 'courses' });
            break;
          case 'filterCategory':
            var cat = $el.data('category');
            searchQuery = cat;
            navigateTo('search', { tab: 'courses', query: cat });
            break;
          case 'clearSearch':
            searchQuery = '';
            renderSearch();
            break;
          case 'goMyCourses':
            navigateTo('myCourses', { tab: 'profile' });
            break;
          case 'goWishlist':
            navigateTo('wishlist', { tab: 'wishlist' });
            break;
          case 'goCertificates':
            navigateTo('certificates', { tab: 'profile' });
            break;
        }
      });

      // Search input live filtering
      $previewScreen.on('input', '#pp-preview-search-input', function () {
        searchQuery = $(this).val();
        renderSearch();
      });

      // Back button
      $previewScreen.on('click', '.pp-preview-back', function (e) {
        e.preventDefault();
        goBack();
      });

      // Bottom nav
      $previewScreen.on('click', '.pp-preview-nav-item', function (e) {
        e.preventDefault();
        var idx = $previewScreen.find('.pp-preview-nav-item').index($(this));
        var tabs = ['home', 'courses', 'wishlist', 'profile'];
        var tab = tabs[idx];
        if (tab && tab !== currentTab) {
          navStack = [];
          currentTab = tab;
          currentView = tab;
          currentCourseId = null;
          searchQuery = '';
          quizState = { quizId: null, currentQuestion: 0, answers: {}, submitted: false, score: 0 };
          renderCurrentView();
          updateNavHighlight();
          updateHeaderForView();
        }
      });

      // ---- Fetch data & init ----
      function fetchPreviewCourses() {
        previewCourses = previewData.courses || [];
        previewCategories = previewData.categories || [];
        previewCurriculum = previewData.curriculum || { byCourseId: {}, lessons: [], quizzes: [] };
        previewProfile = previewData.profile || {};
        previewCertificates = previewData.certificates || [];

        // Debug: log curriculum structure to help diagnose section issues.
        if (previewCurriculum._debug) {
          console.log('[PagePilot] Curriculum debug:', JSON.stringify(previewCurriculum._debug, null, 2));
        }
        if (previewCurriculum.sections) {
          var secKeys = Object.keys(previewCurriculum.sections);
          console.log('[PagePilot] Top-level sections count:', secKeys.length, 'IDs:', secKeys.slice(0, 10));
        }
        // Log sections inside each course.
        var bc = previewCurriculum.byCourseId || {};
        Object.keys(bc).forEach(function (cid) {
          var sc = bc[cid].sections || {};
          var sk = Object.keys(sc);
          console.log('[PagePilot] Course', cid, '- sections:', sk.length, 'IDs:', sk.slice(0, 5), 'lessons:', (bc[cid].lessons || []).length);
        });

        renderCurrentView();
      }

      // Bind live settings updates
      $(document).on('input change', '#app_name, #primary_color, #background_color, #text_color', function () {
        updatePreviewColors();
        renderCurrentView();
      });
      $(document).on('change', '#logo_url', updatePreviewColors);

      // Initial render
      fetchPreviewCourses();
    }
  }

  function ppToast(message, type) {
    if (typeof jQuery === 'undefined') return;
    var $ = jQuery;
    $('.pp-toast').remove();
    var bg = '#0073aa';
    if (type === 'success') bg = '#00a32a';
    else if (type === 'error') bg = '#d63638';
    var toast = $('<div class="pp-toast"></div>')
      .text(message)
      .css({
        position: 'fixed', top: '32px', right: '32px', zIndex: 100000,
        padding: '12px 24px', borderRadius: '6px', color: '#fff',
        fontSize: '14px', fontWeight: 500, background: bg,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)'
      })
      .appendTo('body');
    setTimeout(function () {
      toast.fadeOut(300, function () { toast.remove(); });
    }, 4000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ppInit);
  } else {
    ppInit();
  }
})();
