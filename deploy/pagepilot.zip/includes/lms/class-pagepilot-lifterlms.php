<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * LifterLMS LMS handler.
 *
 * Integrates with LifterLMS REST API at /wp-json/llms/v1/
 * Normalizes all data to PagePilot's standard format.
 */
class PagePilot_LifterLMS extends PagePilot_LMS_Base {

    protected $lms_key = 'lifterlms';
    protected $api_base = '/wp-json/llms/v1';

    private $request_timeout = 15;

    /**
     * Fetch courses with pagination, search, and filters.
     *
     * @param array $args {
     *     @type int    $page     Page number.
     *     @type int    $per_page Items per page.
     *     @type string $search   Search keyword.
     *     @type int    $category Category ID.
     *     @type string $orderby  Order by field.
     *     @type string $order    ASC or DESC.
     * }
     * @return array{courses: array, total: int, pages: int, current_page: int}
     */
    public function get_courses( $args = array() ) {
        $defaults = array(
            'page'     => 1,
            'per_page' => 12,
            'search'   => '',
            'category' => 0,
            'orderby'  => 'date',
            'order'    => 'DESC',
            'status'   => 'publish',
        );
        $args = wp_parse_args( $args, $defaults );

        $cache_key = 'llms_courses_' . md5( wp_json_encode( $args ) );
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $query_args = array(
            'post_type'      => 'course',
            'post_status'    => sanitize_text_field( $args['status'] ),
            'posts_per_page' => intval( $args['per_page'] ),
            'paged'          => intval( $args['page'] ),
            'orderby'        => sanitize_text_field( $args['orderby'] ),
            'order'          => sanitize_text_field( $args['order'] ),
        );

        if ( ! empty( $args['search'] ) ) {
            $query_args['s'] = sanitize_text_field( $args['search'] );
        }

        if ( ! empty( $args['category'] ) ) {
            $query_args['tax_query'] = array(
                array(
                    'taxonomy' => 'course_cat',
                    'field'    => 'term_id',
                    'terms'    => absint( $args['category'] ),
                ),
            );
        }

        $wp_query = new WP_Query( $query_args );

        $courses = array();
        $total   = $wp_query->found_posts;
        $pages   = $wp_query->max_num_pages;

        foreach ( $wp_query->posts as $post ) {
            // Build a stdClass compatible with format_course.
            $raw = new stdClass();
            $raw->id          = $post->ID;
            $raw->post_author = $post->post_author;
            $raw->author      = $post->post_author;
            $raw->title       = $post->post_title;
            $raw->content     = $post->post_content;
            $raw->excerpt     = $post->post_excerpt;
            $raw->status      = $post->post_status;
            $raw->date        = $post->post_date;
            $raw->modified    = $post->post_modified;

            // Get section IDs for this course (LifterLMS uses llms_section post type).
            $section_args = array(
                'post_type'      => 'llms_section',
                'post_status'    => 'publish',
                'post_parent'    => $post->ID,
                'posts_per_page' => -1,
                'orderby'        => 'menu_order',
                'order'          => 'ASC',
                'fields'         => 'ids',
            );
            $raw->sections = get_posts( $section_args );

            $courses[] = $this->format_course( $raw );
        }

        $result = array(
            'courses'      => $courses,
            'total'        => $total,
            'pages'        => $pages,
            'current_page' => $args['page'],
        );

        $this->cache_set( $cache_key, $result );
        return $result;
    }

    /**
     * Get a single course with full details.
     *
     * @param int $id Course ID.
     * @return array|WP_Error Normalized course data or error.
     */
    public function get_course( $id ) {
        $cache_key = 'llms_course_' . $id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $response = $this->make_api_request( '/courses/' . absint( $id ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $course = $this->format_course( $response );

        // Fetch curriculum (sections + lessons + quizzes).
        $course['curriculum'] = $this->get_course_curriculum( $id );

        $this->cache_set( $cache_key, $course );
        return $course;
    }

    /**
     * Get lessons for a course.
     *
     * @param int $course_id Course ID.
     * @return array List of normalized lesson data.
     */
    public function get_lessons( $course_id ) {
        $cache_key = 'llms_lessons_' . $course_id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $lessons = array();

        // Method 1 (most reliable): Query lessons by _llms_parent_course meta.
        // LifterLMS stores the course↔lesson relationship in post meta.
        global $wpdb;
        $meta_lesson_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT pm.post_id FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key = '_llms_parent_course'
                   AND pm.meta_value = %d
                   AND p.post_type = 'lesson'
                   AND p.post_status = 'publish'
                 ORDER BY p.menu_order ASC",
                absint( $course_id )
            )
        );

        if ( ! empty( $meta_lesson_ids ) ) {
            foreach ( $meta_lesson_ids as $lesson_id ) {
                $lesson_data = $this->get_lesson( absint( $lesson_id ) );
                if ( ! is_wp_error( $lesson_data ) ) {
                    $lessons[] = $lesson_data;
                }
            }
        }

        // Method 2: If no results from meta, try section→lesson hierarchy.
        if ( empty( $lessons ) ) {
            $section_args = array(
                'post_type'      => array( 'llms_section', 'section' ),
                'post_status'    => 'publish',
                'post_parent'    => absint( $course_id ),
                'posts_per_page' => -1,
                'orderby'        => 'menu_order',
                'order'          => 'ASC',
            );
            $sections = get_posts( $section_args );

            if ( ! empty( $sections ) ) {
                foreach ( $sections as $section ) {
                    $lesson_ids = get_post_meta( $section->ID, '_llms_section_lessons', true );
                    if ( ! is_array( $lesson_ids ) ) {
                        $lesson_ids = array();
                    }
                    foreach ( $lesson_ids as $lesson_id ) {
                        $lesson_data = $this->get_lesson( absint( $lesson_id ) );
                        if ( ! is_wp_error( $lesson_data ) ) {
                            $lessons[] = $lesson_data;
                        }
                    }
                }
            }
        }

        // Method 3: Direct post_parent match.
        if ( empty( $lessons ) ) {
            $lesson_args = array(
                'post_type'      => 'lesson',
                'post_status'    => 'publish',
                'post_parent'    => absint( $course_id ),
                'posts_per_page' => -1,
                'orderby'        => 'menu_order',
                'order'          => 'ASC',
            );
            $raw_lessons = get_posts( $lesson_args );
            foreach ( $raw_lessons as $lesson_post ) {
                $lesson_data = $this->get_lesson( $lesson_post->ID );
                if ( ! is_wp_error( $lesson_data ) ) {
                    $lessons[] = $lesson_data;
                }
            }
        }

        $this->cache_set( $cache_key, $lessons );
        return $lessons;
    }

    /**
     * Get a single lesson.
     *
     * @param int $id Lesson ID.
     * @return array|WP_Error Normalized lesson data or error.
     */
    public function get_lesson( $id ) {
        $cache_key = 'llms_lesson_' . $id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $post = get_post( absint( $id ) );
        if ( ! $post || 'lesson' !== $post->post_type ) {
            return new WP_Error( 'invalid_lesson', __( 'Lesson not found.', 'pagepilot' ) );
        }

        // Build a stdClass compatible with format_lesson.
        // LifterLMS hierarchy: Course → Section → Lesson.
        // $post->post_parent may be section_id, or 0 if not attached.
        // LifterLMS also stores relationships in post meta:
        //   _llms_parent_course = course_id
        //   _llms_parent_section = section_id
        $section_id = (int) $post->post_parent;
        $course_id  = 0;

        // Method 1: Check _llms_parent_course meta (most reliable).
        $parent_course_meta = get_post_meta( $post->ID, '_llms_parent_course', true );
        if ( $parent_course_meta ) {
            $course_id = (int) $parent_course_meta;
        }

        // Method 2: Traverse section → course if post_parent is set.
        if ( $course_id <= 0 && $section_id > 0 ) {
            $section_post = get_post( $section_id );
            if ( $section_post && in_array( $section_post->post_type, array( 'llms_section', 'section' ), true ) ) {
                $course_id = (int) $section_post->post_parent;
            }
        }

        // Method 3: Check _llms_parent_section meta → section → course.
        if ( $course_id <= 0 ) {
            $parent_section_meta = get_post_meta( $post->ID, '_llms_parent_section', true );
            if ( $parent_section_meta ) {
                $sec_post = get_post( (int) $parent_section_meta );
                if ( $sec_post ) {
                    $course_id = (int) $sec_post->post_parent;
                }
            }
        }

        // Method 4: Find section containing this lesson via _llms_section_lessons meta.
        if ( $course_id <= 0 ) {
            global $wpdb;
            $found_section = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT p.ID, p.post_parent FROM {$wpdb->posts} p
                     INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                     WHERE pm.meta_key = '_llms_section_lessons'
                       AND pm.meta_value LIKE %s
                       AND p.post_type IN ('llms_section', 'section')
                     LIMIT 1",
                    '%' . $wpdb->esc_like( $post->ID ) . '%'
                )
            );
            if ( $found_section && $found_section->post_parent > 0 ) {
                $lesson_ids = get_post_meta( $found_section->ID, '_llms_section_lessons', true );
                if ( is_array( $lesson_ids ) && in_array( $post->ID, array_map( 'absint', $lesson_ids ), true ) ) {
                    $course_id = (int) $found_section->post_parent;
                }
            }
        }

        $raw = new stdClass();
        $raw->id          = $post->ID;
        $raw->post_parent = $post->post_parent;
        $raw->parent      = $course_id > 0 ? $course_id : $section_id;
        $raw->title       = $post->post_title;
        $raw->content     = $post->post_content;
        $raw->menu_order  = $post->menu_order;

        $lesson = $this->format_lesson( $raw );
        $this->cache_set( $cache_key, $lesson );
        return $lesson;
    }

    /**
     * Get quizzes for a course.
     *
     * @param int $course_id Course ID.
     * @return array List of normalized quiz data.
     */
    public function get_quizzes( $course_id ) {
        $cache_key = 'llms_quizzes_' . $course_id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $lessons = $this->get_lessons( $course_id );
        $quizzes = array();

        foreach ( $lessons as $lesson ) {
            if ( isset( $lesson['has_quiz'] ) && $lesson['has_quiz'] && ! empty( $lesson['quiz_id'] ) ) {
                $quiz = $this->get_quiz( $lesson['quiz_id'] );
                if ( ! is_wp_error( $quiz ) ) {
                    $quizzes[] = $quiz;
                }
            }
        }

        $this->cache_set( $cache_key, $quizzes );
        return $quizzes;
    }

    /**
     * Get a single quiz with questions.
     *
     * @param int $id Quiz ID.
     * @return array|WP_Error Normalized quiz data or error.
     */
    public function get_quiz( $id ) {
        $cache_key = 'llms_quiz_' . $id;
        $cached = $this->cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $response = $this->make_api_request( '/quizzes/' . absint( $id ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $quiz = $this->format_quiz( $response );
        $this->cache_set( $cache_key, $quiz );
        return $quiz;
    }

    /**
     * Get user's course progress.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return array|WP_Error Progress data or error.
     */
    public function get_course_progress( $course_id, $user_id ) {
        $response = $this->make_api_request(
            '/students/' . absint( $user_id ) . '/courses/' . absint( $course_id ) . '/progress',
            array(),
            'GET',
            true
        );

        if ( is_wp_error( $response ) ) {
            // Fallback: calculate from enrollment data.
            return $this->calculate_progress_from_enrollment( $course_id, $user_id );
        }

        $total_items    = isset( $response->total_items ) ? (int) $response->total_items : 0;
        $completed_items = isset( $response->completed_items ) ? (int) $response->completed_items : 0;
        $percentage     = $total_items > 0 ? round( ( $completed_items / $total_items ) * 100 ) : 0;

        return array(
            'course_id'       => $course_id,
            'user_id'         => $user_id,
            'total_items'     => $total_items,
            'completed_items' => $completed_items,
            'percentage'      => $percentage,
            'status'          => $percentage >= 100 ? 'completed' : ( $percentage > 0 ? 'in_progress' : 'not_started' ),
            'last_accessed'   => isset( $response->last_event_date ) ? $response->last_event_date : null,
        );
    }

    /**
     * Get course categories.
     *
     * @return array List of categories.
     */
    public function get_categories() {
        $cache_key = 'llms_categories';
        $cached = $this->cache_get( $cache_key, 'pagepilot_lms', DAY_IN_SECONDS );
        if ( $cached !== false ) {
            return $cached;
        }

        $response = $this->make_api_request( '/course-categories' );

        if ( is_wp_error( $response ) ) {
            // Fallback to WP taxonomy.
            $terms = get_terms( array(
                'taxonomy'   => 'course_cat',
                'hide_empty' => false,
            ) );

            $categories = array();
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $categories[] = array(
                        'id'    => $term->term_id,
                        'name'  => $term->name,
                        'slug'  => $term->slug,
                        'count' => $term->count,
                    );
                }
            }
            $this->cache_set( $cache_key, $categories, 'pagepilot_lms', DAY_IN_SECONDS );
            return $categories;
        }

        $categories = array();
        if ( is_object( $response ) && isset( $response->data ) && is_array( $response->data ) ) {
            $raw = $response->data;
        } else {
            $raw = is_array( $response ) ? $response : array();
        }
        foreach ( $raw as $cat ) {
            $categories[] = array(
                'id'    => isset( $cat->id ) ? $cat->id : 0,
                'name'  => isset( $cat->name ) ? $cat->name : '',
                'slug'  => isset( $cat->slug ) ? $cat->slug : '',
                'count' => isset( $cat->count ) ? (int) $cat->count : 0,
            );
        }

        $this->cache_set( $cache_key, $categories, 'pagepilot_lms', DAY_IN_SECONDS );
        return $categories;
    }

    /**
     * Get course tags.
     *
     * @return array List of tags.
     */
    public function get_tags() {
        $cache_key = 'llms_tags';
        $cached = $this->cache_get( $cache_key, 'pagepilot_lms', DAY_IN_SECONDS );
        if ( $cached !== false ) {
            return $cached;
        }

        $response = $this->make_api_request( '/course-tags' );

        if ( is_wp_error( $response ) ) {
            $terms = get_terms( array(
                'taxonomy'   => 'course_tag',
                'hide_empty' => false,
            ) );

            $tags = array();
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $tags[] = array(
                        'id'    => $term->term_id,
                        'name'  => $term->name,
                        'slug'  => $term->slug,
                        'count' => $term->count,
                    );
                }
            }
            $this->cache_set( $cache_key, $tags, 'pagepilot_lms', DAY_IN_SECONDS );
            return $tags;
        }

        $tags = array();
        if ( is_object( $response ) && isset( $response->data ) && is_array( $response->data ) ) {
            $raw = $response->data;
        } else {
            $raw = is_array( $response ) ? $response : array();
        }
        foreach ( $raw as $tag ) {
            $tags[] = array(
                'id'    => isset( $tag->id ) ? $tag->id : 0,
                'name'  => isset( $tag->name ) ? $tag->name : '',
                'slug'  => isset( $tag->slug ) ? $tag->slug : '',
                'count' => isset( $tag->count ) ? (int) $tag->count : 0,
            );
        }

        $this->cache_set( $cache_key, $tags, 'pagepilot_lms', DAY_IN_SECONDS );
        return $tags;
    }

    /**
     * Get instructors/authors.
     *
     * @return array List of instructors.
     */
    public function get_instructors() {
        $cache_key = 'llms_instructors';
        $cached = $this->cache_get( $cache_key, 'pagepilot_lms', DAY_IN_SECONDS );
        if ( $cached !== false ) {
            return $cached;
        }

        // LifterLMS stores instructors as post authors or via the instructor role.
        $instructors = array();
        $args = array(
            'role__in'   => array( 'lifterlms_instructor', 'lifterlms_instructor_assistant', 'administrator' ),
            'fields'     => array( 'ID', 'display_name', 'user_login', 'user_email' ),
            'number'     => 100,
            'orderby'    => 'display_name',
            'order'      => 'ASC',
        );

        $users = get_users( $args );

        foreach ( $users as $user ) {
            $avatar_id = get_user_meta( $user->ID, 'lifterlms_instructor_photo', true );
            $avatar_url = '';
            if ( $avatar_id ) {
                $avatar_url = wp_get_attachment_image_url( $avatar_id, 'thumbnail' );
            }
            if ( ! $avatar_url ) {
                $avatar_url = get_avatar_url( $user->ID, array( 'size' => 96 ) );
            }

            $instructors[] = array(
                'id'     => $user->ID,
                'name'   => $user->display_name,
                'avatar' => $avatar_url,
                'email'  => $user->user_email,
            );
        }

        $this->cache_set( $cache_key, $instructors, 'pagepilot_lms', DAY_IN_SECONDS );
        return $instructors;
    }

    /**
     * Sync all courses to the cache table.
     *
     * @return array{synced: int, errors: int} Sync result.
     */
    public function sync_courses() {
        $page     = 1;
        $per_page = 50;
        $synced   = 0;
        $errors   = 0;

        do {
            $result = $this->get_courses( array(
                'page'     => $page,
                'per_page' => $per_page,
                'status'   => 'publish',
            ) );

            if ( is_wp_error( $result ) ) {
                $this->log_error( $result->get_error_message(), 'sync_courses' );
                break;
            }

            foreach ( $result['courses'] as $course ) {
                $stored = $this->store_in_cache_table( 'course', $course['id'], $course );
                if ( $stored ) {
                    $synced++;
                } else {
                    $errors++;
                }

                // Also sync lessons and quizzes for each course.
                $lessons = $this->get_lessons( $course['id'] );
                foreach ( $lessons as $lesson ) {
                    $this->store_in_cache_table( 'lesson', $lesson['id'], $lesson );
                }

                $quizzes = $this->get_quizzes( $course['id'] );
                foreach ( $quizzes as $quiz ) {
                    $this->store_in_cache_table( 'quiz', $quiz['id'], $quiz );
                }
            }

            $page++;
        } while ( $page <= $result['pages'] );

        return array(
            'synced' => $synced,
            'errors' => $errors,
        );
    }

    // =========================================================================
    // Private Helpers
    // =========================================================================

    /**
     * Get the course curriculum (sections with their lessons/quizzes).
     *
     * @param int $course_id Course ID.
     * @return array Curriculum structure.
     */
    private function get_course_curriculum( $course_id ) {
        $response = $this->make_api_request( '/courses/' . absint( $course_id ) );

        if ( is_wp_error( $response ) ) {
            return array();
        }

        $curriculum  = array();
        $raw_sections = isset( $response->sections ) ? $response->sections : array();

        foreach ( $raw_sections as $section_ref ) {
            $section_id = is_object( $section_ref ) ? $section_ref->id : $section_ref;
            $section_data = $this->make_api_request( '/sections/' . absint( $section_id ) );

            if ( is_wp_error( $section_data ) ) {
                continue;
            }

            $items = array();
            $raw_lessons = isset( $section_data->lessons ) ? $section_data->lessons : array();

            foreach ( $raw_lessons as $lesson_ref ) {
                $lesson_id = is_object( $lesson_ref ) ? $lesson_ref->id : $lesson_ref;
                $lesson_post = get_post( $lesson_id );

                if ( ! $lesson_post ) {
                    continue;
                }

                $items[] = array(
                    'type'     => 'lesson',
                    'id'       => $lesson_id,
                    'title'    => $lesson_post->post_title,
                    'duration' => get_post_meta( $lesson_id, '_lesson_duration', true ),
                );

                // Check if lesson has a quiz.
                $quiz_id = get_post_meta( $lesson_id, '_llms_quiz', true );
                if ( $quiz_id ) {
                    $quiz_post = get_post( $quiz_id );
                    if ( $quiz_post ) {
                        $items[] = array(
                            'type'     => 'quiz',
                            'id'       => (int) $quiz_id,
                            'title'    => $quiz_post->post_title,
                            'duration' => '',
                        );
                    }
                }
            }

            $curriculum[] = array(
                'section_title' => isset( $section_data->title ) ? $section_data->title : '',
                'items'         => $items,
            );
        }

        return $curriculum;
    }

    /**
     * Calculate progress from enrollment data when the progress endpoint fails.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return array Progress data.
     */
    private function calculate_progress_from_enrollment( $course_id, $user_id ) {
        $enrolled = llms_is_user_enrolled( $user_id, $course_id );

        if ( ! $enrolled ) {
            return array(
                'course_id'       => $course_id,
                'user_id'         => $user_id,
                'total_items'     => 0,
                'completed_items' => 0,
                'percentage'      => 0,
                'status'          => 'not_started',
                'last_accessed'   => null,
            );
        }

        $lessons = $this->get_lessons( $course_id );
        $total   = count( $lessons );
        $completed = 0;

        foreach ( $lessons as $lesson ) {
            $status = llms_get_user_post_status( $user_id, $lesson['id'] );
            if ( 'complete' === $status ) {
                $completed++;
            }
        }

        $percentage = $total > 0 ? round( ( $completed / $total ) * 100 ) : 0;

        return array(
            'course_id'       => $course_id,
            'user_id'         => $user_id,
            'total_items'     => $total,
            'completed_items' => $completed,
            'percentage'      => $percentage,
            'status'          => $percentage >= 100 ? 'completed' : ( $percentage > 0 ? 'in_progress' : 'not_started' ),
            'last_accessed'   => null,
        );
    }

    /**
     * Make an authenticated request to the LifterLMS REST API.
     *
     * @param string $endpoint API endpoint path.
     * @param array  $params   Query parameters.
     * @param string $method   HTTP method.
     * @param bool   $auth     Whether to include authentication.
     * @return array|WP_Error Response data or error.
     */
    private function make_api_request( $endpoint, $params = array(), $method = 'GET', $auth = false ) {
        $url = home_url( $this->api_base . $endpoint );

        if ( ! empty( $params ) && 'GET' === $method ) {
            $url = add_query_arg( $params, $url );
        }

        $headers = array(
            'Accept' => 'application/json',
        );

        // LifterLMS REST API key authentication.
        if ( $auth ) {
            $key_id     = get_option( 'pagepilot_llms_api_key', '' );
            $secret_key = get_option( 'pagepilot_llms_api_secret', '' );

            if ( ! empty( $key_id ) && ! empty( $secret_key ) ) {
                $headers['X-Llms-Builder-Key']    = $key_id;
                $headers['X-Llms-Builder-Secret'] = $secret_key;
            }
        }

        $args = array(
            'method'  => $method,
            'headers' => $headers,
            'timeout' => $this->request_timeout,
        );

        if ( ! empty( $params ) && 'GET' !== $method ) {
            $args['body'] = wp_json_encode( $params );
            $headers['Content-Type'] = 'application/json';
        }

        $response = wp_remote_request( $url, $args );

        if ( is_wp_error( $response ) ) {
            $this->log_error( $response->get_error_message(), 'api_request' );
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body );

        if ( $code < 200 || $code >= 300 ) {
            $message = isset( $data->message ) ? $data->message : 'API request failed with status ' . $code;
            $this->log_error( $message, 'api_request' );
            return new WP_Error( 'llms_api_error', $message, array( 'status' => $code ) );
        }

        // Extract pagination headers if present.
        $result = $data;
        $headers_raw = wp_remote_retrieve_headers( $response );
        if ( isset( $headers_raw['x-wp-total'] ) ) {
            $result = (object) array(
                'data'    => $data,
                'headers' => array(
                    'x-wp-total'      => $headers_raw['x-wp-total'],
                    'x-wp-totalpages' => $headers_raw['x-wp-totalpages'],
                ),
            );
        }

        return $result;
    }

    /**
     * Normalize a raw LifterLMS course object to PagePilot's standard format.
     *
     * @param object $raw Raw course data from LifterLMS API.
     * @return array Normalized course data.
     */
    private function format_course( $raw ) {
        $id = isset( $raw->id ) ? (int) $raw->id : 0;

        // Get thumbnail.
        $thumbnail = '';
        if ( has_post_thumbnail( $id ) ) {
            $thumbnail = get_the_post_thumbnail_url( $id, 'large' );
        }

        // Get price info.
        $price      = '';
        $sale_price = '';
        $price_raw  = get_post_meta( $id, '_llms_price', true );
        $sale_raw   = get_post_meta( $id, '_llms_sale_price', true );

        if ( 'yes' === get_post_meta( $id, '_llms_is_free', true ) || '' === $price_raw ) {
            $price = __( 'Free', 'pagepilot' );
        } elseif ( $price_raw ) {
            $currency = get_option( 'llms_currency', 'USD' );
            $symbol   = llms_currency_symbol( $currency );
            $price    = $symbol . number_format( (float) $price_raw, 2 );
            if ( $sale_raw ) {
                $sale_price = $symbol . number_format( (float) $sale_raw, 2 );
            }
        }

        // Duration.
        $duration_hours   = get_post_meta( $id, '_llms_duration_hours', true );
        $duration_minutes = get_post_meta( $id, '_llms_duration_minutes', true );
        $duration = '';
        if ( $duration_hours || $duration_minutes ) {
            $hours   = (int) $duration_hours;
            $minutes = (int) $duration_minutes;
            if ( $hours > 0 && $minutes > 0 ) {
                $duration = $hours . 'h ' . $minutes . 'm';
            } elseif ( $hours > 0 ) {
                $duration = $hours . 'h';
            } else {
                $duration = $minutes . 'm';
            }
        }

        // Instructor.
        $author_id  = isset( $raw->author ) ? (int) $raw->author : (int) $raw->post_author;
        $author     = get_userdata( $author_id );
        $instructor = array(
            'name'   => $author ? $author->display_name : '',
            'avatar' => $author ? get_avatar_url( $author_id, array( 'size' => 96 ) ) : '',
        );

        // Rating.
        $rating = 0;
        $rating_count = 0;
        if ( function_exists( 'llms_get_course_rating' ) ) {
            $rating_data = llms_get_course_rating( $id );
            if ( $rating_data ) {
                $rating       = isset( $rating_data->rating ) ? (float) $rating_data->rating : 0;
                $rating_count = isset( $rating_data->count ) ? (int) $rating_data->count : 0;
            }
        }

        // Students count.
        $students_count = 0;
        global $wpdb;
        $enrolled = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT post_author) FROM {$wpdb->posts}
                 WHERE ID IN (
                     SELECT post_parent FROM {$wpdb->posts} WHERE post_type = 'llms_enrollment' AND post_status = 'publish'
                 ) AND ID = %d",
                $id
            )
        );
        if ( $enrolled ) {
            $students_count = (int) $enrolled;
        }

        // Categories.
        $categories = array();
        $cat_terms = get_the_terms( $id, 'course_cat' );
        if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
            foreach ( $cat_terms as $cat ) {
                $categories[] = $cat->name;
            }
        }

        // Tags.
        $tags = array();
        $tag_terms = get_the_terms( $id, 'course_tag' );
        if ( $tag_terms && ! is_wp_error( $tag_terms ) ) {
            foreach ( $tag_terms as $tag ) {
                $tags[] = $tag->name;
            }
        }

        // Lesson/quiz counts from curriculum.
        $lessons_count = 0;
        $quizzes_count = 0;
        $raw_sections = isset( $raw->sections ) ? $raw->sections : array();
        foreach ( $raw_sections as $section_ref ) {
            $section_id = is_object( $section_ref ) ? $section_ref->id : $section_ref;
            $section_data = get_post( $section_id );
            if ( ! $section_data ) {
                continue;
            }
            // Count lessons via WP query for this section.
            $section_lessons = get_posts( array(
                'post_type'   => 'lesson',
                'post_parent' => $section_id,
                'numberposts' => -1,
                'fields'      => 'ids',
            ) );
            $lessons_count += count( $section_lessons );
            foreach ( $section_lessons as $lid ) {
                if ( get_post_meta( $lid, '_llms_quiz', true ) ) {
                    $quizzes_count++;
                }
            }
        }

        return array(
            'id'              => $id,
            'title'           => isset( $raw->title ) ? ( is_object( $raw->title ) ? $raw->title->rendered : $raw->title ) : get_the_title( $id ),
            'description'     => isset( $raw->content ) ? ( is_object( $raw->content ) ? $raw->content->rendered : $raw->content ) : get_the_content( null, false, $id ),
            'short_description' => isset( $raw->excerpt ) ? ( is_object( $raw->excerpt ) ? $raw->excerpt->rendered : $raw->excerpt ) : get_the_excerpt( $id ),
            'thumbnail'       => $thumbnail,
            'price'           => $price,
            'sale_price'      => $sale_price,
            'duration'        => $duration,
            'instructor'      => $instructor,
            'rating'          => $rating,
            'rating_count'    => $rating_count,
            'students_count'  => $students_count,
            'lessons_count'   => $lessons_count,
            'quizzes_count'   => $quizzes_count,
            'categories'      => $categories,
            'tags'            => $tags,
            'curriculum'      => array(),
            'is_enrolled'     => false,
            'progress'        => 0,
            'is_wishlisted'   => false,
            'permalink'       => get_the_permalink( $id ),
            'status'          => isset( $raw->status ) ? $raw->status : get_post_status( $id ),
            'date'            => isset( $raw->date ) ? $raw->date : get_the_date( 'c', $id ),
            'modified'        => isset( $raw->modified ) ? $raw->modified : get_the_modified_date( 'c', $id ),
        );
    }

    /**
     * Normalize a raw LifterLMS lesson object.
     *
     * @param object $raw Raw lesson data.
     * @return array Normalized lesson data.
     */
    private function format_lesson( $raw ) {
        $id = isset( $raw->id ) ? (int) $raw->id : 0;

        $duration = get_post_meta( $id, '_lesson_duration', true );
        $video_url = get_post_meta( $id, '_lesson_video_url', true );

        // Quiz association.
        $quiz_id = get_post_meta( $id, '_llms_quiz', true );
        $has_quiz = ! empty( $quiz_id );

        // Attachments / downloads.
        $attachments = array();
        $download_ids = get_post_meta( $id, '_llms_downloads', true );
        if ( is_array( $download_ids ) ) {
            foreach ( $download_ids as $att_id ) {
                $att = get_post( $att_id );
                if ( $att ) {
                    $attachments[] = array(
                        'id'   => $att_id,
                        'name' => $att->post_title,
                        'url'  => wp_get_attachment_url( $att_id ),
                        'type' => get_post_mime_type( $att_id ),
                        'size' => size_format( filesize( get_attached_file( $att_id ) ) ),
                    );
                }
            }
        }

        return array(
            'id'          => $id,
            'course_id'   => isset( $raw->parent ) ? (int) $raw->parent : (int) $raw->post_parent,
            'title'       => isset( $raw->title ) ? ( is_object( $raw->title ) ? $raw->title->rendered : $raw->title ) : get_the_title( $id ),
            'content'     => isset( $raw->content ) ? ( is_object( $raw->content ) ? $raw->content->rendered : $raw->content ) : get_the_content( null, false, $id ),
            'duration'    => $duration,
            'thumbnail'   => has_post_thumbnail( $id ) ? get_the_post_thumbnail_url( $id, 'large' ) : '',
            'video_url'   => $video_url,
            'attachments' => $attachments,
            'is_completed' => false,
            'has_quiz'    => $has_quiz,
            'quiz_id'     => $quiz_id ? (int) $quiz_id : null,
            'order'       => isset( $raw->menu_order ) ? (int) $raw->menu_order : 0,
            'permalink'   => get_the_permalink( $id ),
        );
    }

    /**
     * Normalize a raw LifterLMS quiz object.
     *
     * @param object $raw Raw quiz data.
     * @return array Normalized quiz data.
     */
    private function format_quiz( $raw ) {
        $id = isset( $raw->id ) ? (int) $raw->id : 0;

        $questions = array();
        $raw_questions = isset( $raw->questions ) ? $raw->questions : array();

        foreach ( $raw_questions as $q ) {
            $q_id = is_object( $q ) ? $q->id : $q;
            $question_post = get_post( $q_id );
            if ( ! $question_post ) {
                continue;
            }

            $q_type = get_post_meta( $q_id, '_llms_question_type', true );
            $correct = get_post_meta( $q_id, '_llms_answer_key', true );
            $options_raw = get_post_meta( $q_id, '_llms_question_options', true );
            $points     = get_post_meta( $q_id, '_llms_question_points', true );

            $options = array();
            if ( is_array( $options_raw ) ) {
                foreach ( $options_raw as $key => $opt_text ) {
                    $options[] = array(
                        'id'        => $key,
                        'title'     => $opt_text,
                        'is_correct' => is_array( $correct ) ? in_array( $key, $correct ) : ( $correct === $key ),
                    );
                }
            }

            $questions[] = array(
                'id'           => $q_id,
                'type'         => $q_type,
                'title'        => $question_post->post_title,
                'options'      => $options,
                'correct_answer' => $correct,
                'explanation'  => get_post_meta( $q_id, '_llms_question_explanation', true ),
                'points'       => $points ? (int) $points : 1,
                'user_answer'  => null,
            );
        }

        // Get parent lesson.
        $lesson_id = isset( $raw->lesson_id ) ? (int) $raw->lesson_id : 0;
        if ( ! $lesson_id ) {
            $lesson_id = (int) $raw->post_parent;
        }

        // Resolve course_id from the lesson's hierarchy:
        // Quiz → Lesson → Section → Course.
        // Also check _llms_parent_course meta directly on lesson.
        $course_id = 0;
        if ( $lesson_id > 0 ) {
            // Method 1: Check _llms_parent_course meta on the lesson.
            $parent_course_meta = get_post_meta( $lesson_id, '_llms_parent_course', true );
            if ( $parent_course_meta ) {
                $course_id = (int) $parent_course_meta;
            }

            // Method 2: Traverse lesson → section → course.
            if ( $course_id <= 0 ) {
                $lesson_post = get_post( $lesson_id );
                if ( $lesson_post && 'lesson' === $lesson_post->post_type ) {
                    $section_id = (int) $lesson_post->post_parent;
                    if ( $section_id > 0 ) {
                        $section_post = get_post( $section_id );
                        if ( $section_post && in_array( $section_post->post_type, array( 'llms_section', 'section' ), true ) ) {
                            $course_id = (int) $section_post->post_parent;
                        }
                    }
                }
            }

            // Method 3: Check _llms_parent_section meta on lesson → section → course.
            if ( $course_id <= 0 ) {
                $parent_section_meta = get_post_meta( $lesson_id, '_llms_parent_section', true );
                if ( $parent_section_meta ) {
                    $sec_post = get_post( (int) $parent_section_meta );
                    if ( $sec_post ) {
                        $course_id = (int) $sec_post->post_parent;
                    }
                }
            }
        }

        return array(
            'id'              => $id,
            'course_id'       => $course_id,
            'lesson_id'       => $lesson_id,
            'title'           => isset( $raw->title ) ? ( is_object( $raw->title ) ? $raw->title->rendered : $raw->title ) : get_the_title( $id ),
            'description'     => isset( $raw->content ) ? ( is_object( $raw->content ) ? $raw->content->rendered : $raw->content ) : '',
            'duration'        => get_post_meta( $id, '_llms_quiz_time_limit', true ),
            'passing_grade'   => (int) get_post_meta( $id, '_llms_quiz_passing_percent', true ),
            'max_attempts'    => (int) get_post_meta( $id, '_llms_quiz_limit_attempts', true ),
            'questions'       => $questions,
            'attempts'        => 0,
            'best_score'      => 0,
            'time_limit'      => get_post_meta( $id, '_llms_quiz_time_limit', true ),
            'randomize'       => 'yes' === get_post_meta( $id, '_llms_quiz_randomize', true ),
            'show_results'    => get_post_meta( $id, '_llms_quiz_results_display', true ),
        );
    }
}
