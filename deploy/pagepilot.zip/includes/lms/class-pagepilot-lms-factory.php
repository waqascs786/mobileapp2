<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Abstract base class for all LMS handlers.
 *
 * Every LMS integration must extend this class and implement all methods.
 */
abstract class PagePilot_LMS_Base {

    protected $lms_key = '';
    protected $api_base = '';

    abstract public function get_courses( $args = array() );
    abstract public function get_course( $id );
    abstract public function get_lessons( $course_id );
    abstract public function get_lesson( $id );
    abstract public function get_quizzes( $course_id );
    abstract public function get_quiz( $id );
    abstract public function get_course_progress( $course_id, $user_id );
    abstract public function get_categories();
    abstract public function get_tags();
    abstract public function get_instructors();
    abstract public function sync_courses();

    public function get_lms_key() {
        return $this->lms_key;
    }

    public function get_api_base() {
        return $this->api_base;
    }

    protected function cache_get( $key, $group = 'pagepilot_lms', $expiry = HOUR_IN_SECONDS ) {
        return wp_cache_get( $key, $group );
    }

    protected function cache_set( $key, $data, $group = 'pagepilot_lms', $expiry = HOUR_IN_SECONDS ) {
        wp_cache_set( $key, $data, $group, $expiry );
    }

    protected function cache_delete( $key, $group = 'pagepilot_lms' ) {
        wp_cache_delete( $key, $group );
    }

    protected function store_in_cache_table( $item_type, $item_id, $item_data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';
        $result = $wpdb->replace(
            $table,
            array(
                'lms_plugin' => $this->lms_key,
                'item_type'  => $item_type,
                'item_id'    => $item_id,
                'item_data'  => wp_json_encode( $item_data ),
                'last_synced' => current_time( 'mysql' ),
            ),
            array( '%s', '%s', '%d', '%s', '%s' )
        );
        return $result !== false;
    }

    protected function get_from_cache_table( $item_type, $item_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT item_data FROM $table WHERE lms_plugin = %s AND item_type = %s AND item_id = %d",
                $this->lms_key,
                $item_type,
                $item_id
            )
        );
        if ( $row ) {
            return json_decode( $row->item_data, true );
        }
        return null;
    }

    protected function get_all_from_cache_table( $item_type ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pagepilot_course_cache';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT item_id, item_data, last_synced FROM $table WHERE lms_plugin = %s AND item_type = %s ORDER BY last_synced DESC",
                $this->lms_key,
                $item_type
            )
        );
        $items = array();
        foreach ( $rows as $row ) {
            $items[] = array(
                'id'          => (int) $row->item_id,
                'data'        => json_decode( $row->item_data, true ),
                'last_synced' => $row->last_synced,
            );
        }
        return $items;
    }

    protected function log_error( $message, $context = '' ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $log_message = '[PagePilot LMS][' . $this->lms_key . ']';
            if ( $context ) {
                $log_message .= '[' . $context . ']';
            }
            $log_message .= ' ' . $message;
            error_log( $log_message );
        }
    }
}

/**
 * Factory class that detects active LMS plugins and returns the appropriate handler.
 */
class PagePilot_LMS_Factory {

    private static $handlers = array(
        'learnpress' => 'PagePilot_LearnPress',
        'learndash'  => 'PagePilot_LearnDash',
        'lifterlms'  => 'PagePilot_LifterLMS',
        'sensei'     => 'PagePilot_Sensei',
    );

    private static $instances = array();

    /**
     * Get an LMS handler instance for the given key.
     *
     * @param string $lms_key The LMS identifier (e.g. 'learnpress').
     * @return PagePilot_LMS_Base|null The handler instance or null if unsupported/inactive.
     */
    public static function get_handler( $lms_key ) {
        if ( isset( self::$instances[ $lms_key ] ) ) {
            return self::$instances[ $lms_key ];
        }

        if ( ! isset( self::$handlers[ $lms_key ] ) ) {
            return null;
        }

        $class_name = self::$handlers[ $lms_key ];

        if ( ! class_exists( $class_name ) ) {
            return null;
        }

        $handler = new $class_name();
        if ( ! $handler instanceof PagePilot_LMS_Base ) {
            return null;
        }

        self::$instances[ $lms_key ] = $handler;
        return $handler;
    }

    /**
     * Get handler for the currently active/selected LMS.
     *
     * @return PagePilot_LMS_Base|null
     */
    public static function get_active_handler() {
        $active_lms = self::get_detected_lms();
        $selected   = get_option( 'pagepilot_lms_plugin', '' );

        if ( $selected && isset( $active_lms[ $selected ] ) && $active_lms[ $selected ]['active'] ) {
            return self::get_handler( $selected );
        }

        foreach ( $active_lms as $key => $lms ) {
            if ( $lms['active'] ) {
                return self::get_handler( $key );
            }
        }

        return null;
    }

    /**
     * Detect which LMS plugins are installed and active.
     *
     * @return array Associative array of LMS key => detection info.
     */
    public static function get_detected_lms() {
        $detected = array();
        foreach ( self::$handlers as $key => $class_name ) {
            $info = PagePilot_Detector::get_lms_info( $key );
            if ( ! $info ) {
                continue;
            }
            $status = self::check_plugin_active( $info['slug'] );
            $detected[ $key ] = array(
                'name'      => $info['name'],
                'slug'      => $info['slug'],
                'active'    => $status,
                'api_base'  => $info['api_base'],
                'handler'   => $class_name,
            );
        }
        return $detected;
    }

    /**
     * Get all active LMS keys.
     *
     * @return array List of active LMS keys.
     */
    public static function get_active_lms_keys() {
        $detected = self::get_detected_lms();
        $active   = array();
        foreach ( $detected as $key => $lms ) {
            if ( $lms['active'] ) {
                $active[] = $key;
            }
        }
        return $active;
    }

    /**
     * Check if a specific LMS is active.
     *
     * @param string $lms_key The LMS identifier.
     * @return bool
     */
    public static function is_lms_active( $lms_key ) {
        $detected = self::get_detected_lms();
        return isset( $detected[ $lms_key ] ) && $detected[ $lms_key ]['active'];
    }

    /**
     * Register a new LMS handler.
     *
     * @param string $lms_key   Unique key for the LMS.
     * @param string $class_name The handler class name extending PagePilot_LMS_Base.
     */
    public static function register_handler( $lms_key, $class_name ) {
        self::$handlers[ $lms_key ] = $class_name;
    }

    private static function check_plugin_active( $plugin_slug ) {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        return is_plugin_active( $plugin_slug );
    }
}
