<?php
/**
 * PagePilot App API — PHP Proxy Layer
 *
 * Registers all REST API routes that the Flutter app calls.
 * Proxies requests to LifterLMS internally using PHP functions.
 *
 * @package PagePilot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PagePilot_App_API {

    const NAMESPACE = 'pagepilot/v1';

    /**
     * Register all app-facing REST routes.
     */
    public function register_routes() {
        // ── Auth ────────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/auth/login', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'app_login' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/auth/register', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'app_register' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/auth/forgot-password', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'app_forgot_password' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        // ── Student ────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/student/profile', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_student_profile' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/student/enrolled-courses', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_enrolled_courses' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Courses ────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/courses', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_courses' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/courses/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_course_detail' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/courses/(?P<id>\d+)/curriculum', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_course_curriculum' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/courses/(?P<id>\d+)/reviews', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_course_reviews' ),
                'permission_callback' => '__return_true',
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'submit_course_review' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Enrollment ─────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/courses/(?P<id>\d+)/enroll', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'enroll_in_course' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Lessons ────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/lessons/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_lesson' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/lessons/(?P<id>\d+)/complete', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'complete_lesson' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Quizzes ────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/quizzes/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_quiz' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/quizzes/(?P<id>\d+)/submit', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'submit_quiz' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Progress ───────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/courses/(?P<id>\d+)/progress', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_course_progress' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Certificates ───────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/certificates', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_certificates' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Wishlist ───────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/wishlist', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_wishlist' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/app/wishlist/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'add_to_wishlist' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
            array(
                'methods'             => 'DELETE',
                'callback'            => array( $this, 'remove_from_wishlist' ),
                'permission_callback' => array( $this, 'app_auth_check' ),
            ),
        ) );

        // ── Categories ─────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/categories', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_categories' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        // ── Search ─────────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/search', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'search' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        // ── Instructors ────────────────────────────────────────
        register_rest_route( self::NAMESPACE, '/app/instructors', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_instructors' ),
                'permission_callback' => '__return_true',
            ),
        ) );
    }

    // =========================================================================
    // Permission Callbacks
    // =========================================================================

    /**
     * App auth check — validates WordPress nonce or application password.
     */
    public function app_auth_check() {
        $user_id = $this->get_app_user_id();
        return $user_id > 0;
    }

    /**
     * Extract user ID from the request.
     * Supports: Bearer token (nonce), Basic auth, or X-WP-Nonce header.
     */
    private function get_app_user_id() {
        // Method 1: Bearer token (WordPress nonce used as simple token).
        $auth_header = isset( $_SERVER['HTTP_AUTHORIZATION'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) ) : '';
        if ( preg_match( '/Bearer\s+(.+)/i', $auth_header, $matches ) ) {
            $token = $matches[1];
            // Try nonce verification.
            if ( wp_verify_nonce( $token, 'wp_rest' ) ) {
                return get_current_user_id();
            }
            // Try as user ID (simple token from login response).
            $user_id = absint( $token );
            if ( $user_id > 0 && get_userdata( $user_id ) ) {
                wp_set_current_user( $user_id );
                return $user_id;
            }
        }

        // Method 2: X-WP-Nonce header.
        $nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) ) : '';
        if ( ! empty( $nonce ) && wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return get_current_user_id();
        }

        // Method 3: Basic Auth (username:password).
        if ( isset( $_SERVER['PHP_AUTH_USER'] ) && isset( $_SERVER['PHP_AUTH_PW'] ) ) {
            $user = wp_authenticate( sanitize_text_field( wp_unslash( $_SERVER['PHP_AUTH_USER'] ) ), wp_unslash( $_SERVER['PHP_AUTH_PW'] ) );
            if ( ! is_wp_error( $user ) ) {
                wp_set_current_user( $user->ID );
                return $user->ID;
            }
        }

        // Method 4: X-PagePilot-User + X-PagePilot-Token custom headers.
        $pp_user = isset( $_SERVER['HTTP_X_PAGEPILOT_USER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_PAGEPILOT_USER'] ) ) : '';
        $pp_token = isset( $_SERVER['HTTP_X_PAGEPILOT_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_PAGEPILOT_TOKEN'] ) ) : '';
        if ( ! empty( $pp_user ) && ! empty( $pp_token ) ) {
            // Token = MD5(user_id + site_salt).
            $user = get_user_by( 'login', $pp_user );
            if ( $user ) {
                $expected = md5( $user->ID . wp_salt() );
                if ( hash_equals( $expected, $pp_token ) ) {
                    wp_set_current_user( $user->ID );
                    return $user->ID;
                }
            }
        }

        return 0;
    }

    // =========================================================================
    // Auth Endpoints
    // =========================================================================

    /**
     * POST /app/auth/login
     */
    public function app_login( $request ) {
        $params = $request->get_json_params();
        $username = isset( $params['username'] ) ? sanitize_user( $params['username'] ) : '';
        $password = isset( $params['password'] ) ? $params['password'] : '';

        if ( empty( $username ) || empty( $password ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Username and password are required.', 'pagepilot' ) ), 400 );
        }

        $user = wp_authenticate( $username, $password );
        if ( is_wp_error( $user ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Invalid username or password.', 'pagepilot' ) ), 401 );
        }

        // Generate simple auth token.
        $token = md5( $user->ID . wp_salt() );

        // Update last login.
        update_user_meta( $user->ID, 'llms_last_login', current_time( 'mysql' ) );

        // Get student data if LifterLMS is active.
        $student_data = array();
        if ( class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user->ID );
            if ( $student ) {
                // get_courses() returns array with 'results' key (enrollment IDs).
                $enrollments     = $student->get_courses( array( 'limit' => 9999 ) );
                $completed       = $student->get_completed_courses( array( 'limit' => 9999 ) );
                $student_data    = array(
                    'enrolled_count'  => isset( $enrollments['found'] ) ? (int) $enrollments['found'] : 0,
                    'completed_count' => isset( $completed['results'] ) ? count( $completed['results'] ) : 0,
                );
            }
        }

        return new WP_REST_Response( array(
            'success' => true,
            'data'    => array(
                'id'           => $user->ID,
                'username'     => $user->user_login,
                'email'        => $user->user_email,
                'display_name' => $user->display_name,
                'first_name'   => $user->first_name,
                'last_name'    => $user->last_name,
                'avatar'       => get_avatar_url( $user->ID, array( 'size' => 200 ) ),
                'token'        => $token,
                'student'      => $student_data,
            ),
        ), 200 );
    }

    /**
     * POST /app/auth/register
     */
    public function app_register( $request ) {
        $params = $request->get_json_params();
        $username  = isset( $params['username'] ) ? sanitize_user( $params['username'] ) : '';
        $email     = isset( $params['email'] ) ? sanitize_email( $params['email'] ) : '';
        $password  = isset( $params['password'] ) ? $params['password'] : '';
        $first     = isset( $params['first_name'] ) ? sanitize_text_field( $params['first_name'] ) : '';
        $last      = isset( $params['last_name'] ) ? sanitize_text_field( $params['last_name'] ) : '';

        if ( empty( $username ) || empty( $email ) || empty( $password ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Username, email, and password are required.', 'pagepilot' ) ), 400 );
        }

        if ( username_exists( $username ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Username already taken.', 'pagepilot' ) ), 409 );
        }

        if ( email_exists( $email ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Email already registered.', 'pagepilot' ) ), 409 );
        }

        $user_id = wp_create_user( $username, $password, $email );
        if ( is_wp_error( $user_id ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => $user_id->get_error_message() ), 500 );
        }

        wp_update_user( array(
            'ID'         => $user_id,
            'first_name' => $first,
            'last_name'  => $last,
            'display_name' => trim( $first . ' ' . $last ) ?: $username,
        ) );

        // Auto-login.
        wp_set_current_user( $user_id );
        $token = md5( $user_id . wp_salt() );

        return new WP_REST_Response( array(
            'success' => true,
            'data'    => array(
                'id'           => $user_id,
                'username'     => $username,
                'email'        => $email,
                'display_name' => trim( $first . ' ' . 'last' ) ?: $username,
                'first_name'   => $first,
                'last_name'    => $last,
                'avatar'       => get_avatar_url( $user_id, array( 'size' => 200 ) ),
                'token'        => $token,
            ),
        ), 201 );
    }

    /**
     * POST /app/auth/forgot-password
     */
    public function app_forgot_password( $request ) {
        $params = $request->get_json_params();
        $email = isset( $params['email'] ) ? sanitize_email( $params['email'] ) : '';

        if ( empty( $email ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Email is required.', 'pagepilot' ) ), 400 );
        }

        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            // Don't reveal whether email exists.
            return new WP_REST_Response( array( 'success' => true, 'message' => __( 'If an account exists with that email, a password reset link has been sent.', 'pagepilot' ) ), 200 );
        }

        $reset_key = get_password_reset_key( $user );
        if ( is_wp_error( $reset_key ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => __( 'Unable to generate reset link.', 'pagepilot' ) ), 500 );
        }

        $reset_url = network_site_url( "wp-login.php?action=rp&key={$reset_key}&login=" . rawurlencode( $user->user_login ), 'login' );

        // Send email.
        $message = __( 'Someone requested a password reset for the following account:', 'pagepilot' ) . "\r\n\r\n";
        $message .= sprintf( __( 'Username: %s', 'pagepilot' ), $user->user_login ) . "\r\n\r\n";
        $message .= __( 'If this was a mistake, just ignore this email and nothing will happen.', 'pagepilot' ) . "\r\n\r\n";
        $message .= __( 'To reset your password, visit the following address:', 'pagepilot' ) . "\r\n\r\n";
        $message .= $reset_url;

        wp_mail( $email, __( '[%s] Password Reset', 'pagepilot' ), $message );

        return new WP_REST_Response( array( 'success' => true, 'message' => __( 'Password reset link sent.', 'pagepilot' ) ), 200 );
    }

    // =========================================================================
    // Student Profile
    // =========================================================================

    /**
     * GET /app/student/profile
     */
    public function get_student_profile( $request ) {
        $user_id = $this->get_app_user_id();
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'User not found.' ), 404 );
        }

        $profile = array(
            'id'           => $user_id,
            'username'     => $user->user_login,
            'email'        => $user->user_email,
            'display_name' => $user->display_name,
            'first_name'   => $user->first_name,
            'last_name'    => $user->last_name,
            'avatar'       => get_avatar_url( $user_id, array( 'size' => 200 ) ),
            'registered'   => $user->user_registered,
        );

        // LifterLMS student data.
        if ( class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user_id );
            if ( $student ) {
                $enrollments     = $student->get_courses( array( 'limit' => 9999 ) );
                $completed       = $student->get_completed_courses( array( 'limit' => 9999 ) );
                $certificates    = function_exists( 'llms_get_certificates_by_student' ) ? llms_get_certificates_by_student( $user_id ) : array();

                $enrolled_ids    = isset( $enrollments['results'] ) ? $enrollments['results'] : array();
                $completed_ids   = isset( $completed['results'] ) ? $completed['results'] : array();

                $profile['enrolled_count']  = count( $enrolled_ids );
                $profile['completed_count'] = count( $completed_ids );
                $profile['certificate_count'] = is_array( $certificates ) ? count( $certificates ) : 0;

                // Overall progress — get_progress() returns a float percentage (0–100).
                $progress_sum = 0;
                $progress_count = 0;
                foreach ( $enrolled_ids as $course_id ) {
                    $p = $student->get_progress( $course_id );
                    if ( is_numeric( $p ) ) {
                        $progress_sum += (float) $p;
                        $progress_count++;
                    }
                }
                $profile['overall_progress'] = $progress_count > 0 ? round( $progress_sum / $progress_count ) : 0;
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $profile ), 200 );
    }

    // =========================================================================
    // Enrolled Courses
    // =========================================================================

    /**
     * GET /app/student/enrolled-courses
     */
    public function get_enrolled_courses( $request ) {
        $user_id = $this->get_app_user_id();
        $courses = array();

        try {
            if ( class_exists( 'LifterLMS' ) ) {
                $student = llms_get_student( $user_id );
                if ( $student ) {
                    $enrolled = $student->get_courses( array( 'limit' => 9999 ) );
                    $enrolled_ids = isset( $enrolled['results'] ) ? $enrolled['results'] : array();

                    foreach ( $enrolled_ids as $course_id ) {
                        $course = new LLMS_Course( $course_id );
                        if ( ! $course ) {
                            continue;
                        }

                        // get_progress() returns a float percentage (0–100).
                        $pct    = 0;
                        $status = 'not_started';
                        $progress = $student->get_progress( $course_id );
                        if ( is_numeric( $progress ) ) {
                            $pct    = round( (float) $progress );
                            $status = $pct >= 100 ? 'completed' : ( $pct > 0 ? 'in_progress' : 'not_started' );
                        }

                        // Get enrollment date.
                        $enrolled_date = $student->get_enrollment_date( $course_id, 'enrolled', 'Y-m-d' );
                        if ( ! $enrolled_date ) {
                            $enrolled_date = '';
                        }

                        $title      = method_exists( $course, 'get_title' ) ? $course->get_title() : get_the_title( $course_id );
                        $thumb      = get_the_post_thumbnail_url( $course_id, 'medium' );
                        $instructor = $this->get_course_instructor( $course_id );
                        $count      = method_exists( $course, 'get_lesson_count' ) ? (int) $course->get_lesson_count() : 0;
                        $permalink  = get_the_permalink( $course_id );

                        $courses[] = array(
                            'id'                => $course_id,
                            'title'             => $title,
                            'description'       => wp_trim_words( get_the_excerpt( $course_id ), 30 ),
                            'shortDescription'  => wp_trim_words( get_the_excerpt( $course_id ), 20 ),
                            'thumbnail'         => $thumb ? $thumb : '',
                            'price'             => $this->get_course_price_num( $course_id ),
                            'salePrice'         => (float) ( get_post_meta( $course_id, '_llms_sale_price', true ) ?: 0 ),
                            'duration'          => $this->get_course_duration( $course_id ),
                            'instructor'        => $instructor,
                            'rating'            => 0,
                            'ratingCount'       => 0,
                            'studentsCount'     => 0,
                            'lessonsCount'      => $count,
                            'quizzesCount'      => $this->get_quiz_count( $course_id ),
                            'categories'        => $this->get_course_categories( $course_id ),
                            'tags'              => $this->get_course_tags( $course_id ),
                            'curriculum'        => array(),
                            'isEnrolled'        => true,
                            'isWishlisted'      => false,
                            'progress'          => $pct,
                            'status'            => $status,
                            'enrolledDate'      => $enrolled_date,
                            'permalink'         => $permalink ? $permalink : '',
                        );
                    }
                }
            }
        } catch ( \Throwable $e ) {
            return new WP_REST_Response( array(
                'success' => false,
                'message' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
            ), 500 );
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $courses ), 200 );
    }

    // =========================================================================
    // Courses (Public)
    // =========================================================================

    /**
     * GET /app/courses
     */
    public function get_courses( $request ) {
        $page     = $request->get_param( 'page' ) ?: 1;
        $per_page = min( $request->get_param( 'per_page' ) ?: 20, 100 );
        $search   = $request->get_param( 'search' ) ?: '';
        $category = $request->get_param( 'category' ) ?: '';
        $orderby  = $request->get_param( 'orderby' ) ?: 'date';
        $order    = $request->get_param( 'order' ) ?: 'DESC';

        $args = array(
            'post_type'      => 'course',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => absint( $page ),
            'orderby'        => $orderby,
            'order'          => $order,
        );

        if ( ! empty( $search ) ) {
            $args['s'] = sanitize_text_field( $search );
        }

        if ( ! empty( $category ) ) {
            $cat_field = is_numeric( $category ) ? 'term_id' : 'slug';
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'course_cat',
                    'field'    => $cat_field,
                    'terms'    => sanitize_text_field( $category ),
                ),
            );
        }

        $query = new WP_Query( $args );
        $courses = array();

        try {
            foreach ( $query->posts as $post ) {
                $courses[] = $this->format_course_public( $post->ID );
            }
        } catch ( \Throwable $e ) {
            return new WP_REST_Response( array(
                'success' => false,
                'message' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
            ), 500 );
        }

        return new WP_REST_Response( array(
            'success' => true,
            'data'    => $courses,
            'total'   => $query->found_posts,
            'pages'   => $query->max_num_pages,
            'page'    => absint( $page ),
        ), 200 );
    }

    /**
     * GET /app/courses/{id}
     */
    public function get_course_detail( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $post      = get_post( $course_id );

        if ( ! $post || 'course' !== $post->post_type ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Course not found.' ), 404 );
        }

        try {
            $data = $this->format_course_public( $course_id, true );

            // Add curriculum as sections with items (Flutter expects 'curriculum' key).
            $data['curriculum'] = $this->get_course_sections( $course_id );
        } catch ( \Throwable $e ) {
            return new WP_REST_Response( array(
                'success' => false,
                'message' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
            ), 500 );
        }

        // Check enrollment.
        $user_id = $this->get_app_user_id();
        if ( $user_id > 0 && class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user_id );
            if ( $student ) {
                $data['isEnrolled'] = $student->is_enrolled( $course_id );
                if ( $data['isEnrolled'] ) {
                    // get_progress() returns a float percentage (0–100).
                    $data['progress'] = 0;
                    $progress = $student->get_progress( $course_id );
                    if ( is_numeric( $progress ) ) {
                        $data['progress'] = round( (float) $progress );
                    }
                }
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $data ), 200 );
    }

    /**
     * GET /app/courses/{id}/curriculum
     */
    public function get_course_curriculum( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $sections  = $this->get_course_sections( $course_id, true );

        return new WP_REST_Response( array( 'success' => true, 'data' => $sections ), 200 );
    }

    // =========================================================================
    // Enrollment
    // =========================================================================

    /**
     * POST /app/courses/{id}/enroll
     */
    public function enroll_in_course( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();

        if ( $user_id <= 0 ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Please log in to enroll.' ), 401 );
        }

        if ( ! class_exists( 'LifterLMS' ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'LMS not available.' ), 500 );
        }

        $course = new LLMS_Course( $course_id );
        if ( ! $course || ! $course->get( 'id' ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Course not found.' ), 404 );
        }

        // Check if already enrolled.
        $student = llms_get_student( $user_id );
        if ( $student && $student->is_enrolled( $course_id ) ) {
            return new WP_REST_Response( array( 'success' => true, 'message' => 'Already enrolled.' ), 200 );
        }

        // Check if free — LifterLMS 10 removed is_free(); check access plans directly.
        $is_free = true;
        if ( function_exists( 'llms_get_access_plans_for_object' ) ) {
            $plans = llms_get_access_plans_for_object( $course_id );
            if ( ! empty( $plans ) ) {
                foreach ( $plans as $plan ) {
                    $price = (float) get_post_meta( $plan->get( 'id' ), '_llms_price', true );
                    if ( $price > 0 ) {
                        $is_free = false;
                        break;
                    }
                }
            }
        }

        if ( ! $is_free ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'This course requires payment.' ), 402 );
        }

        // Enroll.
        $result = llms_enroll_student( $user_id, $course_id, 'app_enrollment' );

        if ( is_wp_error( $result ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => $result->get_error_message() ), 500 );
        }

        return new WP_REST_Response( array( 'success' => true, 'message' => 'Enrolled successfully.' ), 200 );
    }

    // =========================================================================
    // Lessons
    // =========================================================================

    /**
     * GET /app/lessons/{id}
     */
    public function get_lesson( $request ) {
        $lesson_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();

        $post = get_post( $lesson_id );
        if ( ! $post || 'lesson' !== $post->post_type ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Lesson not found.' ), 404 );
        }

        $data = array(
            'id'            => $lesson_id,
            'title'         => $post->post_title,
            'content'       => apply_filters( 'the_content', $post->post_content ),
            'excerpt'       => $post->post_excerpt,
            'thumbnail'     => get_the_post_thumbnail_url( $lesson_id, 'large' ) ?: '',
            'duration'      => get_post_meta( $lesson_id, '_lesson_duration', true ),
            'video_url'     => get_post_meta( $lesson_id, '_lesson_video_url', true ),
            'video_embed'   => get_post_meta( $lesson_id, '_llms_video_embed', true ),
            'audio_embed'   => get_post_meta( $lesson_id, '_llms_audio_embed', true ),
            'order'         => (int) $post->menu_order,
            'permalink'     => get_the_permalink( $lesson_id ),
            'course_id'     => 0,
            'section_id'    => 0,
            'has_quiz'      => false,
            'quiz_id'       => null,
            'is_completed'  => false,
            'is_free'       => (bool) get_post_meta( $lesson_id, '_llms_free_lesson', true ),
            'attachments'   => $this->get_lesson_attachments( $lesson_id ),
        );

        // Resolve course_id.
        $parent_course = get_post_meta( $lesson_id, '_llms_parent_course', true );
        if ( $parent_course ) {
            $data['course_id'] = (int) $parent_course;
        }

        $parent_section = get_post_meta( $lesson_id, '_llms_parent_section', true );
        if ( $parent_section ) {
            $data['section_id'] = (int) $parent_section;
        }

        // Quiz association.
        $quiz_enabled = get_post_meta( $lesson_id, '_llms_quiz_enabled', true );
        if ( 'yes' === $quiz_enabled ) {
            $quizzes = get_post_meta( $lesson_id, '_llms_quiz', true );
            if ( ! empty( $quizzes ) ) {
                $quiz_ids = is_array( $quizzes ) ? $quizzes : array( $quizzes );
                $data['has_quiz'] = true;
                $data['quiz_id']  = (int) $quiz_ids[0];
            }
        }

        // Completion status.
        if ( $user_id > 0 && class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user_id );
            if ( $student ) {
                $data['is_completed'] = $student->is_complete( $lesson_id, 'lesson' );
            }
        }

        // Navigation (prev/next).
        $data['prev_lesson'] = $this->get_adjacent_lesson( $lesson_id, $data['course_id'], 'prev' );
        $data['next_lesson'] = $this->get_adjacent_lesson( $lesson_id, $data['course_id'], 'next' );

        return new WP_REST_Response( array( 'success' => true, 'data' => $data ), 200 );
    }

    /**
     * POST /app/lessons/{id}/complete
     */
    public function complete_lesson( $request ) {
        $lesson_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();

        if ( ! class_exists( 'LifterLMS' ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'LMS not available.' ), 500 );
        }

        $student = llms_get_student( $user_id );
        if ( ! $student ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Student not found.' ), 404 );
        }

        $course_id = (int) get_post_meta( $lesson_id, '_llms_parent_course', true );

        // Mark complete.
        $result = $student->mark_complete( $lesson_id, 'lesson', 'pagepilot_app' );

        if ( is_wp_error( $result ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => $result->get_error_message() ), 500 );
        }

        // Check if course is now complete.
        // get_progress() returns a float percentage (0–100).
        $progress_val    = 0;
        $course_complete = false;
        $raw_progress = $student->get_progress( $course_id );
        if ( is_numeric( $raw_progress ) ) {
            $progress_val    = round( (float) $raw_progress );
            $course_complete = ( $progress_val >= 100 );
        }

        // Get next lesson.
        $next = $this->get_adjacent_lesson( $lesson_id, $course_id, 'next' );

        return new WP_REST_Response( array(
            'success'        => true,
            'message'        => 'Lesson completed.',
            'course_complete' => $course_complete,
            'next_lesson'    => $next,
            'progress'       => array(
                'percentage' => $progress_val,
            ),
        ), 200 );
    }

    // =========================================================================
    // Quizzes
    // =========================================================================

    /**
     * GET /app/quizzes/{id}
     */
    public function get_quiz( $request ) {
        $quiz_id  = absint( $request->get_param( 'id' ) );
        $user_id  = $this->get_app_user_id();
        $post     = get_post( $quiz_id );

        if ( ! $post || 'llms_quiz' !== $post->post_type ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Quiz not found.' ), 404 );
        }

        // Get questions.
        $questions = array();
        $question_ids = get_post_meta( $quiz_id, '_llms_quiz_questions', true );
        if ( ! is_array( $question_ids ) ) {
            $question_ids = array();
        }

        foreach ( $question_ids as $q_id ) {
            $q_post = get_post( $q_id );
            if ( ! $q_post ) {
                continue;
            }

            $q_type     = get_post_meta( $q_id, '_llms_question_type', true );
            $options    = get_post_meta( $q_id, '_llms_question_options', true );
            $points     = get_post_meta( $q_id, '_llms_question_points', true );
            $media      = get_post_meta( $q_id, '_llms_question_media', true );
            $explainer  = get_post_meta( $q_id, '_llms_question_explainer', true );

            $formatted_options = array();
            if ( is_array( $options ) ) {
                foreach ( $options as $key => $text ) {
                    $formatted_options[] = array(
                        'id'    => $key,
                        'title' => $text,
                    );
                }
            }

            $questions[] = array(
                'id'           => $q_id,
                'type'         => $q_type,
                'title'        => $q_post->post_title,
                'content'      => apply_filters( 'the_content', $q_post->post_content ),
                'options'      => $formatted_options,
                'points'       => $points ? (int) $points : 1,
                'media'        => $media ?: null,
                'explanation'  => $explainer ?: null,
            );
        }

        $data = array(
            'id'              => $quiz_id,
            'title'           => $post->post_title,
            'description'     => apply_filters( 'the_content', $post->post_content ),
            'questions'       => $questions,
            'passing_grade'   => (int) get_post_meta( $quiz_id, '_llms_quiz_passing_percent', true ),
            'time_limit'      => (int) get_post_meta( $quiz_id, '_llms_quiz_time_limit', true ),
            'max_attempts'    => (int) get_post_meta( $quiz_id, '_llms_quiz_limit_attempts', true ),
            'randomize'       => 'yes' === get_post_meta( $quiz_id, '_llms_quiz_randomize', true ),
            'show_results'    => get_post_meta( $quiz_id, '_llms_quiz_results_display', true ),
            'attempts'        => 0,
            'best_score'      => 0,
            'course_id'       => 0,
        );

        // Resolve course from parent lesson.
        $parent_lesson = get_post_meta( $quiz_id, '_llms_parent_lesson', true );
        if ( ! $parent_lesson ) {
            $parent_lesson = (int) $post->post_parent;
        }
        if ( $parent_lesson ) {
            $data['course_id'] = (int) get_post_meta( $parent_lesson, '_llms_parent_course', true );
        }

        // Get attempt count and best score.
        if ( $user_id > 0 && class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user_id );
            if ( $student ) {
                $attempts = $student->get_quiz_attempts( $quiz_id );
                if ( is_array( $attempts ) ) {
                    $data['attempts']   = count( $attempts );
                    $best               = 0;
                    foreach ( $attempts as $attempt ) {
                        $grade = isset( $attempt->grade ) ? (float) $attempt->grade : 0;
                        if ( $grade > $best ) {
                            $best = $grade;
                        }
                    }
                    $data['best_score'] = $best;
                }
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $data ), 200 );
    }

    /**
     * POST /app/quizzes/{id}/submit
     */
    public function submit_quiz( $request ) {
        $quiz_id  = absint( $request->get_param( 'id' ) );
        $user_id  = $this->get_app_user_id();
        $params   = $request->get_json_params();
        $answers  = isset( $params['answers'] ) ? $params['answers'] : array();

        if ( ! class_exists( 'LifterLMS' ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'LMS not available.' ), 500 );
        }

        $student = llms_get_student( $user_id );
        if ( ! $student ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Student not found.' ), 404 );
        }

        $post = get_post( $quiz_id );
        if ( ! $post ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Quiz not found.' ), 404 );
        }

        // Grade the quiz manually (more reliable than LifterLMS internal methods).
        $question_ids = get_post_meta( $quiz_id, '_llms_quiz_questions', true );
        if ( ! is_array( $question_ids ) ) {
            $question_ids = array();
        }

        $total_points     = 0;
        $earned_points    = 0;
        $correct_answers  = array();
        $results          = array();

        foreach ( $question_ids as $q_id ) {
            $q_post = get_post( $q_id );
            if ( ! $q_post ) {
                continue;
            }

            $points          = (int) get_post_meta( $q_id, '_llms_question_points', true );
            $correct_key     = get_post_meta( $q_id, '_llms_answer_key', true );
            $q_type          = get_post_meta( $q_id, '_llms_question_type', true );
            $user_answer     = isset( $answers[ $q_id ] ) ? $answers[ $q_id ] : '';

            $total_points += $points > 0 ? $points : 1;
            $is_correct    = false;

            if ( 'choice' === $q_type || 'picture_choice' === $q_type ) {
                $is_correct = ( $user_answer === $correct_key );
            } elseif ( 'true_false' === $q_type ) {
                $is_correct = ( strtolower( $user_answer ) === strtolower( $correct_key ) );
            } elseif ( 'fill_blank' === $q_type ) {
                $is_correct = ( strtolower( trim( $user_answer ) ) === strtolower( trim( $correct_key ) ) );
            } elseif ( 'multi_choice' === $q_type ) {
                if ( is_array( $correct_key ) && is_array( $user_answer ) ) {
                    sort( $correct_key );
                    sort( $user_answer );
                    $is_correct = ( $correct_key === $user_answer );
                }
            }

            if ( $is_correct ) {
                $earned_points += $points > 0 ? $points : 1;
            }

            $correct_answers[ $q_id ] = $correct_key;
            $results[] = array(
                'question_id' => $q_id,
                'user_answer' => $user_answer,
                'correct_answer' => $correct_key,
                'is_correct'  => $is_correct,
                'points'      => $points > 0 ? $points : 1,
            );
        }

        $percentage = $total_points > 0 ? round( ( $earned_points / $total_points ) * 100 ) : 0;
        $passing    = (int) get_post_meta( $quiz_id, '_llms_quiz_passing_percent', true );
        $passed     = $percentage >= $passing;

        // Store the attempt.
        $attempt_data = array(
            'quiz_id'     => $quiz_id,
            'user_id'     => $user_id,
            'grade'       => $percentage,
            'passed'      => $passed,
            'points'      => $earned_points,
            'total'       => $total_points,
            'answers'     => $results,
            'date'        => current_time( 'mysql' ),
        );

        // Store in postmeta for history.
        $attempts = get_user_meta( $user_id, '_pp_quiz_attempts_' . $quiz_id, true );
        if ( ! is_array( $attempts ) ) {
            $attempts = array();
        }
        $attempts[] = $attempt_data;
        update_user_meta( $user_id, '_pp_quiz_attempts_' . $quiz_id, $attempts );

        // If passed and quiz is linked to a lesson, mark lesson complete.
        if ( $passed ) {
            $parent_lesson = get_post_meta( $quiz_id, '_llms_parent_lesson', true );
            if ( ! $parent_lesson ) {
                $parent_lesson = (int) $post->post_parent;
            }
            if ( $parent_lesson ) {
                $course_id = (int) get_post_meta( $parent_lesson, '_llms_parent_course', true );
                $student->complete_lesson( $parent_lesson, $course_id );
            }
        }

        return new WP_REST_Response( array(
            'success'        => true,
            'data'           => array(
                'percentage'   => $percentage,
                'passed'       => $passed,
                'points'       => $earned_points,
                'total_points' => $total_points,
                'passing_grade' => $passing,
                'results'      => $results,
                'attempt_number' => count( $attempts ),
            ),
        ), 200 );
    }

    // =========================================================================
    // Progress
    // =========================================================================

    /**
     * GET /app/courses/{id}/progress
     */
    public function get_course_progress( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();

        $progress = array(
            'total'      => 0,
            'completed'  => 0,
            'percentage' => 0,
            'lessons'    => array(),
        );

        if ( class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user_id );
            if ( $student ) {
                // get_progress() returns a float percentage (0–100).
                $prog = $student->get_progress( $course_id );
                if ( is_numeric( $prog ) ) {
                    $progress['percentage'] = round( (float) $prog );
                }

                // Per-lesson completion status.
                $course_post = get_post( $course_id );
                if ( $course_post ) {
                    $lessons = get_posts( array(
                        'post_type'      => 'lesson',
                        'post_status'    => 'publish',
                        'meta_key'       => '_llms_parent_course',
                        'meta_value'     => $course_id,
                        'posts_per_page' => -1,
                        'orderby'        => 'menu_order',
                        'order'          => 'ASC',
                    ) );

                    foreach ( $lessons as $lesson ) {
                        $progress['lessons'][] = array(
                            'id'           => $lesson->ID,
                            'title'        => $lesson->post_title,
                            'is_completed' => $student->is_complete( $lesson->ID, 'lesson' ),
                        );
                    }
                }
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $progress ), 200 );
    }

    // =========================================================================
    // Certificates
    // =========================================================================

    /**
     * GET /app/certificates
     */
    public function get_certificates( $request ) {
        $user_id = $this->get_app_user_id();
        $certificates = array();

        if ( class_exists( 'LifterLMS' ) ) {
            // Try LifterLMS certificate custom post type.
            $cert_posts = get_posts( array(
                'post_type'      => 'llms_certificate',
                'post_status'    => 'publish',
                'author'         => $user_id,
                'posts_per_page' => -1,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ) );

            foreach ( $cert_posts as $cert ) {
                $certificates[] = array(
                    'id'          => $cert->ID,
                    'title'       => $cert->post_title,
                    'date'        => $cert->post_date,
                    'url'         => get_the_permalink( $cert->ID ),
                    'course_id'   => (int) get_post_meta( $cert->ID, '_llms_course_id', true ),
                    'course_name' => get_the_title( get_post_meta( $cert->ID, '_llms_course_id', true ) ),
                );
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $certificates ), 200 );
    }

    // =========================================================================
    // Wishlist
    // =========================================================================

    /**
     * GET /app/wishlist
     */
    public function get_wishlist( $request ) {
        $user_id = $this->get_app_user_id();
        $course_ids = get_user_meta( $user_id, '_pagepilot_wishlist', true );
        if ( ! is_array( $course_ids ) ) {
            $course_ids = array();
        }

        $courses = array();
        foreach ( $course_ids as $cid ) {
            $post = get_post( $cid );
            if ( $post && 'course' === $post->post_type ) {
                $courses[] = $this->format_course_public( $cid );
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $courses ), 200 );
    }

    /**
     * POST /app/wishlist/{id}
     */
    public function add_to_wishlist( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();

        $wishlist = get_user_meta( $user_id, '_pagepilot_wishlist', true );
        if ( ! is_array( $wishlist ) ) {
            $wishlist = array();
        }

        if ( ! in_array( $course_id, $wishlist, true ) ) {
            $wishlist[] = $course_id;
            update_user_meta( $user_id, '_pagepilot_wishlist', $wishlist );
        }

        return new WP_REST_Response( array( 'success' => true, 'message' => 'Added to wishlist.' ), 200 );
    }

    /**
     * DELETE /app/wishlist/{id}
     */
    public function remove_from_wishlist( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();

        $wishlist = get_user_meta( $user_id, '_pagepilot_wishlist', true );
        if ( ! is_array( $wishlist ) ) {
            $wishlist = array();
        }

        $wishlist = array_diff( $wishlist, array( $course_id ) );
        update_user_meta( $user_id, '_pagepilot_wishlist', array_values( $wishlist ) );

        return new WP_REST_Response( array( 'success' => true, 'message' => 'Removed from wishlist.' ), 200 );
    }

    // =========================================================================
    // Reviews
    // =========================================================================

    /**
     * GET /app/courses/{id}/reviews
     */
    public function get_course_reviews( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $reviews   = array();

        // LifterLMS reviews.
        if ( class_exists( 'LifterLMS' ) && function_exists( 'llms_get_reviews' ) ) {
            $review_posts = get_comments( array(
                'post_id' => $course_id,
                'type'    => 'llms_review',
                'status'  => 'approve',
                'number'  => 20,
            ) );

            foreach ( $review_posts as $review ) {
                $reviews[] = array(
                    'id'         => $review->comment_ID,
                    'rating'     => (int) get_comment_meta( $review->comment_ID, 'rating', true ),
                    'user_name'  => $review->comment_author,
                    'user_avatar'=> get_avatar_url( $review->user_id, array( 'size' => 80 ) ),
                    'comment'    => $review->comment_content,
                    'date'       => $review->comment_date,
                );
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $reviews ), 200 );
    }

    /**
     * POST /app/courses/{id}/reviews
     */
    public function submit_course_review( $request ) {
        $course_id = absint( $request->get_param( 'id' ) );
        $user_id   = $this->get_app_user_id();
        $params    = $request->get_json_params();
        $rating    = isset( $params['rating'] ) ? absint( $params['rating'] ) : 0;
        $comment   = isset( $params['comment'] ) ? sanitize_textarea_field( $params['comment'] ) : '';

        if ( $rating < 1 || $rating > 5 ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Rating must be between 1 and 5.' ), 400 );
        }

        $comment_id = wp_insert_comment( array(
            'comment_post_ID' => $course_id,
            'user_id'         => $user_id,
            'comment_author'  => get_userdata( $user_id )->display_name,
            'comment_content' => $comment,
            'comment_type'    => 'llms_review',
            'comment_approved' => 1,
        ) );

        if ( $comment_id ) {
            update_comment_meta( $comment_id, 'rating', $rating );
            return new WP_REST_Response( array( 'success' => true, 'message' => 'Review submitted.' ), 201 );
        }

        return new WP_REST_Response( array( 'success' => false, 'message' => 'Failed to submit review.' ), 500 );
    }

    // =========================================================================
    // Categories & Search
    // =========================================================================

    /**
     * GET /app/categories
     */
    public function get_categories( $request ) {
        $terms = get_terms( array(
            'taxonomy'   => 'course_cat',
            'hide_empty' => true,
        ) );

        $categories = array();
        if ( ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $categories[] = array(
                    'id'    => $term->term_id,
                    'name'  => $term->name,
                    'slug'  => $term->slug,
                    'count' => $term->count,
                );
            }
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $categories ), 200 );
    }

    /**
     * GET /app/search
     */
    public function search( $request ) {
        $query = $request->get_param( 'q' ) ?: '';
        $type  = $request->get_param( 'type' ) ?: 'course';

        if ( empty( $query ) ) {
            return new WP_REST_Response( array( 'success' => true, 'data' => array() ), 200 );
        }

        $args = array(
            's'              => sanitize_text_field( $query ),
            'posts_per_page' => 20,
            'post_status'    => 'publish',
        );

        if ( 'course' === $type ) {
            $args['post_type'] = 'course';
        } elseif ( 'lesson' === $type ) {
            $args['post_type'] = 'lesson';
        } else {
            $args['post_type'] = array( 'course', 'lesson' );
        }

        $query_obj = new WP_Query( $args );
        $results   = array();

        foreach ( $query_obj->posts as $post ) {
            $item = array(
                'id'    => $post->ID,
                'title' => $post->post_title,
                'type'  => $post->post_type,
                'thumbnail' => get_the_post_thumbnail_url( $post->ID, 'thumbnail' ) ?: '',
                'excerpt'   => wp_trim_words( $post->post_excerpt ?: $post->post_content, 20 ),
                'permalink' => get_the_permalink( $post->ID ),
            );

            if ( 'course' === $post->post_type ) {
                $rating_obj = function_exists( 'llms_get_course_rating' ) ? llms_get_course_rating( $post->ID ) : null;
                $item['price']     = $this->get_course_price( $post->ID );
                $item['rating']    = ( $rating_obj && isset( $rating_obj->rating ) ) ? (float) $rating_obj->rating : 0;
                $item['instructor'] = $this->get_course_instructor( $post->ID );
            }

            $results[] = $item;
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $results ), 200 );
    }

    // =========================================================================
    // Instructors
    // =========================================================================

    /**
     * GET /app/instructors
     */
    public function get_instructors( $request ) {
        $instructors = array();
        $users = get_users( array( 'role__in' => array( 'lifterlms_instructor', 'lifterlms_instructor_assistant' ) ) );

        foreach ( $users as $user ) {
            $instructors[] = array(
                'id'           => $user->ID,
                'name'         => $user->display_name,
                'avatar'       => get_avatar_url( $user->ID, array( 'size' => 200 ) ),
                'bio'          => $user->description ?: '',
                'course_count' => count_user_posts( $user->ID, 'course' ),
            );
        }

        return new WP_REST_Response( array( 'success' => true, 'data' => $instructors ), 200 );
    }

    // =========================================================================
    // Private Helpers
    // =========================================================================

    /**
     * Format a course for public API response.
     */
    private function format_course_public( $course_id, $full = false ) {
        global $wpdb;

        $post = get_post( $course_id );
        if ( ! $post ) {
            return array();
        }

        $course = new LLMS_Course( $course_id );
        $rating_obj = function_exists( 'llms_get_course_rating' ) ? llms_get_course_rating( $course_id ) : null;

        // Count lessons directly from meta to avoid deprecated methods.
        $lessons_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID WHERE p.post_type = 'lesson' AND p.post_status = 'publish' AND pm.meta_key = '_llms_parent_course' AND pm.meta_value = %d",
            $course_id
        ) );

        // Check if free by looking for price access plan or price meta.
        $price = get_post_meta( $course_id, '_llms_price', true );
        $is_free = ( '' === $price || 0 == $price );

        $data = array(
            'id'                => $course_id,
            'title'             => $post->post_title,
            'description'       => $full ? apply_filters( 'the_content', $post->post_content ) : wp_trim_words( $post->post_content, 30 ),
            'shortDescription'  => wp_trim_words( $post->post_excerpt ?: $post->post_content, 20 ),
            'thumbnail'         => get_the_post_thumbnail_url( $course_id, 'large' ) ?: '',
            'price'             => $this->get_course_price_num( $course_id ),
            'salePrice'         => (float) ( get_post_meta( $course_id, '_llms_sale_price', true ) ?: 0 ),
            'duration'          => $this->get_course_duration( $course_id ),
            'instructor'        => $this->get_course_instructor( $course_id ),
            'rating'            => ( $rating_obj && isset( $rating_obj->rating ) ) ? (float) $rating_obj->rating : 0,
            'ratingCount'       => ( $rating_obj && isset( $rating_obj->count ) ) ? (int) $rating_obj->count : 0,
            'studentsCount'     => $this->get_student_count( $course_id ),
            'lessonsCount'      => $lessons_count,
            'quizzesCount'      => $this->get_quiz_count( $course_id ),
            'categories'        => $this->get_course_categories( $course_id ),
            'tags'              => $this->get_course_tags( $course_id ),
            'isFree'            => $is_free,
            'isEnrolled'        => false,
            'isWishlisted'      => false,
            'progress'          => 0.0,
            'curriculum'        => array(),
            'permalink'         => get_the_permalink( $course_id ) ?: '',
            'status'            => $post->post_status,
        );

        return $data;
    }

    /**
     * Get course sections with lessons.
     */
    private function get_course_sections( $course_id, $with_content = false ) {
        $sections = array();

        // Get sections via _llms_parent_course on lessons.
        $lessons = get_posts( array(
            'post_type'      => 'lesson',
            'post_status'    => 'publish',
            'meta_key'       => '_llms_parent_course',
            'meta_value'     => $course_id,
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );

        // Get quizzes for this course.
        $quizzes = get_posts( array(
            'post_type'      => 'llms_quiz',
            'post_status'    => 'publish',
            'meta_key'       => '_llms_parent_course',
            'meta_value'     => $course_id,
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );

        // Determine completion status for authenticated user.
        $completed_ids = array();
        $user_id = $this->get_app_user_id();
        if ( $user_id > 0 && class_exists( 'LifterLMS' ) ) {
            $student = llms_get_student( $user_id );
            if ( $student ) {
                foreach ( $lessons as $lesson ) {
                    if ( $student->is_complete( $lesson->ID, 'lesson' ) ) {
                        $completed_ids[ $lesson->ID ] = true;
                    }
                }
                foreach ( $quizzes as $quiz ) {
                    if ( $student->is_complete( $quiz->ID, 'quiz' ) ) {
                        $completed_ids[ $quiz->ID ] = true;
                    }
                }
            }
        }

        // Group lessons by section.
        $section_map = array();
        foreach ( $lessons as $lesson ) {
            $section_id = (int) get_post_meta( $lesson->ID, '_llms_parent_section', true );
            if ( ! isset( $section_map[ $section_id ] ) ) {
                $section_post = get_post( $section_id );
                $section_map[ $section_id ] = array(
                    'sectionTitle' => $section_post ? $section_post->post_title : 'Untitled Section',
                    'items'        => array(),
                );
            }

            $item = array(
                'type'        => 'lesson',
                'id'          => $lesson->ID,
                'title'       => $lesson->post_title,
                'duration'    => get_post_meta( $lesson->ID, '_lesson_duration', true ) ?: '',
                'isCompleted' => isset( $completed_ids[ $lesson->ID ] ),
            );

            if ( $with_content ) {
                $item['content'] = apply_filters( 'the_content', $lesson->post_content );
                // LifterLMS stores video in _llms_video_embed; fallback to _lesson_video_url.
                $video = get_post_meta( $lesson->ID, '_llms_video_embed', true ) ?: '';
                if ( empty( $video ) ) {
                    $video = get_post_meta( $lesson->ID, '_lesson_video_url', true ) ?: '';
                }
                $item['videoUrl'] = $video;
                $item['isFree'] = (bool) get_post_meta( $lesson->ID, '_llms_free_lesson', true );
            }

            $section_map[ $section_id ]['items'][] = $item;
        }

        // Add quizzes to their parent sections.
        foreach ( $quizzes as $quiz ) {
            // Quizzes may be linked to a lesson; find that lesson's section.
            $quiz_lesson_id = (int) get_post_meta( $quiz->ID, '_llms_quiz_lesson_id', true );
            $section_id = 0;
            if ( $quiz_lesson_id > 0 ) {
                $section_id = (int) get_post_meta( $quiz_lesson_id, '_llms_parent_section', true );
            }
            if ( $section_id === 0 && ! empty( $section_map ) ) {
                $section_id = array_key_first( $section_map );
            }
            if ( ! isset( $section_map[ $section_id ] ) ) {
                continue;
            }

            $item = array(
                'type'        => 'quiz',
                'id'          => $quiz->ID,
                'title'       => $quiz->post_title,
                'duration'    => '',
                'isCompleted' => isset( $completed_ids[ $quiz->ID ] ),
            );

            if ( $with_content ) {
                $item['content'] = apply_filters( 'the_content', $quiz->post_content );
                $item['isFree'] = false;
            }

            $section_map[ $section_id ]['items'][] = $item;
        }

        $sections = array_values( $section_map );
        return $sections;
    }

    private function get_course_price( $course_id ) {
        $price = get_post_meta( $course_id, '_llms_price', true );
        if ( '' === $price || false === $price ) {
            return 'Free';
        }
        if ( function_exists( 'llms_price' ) ) {
            return llms_price( $price );
        }
        return (string) $price;
    }

    private function get_course_price_num( $course_id ) {
        $price = get_post_meta( $course_id, '_llms_price', true );
        if ( '' === $price || false === $price ) {
            return 0;
        }
        return (float) $price;
    }

    private function get_course_duration( $course_id ) {
        $hours   = (int) get_post_meta( $course_id, '_llms_duration_hours', true );
        $minutes = (int) get_post_meta( $course_id, '_llms_duration_minutes', true );
        $parts   = array();
        if ( $hours > 0 ) {
            $parts[] = $hours . 'h';
        }
        if ( $minutes > 0 ) {
            $parts[] = $minutes . 'm';
        }
        return implode( ' ', $parts );
    }

    private function get_course_instructor( $course_id ) {
        $author_id = (int) get_post_field( 'post_author', $course_id );
        $user = get_userdata( $author_id );
        return array(
            'id'     => $author_id,
            'name'   => $user ? $user->display_name : '',
            'avatar' => $user ? get_avatar_url( $author_id, array( 'size' => 100 ) ) : '',
        );
    }

    private function get_student_count( $course_id ) {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT post_author) FROM {$wpdb->posts}
                 WHERE post_type = 'llms_enrollment'
                   AND post_status IN ('enrolled', 'completed')
                   AND post_parent = %d",
                $course_id
            )
        );
    }

    private function get_quiz_count( $course_id ) {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                 WHERE p.post_type = 'lesson'
                   AND p.post_status = 'publish'
                   AND pm.meta_key = '_llms_parent_course'
                   AND pm.meta_value = %d
                   AND EXISTS (
                     SELECT 1 FROM {$wpdb->postmeta} pm2
                     WHERE pm2.post_id = p.ID
                       AND pm2.meta_key = '_llms_quiz_enabled'
                       AND pm2.meta_value = 'yes'
                   )",
                $course_id
            )
        );
    }

    private function get_course_categories( $course_id ) {
        $terms = get_the_terms( $course_id, 'course_cat' );
        if ( ! is_array( $terms ) ) {
            return array();
        }
        return array_map( function ( $t ) {
            return $t->name;
        }, $terms );
    }

    private function get_course_tags( $course_id ) {
        $terms = get_the_terms( $course_id, 'course_tag' );
        if ( ! is_array( $terms ) ) {
            return array();
        }
        return array_map( function ( $t ) {
            return $t->name;
        }, $terms );
    }

    private function get_lesson_attachments( $lesson_id ) {
        $attachments = array();
        $download_ids = get_post_meta( $lesson_id, '_llms_downloads', true );
        if ( is_array( $download_ids ) ) {
            foreach ( $download_ids as $att_id ) {
                $att = get_post( $att_id );
                if ( $att ) {
                    $url = wp_get_attachment_url( $att_id );
                    $attachments[] = array(
                        'id'   => $att_id,
                        'name' => $att->post_title,
                        'url'  => $url,
                        'type' => get_post_mime_type( $att_id ),
                        'size' => function_exists( 'size_format' ) ? size_format( filesize( get_attached_file( $att_id ) ) ) : '',
                    );
                }
            }
        }
        return $attachments;
    }

    private function get_adjacent_lesson( $lesson_id, $course_id, $direction = 'next' ) {
        $lessons = get_posts( array(
            'post_type'      => 'lesson',
            'post_status'    => 'publish',
            'meta_key'       => '_llms_parent_course',
            'meta_value'     => $course_id,
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
            'fields'         => 'ids',
        ) );

        $index = array_search( $lesson_id, $lessons );
        if ( false === $index ) {
            return null;
        }

        if ( 'next' === $direction && isset( $lessons[ $index + 1 ] ) ) {
            $next_id = $lessons[ $index + 1 ];
            $next_post = get_post( $next_id );
            return $next_post ? array( 'id' => $next_id, 'title' => $next_post->post_title ) : null;
        }

        if ( 'prev' === $direction && isset( $lessons[ $index - 1 ] ) ) {
            $prev_id = $lessons[ $index - 1 ];
            $prev_post = get_post( $prev_id );
            return $prev_post ? array( 'id' => $prev_id, 'title' => $prev_post->post_title ) : null;
        }

        return null;
    }
}
